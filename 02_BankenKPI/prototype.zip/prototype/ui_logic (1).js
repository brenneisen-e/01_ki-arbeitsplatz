/* ============================================================
   NÜRNBERGER KPI-Board — UI-Logik
   ------------------------------------------------------------
   Reine Funktionen ohne DOM: Zahleneingabe, Plausibilität,
   Veränderung zur Vorperiode, Sortierung, Hochrechnung.
   Läuft im Browser und in Node (Tests).
   ============================================================ */
(function (root) {
  'use strict';

  const fmt = (n, digits) => n.toLocaleString('de-DE', { maximumFractionDigits: digits });

  /* „1,85" und „1.85" → 1.85; leer → null; sonst NaN.
     Tausenderpunkte werden abgewiesen (mehrdeutig). */
  function parseDecimal(raw) {
    const s = String(raw == null ? '' : raw).trim().replace(/−/g, '-').replace(/\s+/g, '');
    if (s === '') return null;
    if (!/^[+-]?\d+([.,]\d+)?$/.test(s)) return NaN;
    return parseFloat(s.replace(',', '.'));
  }

  /* Eingabefreundlich: Komma, keine Tausendertrennung. */
  function formatDecimalDe(v) {
    if (typeof v !== 'number' || Number.isNaN(v)) return '';
    return String(v).replace('.', ',');
  }

  /* Außerhalb der Grenzen → error (Speichern gesperrt). Großer Sprung zur
     Vorperiode → warn: > 25 % der Spanne, ohne Spanne > 50 % des Vorwerts. */
  function checkPlausible(value, bounds, prev) {
    if (typeof value !== 'number' || Number.isNaN(value)) return { level: 'ok', msg: '' };
    const b = bounds || {};
    if (typeof b.min === 'number' && value < b.min) return { level: 'error', msg: `unter ${fmt(b.min, 2)} nicht möglich` };
    if (typeof b.max === 'number' && value > b.max) return { level: 'error', msg: `über ${fmt(b.max, 2)} nicht möglich` };
    if (typeof prev === 'number') {
      const d = Math.abs(value - prev);
      const hasRange = typeof b.min === 'number' && typeof b.max === 'number';
      const limit = hasRange ? 0.25 * (b.max - b.min) : 0.5 * Math.abs(prev);
      if (limit > 0 && d > limit) {
        return { level: 'warn', msg: `Sprung ${value > prev ? '+' : '−'}${fmt(d, 2)} ggü. Vorperiode — bitte prüfen` };
      }
    }
    return { level: 'ok', msg: '' };
  }

  /* Veränderung zur Vorperiode: Raten absolut („+0,2 pp"), sonst relativ
     („+6,9 %"). good = Bewegung in Zielrichtung. */
  function periodDelta(cur, prev, opts) {
    if (typeof cur !== 'number' || typeof prev !== 'number') return null;
    const o = opts || {};
    const d = cur - prev;
    if (Math.abs(d) < 1e-9) return { delta: 0, text: '±0', good: null };
    const sign = d > 0 ? '+' : '−';
    const good = o.direction === 'up' ? d > 0 : d < 0;
    /* Kleine Änderungen mit zwei Nachkommastellen, sonst würden sie zu 0 gerundet. */
    if (o.isRate) {
      const digits = Math.abs(d) < 0.095 ? 2 : 1;
      const unit = o.unitLabel === 'Punkte' && fmt(Math.abs(d), digits) === '1' ? 'Punkt' : (o.unitLabel || '');
      return { delta: d, text: `${sign}${fmt(Math.abs(d), digits)} ${unit}`.trim(), good };
    }
    if (prev === 0) return null;
    return { delta: d, text: `${sign}${fmt(Math.abs(d) / Math.abs(prev) * 100, 1)} %`, good };
  }

  /* Rot vor Gelb; sonst bleibt die Reihenfolge. */
  function sortFlagged(items) {
    const rank = s => (s === 'red' ? 0 : s === 'amber' ? 1 : 2);
    return (items || []).map((x, i) => [x, i])
      .sort((a, b) => rank(a[0].s) - rank(b[0].s) || a[1] - b[1])
      .map(x => x[0]);
  }

  /* Letztes volles Geschäftsjahr = jüngster Q4-Wert; sonst der Rückfallwert. */
  function latestFullYear(points, fallback) {
    const pts = points || [];
    for (let i = pts.length - 1; i >= 0; i--) {
      const p = pts[i];
      if (/-Q4$/.test(p.period) && typeof p.value === 'number') {
        return { value: p.value, year: p.period.slice(0, 4), source: 'serie' };
      }
    }
    if (fallback && typeof fallback.value === 'number') {
      return { value: fallback.value, year: String(fallback.year), source: 'meta' };
    }
    return null;
  }

  /* ---------- Hochrechnung kumulierter KPIs ----------
     Hochrechnung = YTD ÷ geplanter Jahresanteil bis zum Quartal.
     (×4/q wäre falsch: beim Konzernergebnis trägt Q4 rund 60 %.) */

  /* Geplanter Jahresanteil bis Quartal q: aus den hinterlegten Quartalen
     des Jahres, nach dem letzten hinterlegten Jahr aus den Durchschnitts-
     gewichten, davor keiner. */
  function phasingShare(documented, year, q, weights) {
    if (q === 4) return 1;
    const doc = documented || {};
    const v = doc[`${year}-Q${q}`], fy = doc[`${year}-Q4`];
    if (typeof v === 'number' && typeof fy === 'number' && fy !== 0) return v / fy;
    const years = Object.keys(doc).map(p => parseInt(String(p).slice(0, 4), 10)).filter(y => !isNaN(y));
    const lastDocYear = years.length ? Math.max(...years) : null;
    if (weights && lastDocYear !== null && year > lastDocYear && typeof weights[q - 1] === 'number') return weights[q - 1];
    return null;
  }

  function annualizeYtd(ytd, share) {
    if (typeof ytd !== 'number' || typeof share !== 'number' || share <= 0) return null;
    return ytd / share;
  }

  root.UiLogic = { parseDecimal, formatDecimalDe, checkPlausible, periodDelta, sortFlagged, latestFullYear, phasingShare, annualizeYtd };
})(typeof window !== 'undefined' ? window : globalThis);
