/* ============================================================
   NÜRNBERGER KPI-Board — Anwendung
   ------------------------------------------------------------
   Vanilla JS ohne Abhängigkeiten; rendert alle Ansichten aus DATA.
   Drei Fragen an dieselbe Kette:
     1  Gewinnen wir wirtschaftlich?  (finance)
     2  Wirken die vier Hebel?        (central je Hebel)
     3  Tun wir die richtigen Dinge?  (drivers je Hebel)
   ============================================================ */

/* ---------- Hilfsfunktionen ---------- */
const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

function esc(s) {
  return String(s == null ? "" : s)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

function fmtNum(v) {
  if (v === null || v === undefined) return "—";
  return v.toLocaleString("de-DE", { maximumFractionDigits: 2 });
}

function statusLabel(s) {
  return {
    green: "Auf Kurs",
    amber: "Beobachten",
    red: "Handlungsbedarf",
    "auszuwerten": "Auszuwerten",
    tbd: "Zu entwickeln"
  }[s] || s;
}

/* Status je KPI: green/amber/red, sonst Reifegrad (auszuwerten/tbd). */
function statusKey(k) {
  const r = resolve(k);
  if (["green", "amber", "red"].includes(r.status)) return r.status;
  if (k.maturity === "auszuwerten") return "auszuwerten";
  return "tbd";
}

/* Status-Badge mit Farbe und Abweichung vom Plan */
function ragBadge(s, computed, dev) {
  const devTxt = dev ? `<span class="badge-dev">${esc(dev.text)}</span>` : "";
  return `<span class="badge ${s}"><span class="rag-dot ${s}"></span>${statusLabel(s)}${devTxt}</span>`;
}

/* Badge für Kennzahlen ohne Messung: grau, ohne Statusfarbe */
function availBadge(s) {
  const map = {
    "auszuwerten": "Baseline bzw. Zielwert ausstehend",
    "tbd": "Kennzahl wird erst entwickelt"
  };
  return `<span class="badge-avail" title="${esc(map[s] || "")}"><span class="avail-ring"></span>${statusLabel(s)}</span>`;
}

function statusBadge(k) {
  const { status, computed } = resolve(k);
  if (["green", "amber", "red"].includes(status)) return ragBadge(status, computed, deviationInfo(k));
  return availBadge(statusKey(k));
}

/* Reifegrad (nur im Steckbrief) */
function maturityLabel(m) {
  return { "etabliert": "etabliert", "auszuwerten": "auszuwerten", "zu-entwickeln": "zu entwickeln" }[m] || "";
}

function vorschlagChip() {
  return `<span class="chip chip-vorschlag">Vorschlag</span>`;
}

/* Alle KPIs als flache Liste */
function allKpis() {
  return [...DATA.finance, ...DATA.central, ...DATA.drivers, ...DATA.suggestions];
}
function kpiById(id) {
  return allKpis().find(k => k.id === id);
}

function leverName(id) {
  const l = DATA.levers.find(x => x.id === id);
  if (l) return l.name;
  if (id === "finanzen") return "Finanzen";
  return id;
}

/* ---------- Farb-Tokens ---------- */
const cssVar = n => getComputedStyle(document.documentElement).getPropertyValue(n).trim();

/* ---------- Zustand (lokale Korrekturen) ---------- */
const STORE_KEY = "nuernberger-kpi-board-v3";
let EDITS = {};
try { EDITS = JSON.parse(localStorage.getItem(STORE_KEY) || "{}") || {}; } catch (e) { EDITS = {}; }
function saveEdits() { try { localStorage.setItem(STORE_KEY, JSON.stringify(EDITS)); } catch (e) {} }
function hasEdits(id) { return !!(EDITS[id] && Object.keys(EDITS[id]).length); }
function resetKpi(id) { delete EDITS[id]; saveEdits(); }
function resetAllEdits() { EDITS = {}; saveEdits(); }

let CURRENT_VIEW = null;

/* ---------- Effektive Werte ----------
   Rangfolge für den Ist-Wert: 1. Erfassung im Datenblatt
   2. Schnellkorrektur im Modal 3. jüngster Ist-Wert der Serie
   (data_basis.js) 4. current aus data.js. */
function latestActual(kpiId) {
  if (typeof KPI_DATA === "undefined" || !KPI_DATA[kpiId]) return null;
  const s = KPI_DATA[kpiId].series || [];
  for (let i = s.length - 1; i >= 0; i--) {
    if (s[i].isActual && typeof s[i].value === "number") return s[i];
  }
  return null;
}

function effKpi(k) {
  const merged = Object.assign({}, k);
  const entered = (typeof effectiveValue === "function") ? effectiveValue(k.id) : null;
  if (entered && typeof entered.value === "number") {
    merged.current = { value: entered.value, label: entered.period || k.current.label || "" };
  } else {
    const latest = latestActual(k.id);
    if (latest) merged.current = { value: latest.value, label: latest.period };
  }
  const e = EDITS[k.id];
  if (!e) return merged;
  if (e.target2028) merged.target2028 = Object.assign({}, k.target2028, e.target2028);
  if (e.target2031) merged.target2031 = Object.assign({}, k.target2031, e.target2031);
  /* Geänderte Basis wie geänderte Ziele übernehmen */
  if (e.baseline) merged.baseline = Object.assign({}, k.baseline, e.baseline);
  if (e.current) merged.current = Object.assign({}, merged.current, e.current);
  return merged;
}

/* ---------- Kumulierte Messung (YTD) ----------
   Gemessen wird der kumulierte Ist-Wert des Jahres gegen den
   anteiligen Plan, nicht ein Quartal gegen das Jahresziel.
   Gewichte je Quartal: linear (¼) oder `ytd.weights`. */
function ytdWeights(kpi) {
  const cfg = kpi.ytd || {};
  if (Array.isArray(cfg.weights) && cfg.weights.length === 4) return cfg.weights.slice();
  return [0.25, 0.25, 0.25, 0.25];
}

/* Quartal 1..4 aus „YYYY-Qn" */
function quarterOf(period) {
  const m = String(period || "").match(/^(\d{4})-Q([1-4])$/);
  return m ? { year: m[1], q: parseInt(m[2], 10) } : null;
}

/* ytd.mode aus data.js:
   - "kumuliert": Quartalswert = Jahreswert bis dahin (Q4 = Jahresergebnis);
     YTD ist der jüngste Wert, keine Summe.
   - "summe" (Standard): Quartalswerte werden addiert. */
function ytdMode(kpi) {
  return ((kpi.ytd || {}).mode === "kumuliert") ? "kumuliert" : "summe";
}

/* Kumulierter Ist-Wert bis einschließlich Quartal `uptoQ` */
function ytdActual(kpiId, year, uptoQ) {
  const kpi = kpiById(kpiId);
  if (!kpi) return { value: null, mode: "summe", quarters: [], missing: [] };
  const mode = ytdMode(kpi);
  const quarters = [], missing = [];
  let sum = 0, latest = null, any = false;
  for (let q = 1; q <= uptoQ; q++) {
    const period = `${year}-Q${q}`;
    const rec = (typeof getLongRecord === "function") ? getLongRecord(kpiId, period, "ist") : null;
    let v = null;
    if (rec && typeof rec.value === "number") v = rec.value;
    else if (typeof KPI_DATA !== "undefined" && KPI_DATA[kpiId]) {
      const s = (KPI_DATA[kpiId].series || []).find(x => x.period === period && x.isActual && typeof x.value === "number");
      if (s) v = s.value;
    }
    if (v === null) { missing.push(period); continue; }
    quarters.push({ period, value: v });
    sum += v; latest = v; any = true;
  }
  /* Bei kumulierten KPIs enthält der jüngste Wert die Vorquartale;
       fehlende frühere Quartale sind keine Lücke. */
  const gaps = (mode === "kumuliert" && any) ? [] : missing;
  return {
    value: any ? (mode === "kumuliert" ? latest : sum) : null,
    mode, quarters, missing: gaps
  };
}

/* Planwert bis Quartal `uptoQ`: kumuliert = Planwert der Periode,
   Summe = Summe der Planwerte Q1..uptoQ. Ohne Plan: anteiliges
   ytd.annualTarget. */
function ytdTarget(kpi, uptoQ, year) {
  const mode = ytdMode(kpi);
  const period = `${year}-Q${uptoQ}`;
  if (mode === "kumuliert") {
    const pv = pathValueAt(kpi, period);
    if (typeof pv === "number") return { value: pv, source: "pfad", period, mode };
  } else {
    let sum = 0, complete = true;
    for (let q = 1; q <= uptoQ; q++) {
      const pv = pathValueAt(kpi, `${year}-Q${q}`);
      if (typeof pv !== "number") { complete = false; break; }
      sum += pv;
    }
    if (complete) return { value: sum, source: "pfad", period, mode };
  }
  const cfg = kpi.ytd || {};
  const annual = (typeof cfg.annualTarget === "number") ? cfg.annualTarget : null;
  if (annual === null) return null;
  const w = ytdWeights(kpi);
  let share = 0;
  for (let q = 1; q <= uptoQ; q++) share += w[q - 1];
  return { value: annual * share, share, annual, source: "verteilt", mode };
}

/* Jahresziel des laufenden Jahres = Planwert Q4; sonst ytd.annualTarget. */
function ytdAnnualTarget(kpi, year) {
  const pv = pathValueAt(kpi, `${year}-Q4`);
  if (typeof pv === "number") return { value: pv, source: "pfad", label: `${fmtNum(pv)} ${kpi.unit}` };
  const cfg = kpi.ytd || {};
  if (typeof cfg.annualTarget === "number") {
    return { value: cfg.annualTarget, source: "deklariert", label: cfg.annualTargetLabel || `${fmtNum(cfg.annualTarget)} ${kpi.unit}` };
  }
  return null;
}

/* YTD-Fortschritt; null ohne ytd-Konfiguration oder ohne Ist im Jahr. */
function ytdProgress(kpi) {
  if (!kpi.ytd) return null;
  const cur = effKpi(kpi).current;
  const qp = quarterOf(cur.label);
  if (!qp) return null;
  const act = ytdActual(kpi.id, qp.year, qp.q);
  if (act.value === null) return null;
  const tgt = ytdTarget(kpi, qp.q, qp.year);
  if (!tgt) return null;
  const annual = ytdAnnualTarget(kpi, qp.year);
  const delta = act.value - tgt.value;
  const tol = Math.abs(tgt.value) * 0.05;
  let status;
  if (kpi.direction === "up") status = delta >= 0 ? "green" : (delta >= -tol ? "amber" : "red");
  else status = delta <= 0 ? "green" : (delta <= tol ? "amber" : "red");
  return {
    year: qp.year, quarter: qp.q, actual: act.value, target: tgt.value,
    mode: act.mode, targetSource: tgt.source,
    annual: annual ? annual.value : null, annualSource: annual ? annual.source : null,
    annualLabel: annual ? annual.label : null,
    delta, status,
    quarters: act.quarters, missing: act.missing,
    linear: !Array.isArray((kpi.ytd || {}).weights)
  };
}

function yearOf(label) {
  if (!label) return null;
  const m = String(label).match(/(19|20)\d{2}/);
  if (!m) return null;
  let y = parseInt(m[0], 10);
  if (/mitte/i.test(label)) y += 0.5;
  if (/q1/i.test(label)) y += 0.25;
  if (/q3/i.test(label)) y += 0.75;
  return y;
}

/* ---------- Status gegen den Plan ----------
   Verglichen wird der Ist-Wert mit dem Planwert derselben Periode,
   nicht mit dem Endziel. So gilt ein geplanter Anstieg (Kostenquote
   13,5 → 14,3) nicht als Abweichung. `direction` gibt die gute Seite an. */
/* Eckwerte (Basis, Ziel 2028, Ziel 2031); ohne Zahl fallen sie weg.
   Die Basis liegt in baseline.period, sonst am Ende ihres Jahres. */
function anchorsOf(kpi) {
  const out = [];
  const b = kpi.baseline || {};
  const by = yearOf(b.label);
  if (typeof b.value === "number" && (b.period || by !== null)) {
    out.push({ period: b.period || `${Math.floor(by)}-Q4`, value: b.value, source: "basis" });
  }
  const t28 = kpi.target2028 || {};
  if (typeof t28.value === "number") {
    out.push({ period: "2028-Q4", value: t28.value, source: "ziel2028" });
  }
  const t31 = kpi.target2031 || {};
  if (typeof t31.value === "number") {
    out.push({ period: "2031-Q4", value: t31.value, source: "ziel2031" });
  }
  return out;
}

/* Hinterlegte Planwerte einzelner Quartale (nur Konzernergebnis) */
function documentedPathOf(kpiId) {
  const d = (typeof KPI_DATA !== "undefined" && KPI_DATA[kpiId]) ? KPI_DATA[kpiId] : null;
  return (d && d.documentedPath) || {};
}

/* Kumulierte KPIs: Quartale ohne hinterlegten Wert saisonal verteilen. */
function pathOptsOf(kpi) {
  return { cumulative: !!(kpi.ytd && kpi.ytd.mode === "kumuliert") };
}

/* Plan über den gesamten Horizont */
function derivedPathOf(kpi, opts) {
  if (typeof PathDerive === "undefined") return [];
  const periods = (typeof PATH_PERIODS !== "undefined") ? PATH_PERIODS : [];
  return PathDerive.derivePath(periods, anchorsOf(kpi), documentedPathOf(kpi.id), opts || pathOptsOf(kpi));
}

/* Planwert einer Periode, aus dem effektiven KPI (inkl. Korrekturen) */
function pathValueAt(kpi, period) {
  if (!kpi || typeof PathDerive === "undefined") return null;
  return PathDerive.pathValueAt(
    [period], anchorsOf(kpi), documentedPathOf(kpi.id), period, pathOptsOf(kpi));
}

/* Erwarteter Wert: Planwert der Periode, sonst lineare Interpolation
   Basis → nächstes Ziel. */
function expectedValue(k) {
  const c = k.current.value;
  if (typeof c !== "number") return null;
  const period = k.current.label;
  if (period && /^\d{4}-Q[1-4]$/.test(period)) {
    const pv = pathValueAt(k, period);
    if (pv !== null) return pv;
  }
  const b = k.baseline.value;
  const by = yearOf(k.baseline.label), cy = yearOf(period);
  if (typeof b !== "number" || by === null || cy === null || cy <= by) return null;
  const cands = [];
  if (k.target2028 && typeof k.target2028.value === "number") cands.push({ v: k.target2028.value, y: 2028 });
  if (k.target2031 && typeof k.target2031.value === "number") cands.push({ v: k.target2031.value, y: 2031 });
  if (!cands.length) return null;
  cands.sort((a, x) => a.y - x.y);
  const t = cands.find(x => x.y >= cy) || cands[cands.length - 1];
  if (t.y <= by) return null;
  return b + (t.v - b) * (cy - by) / (t.y - by);
}

function computeStatus(k) {
  const c = k.current.value;
  const expected = expectedValue(k);
  if (typeof c !== "number" || expected === null) return null;
  /* Toleranz 5 % des Planwerts, bei Raten mindestens 0,05. */
  const tol = isRateUnit(k.unit)
    ? Math.max(Math.abs(expected) * 0.05, 0.05)
    : Math.abs(expected) * 0.05;
  if (k.direction === "up") {
    if (c >= expected) return "green";
    if (c >= expected - tol) return "amber";
    return "red";
  }
  if (c <= expected) return "green";
  if (c <= expected + tol) return "amber";
  return "red";
}

/* Abweichung vom Planwert: bei Raten (%, Punkte, Note, Index) absolut,
   bei Niveaus (Mio. EUR, Tage …) relativ. */
function isRateUnit(unit) {
  return /%|pp|Punkte|Note|Index/i.test(String(unit || ""));
}

/* Einheit ohne Klammerzusatz; „pp vs. Markt" → „pp". */
function devUnit(unit) {
  return String(unit || "").replace(/\s*\(.*?\)/g, "").replace(/\s+vs\..*$/i, "").trim();
}

/* Einheit einer Differenz: bei Prozent-Kennzahlen Prozentpunkte. */
function gapUnit(unit) {
  const u = devUnit(unit);
  return u.startsWith("%") ? "pp" : u;
}

function deviationInfo(k) {
  const kpi = effKpi(k);
  /* YTD-KPIs: Abweichung des kumulierten Ist vom anteiligen Plan */
  const ytd = ytdProgress(kpi);
  if (ytd) {
    const sign = ytd.delta > 0 ? "+" : "−";
    const pct = ytd.target ? Math.abs(ytd.delta) / Math.abs(ytd.target) * 100 : 0;
    if (Math.abs(pct) < 0.05) return null;
    return {
      text: `${sign}${pct.toLocaleString("de-DE", { maximumFractionDigits: 1 })} % vs. ${ytd.targetSource === "pfad" ? "Zielpfad" : "anteiliges Ziel"}`,
      delta: ytd.delta, ytd: true
    };
  }
  const c = kpi.current.value;
  const expected = expectedValue(kpi);
  if (typeof c !== "number" || expected === null) return null;
  const delta = c - expected;
  if (Math.abs(delta) < 1e-9) return null;
  const sign = delta > 0 ? "+" : "−";
  if (isRateUnit(kpi.unit)) {
    const abs = Math.abs(delta);
    if (abs < 0.05) return null;
    /* Raten mit einer Nachkommastelle */
    const n = abs.toLocaleString("de-DE", { maximumFractionDigits: 1 });
    const unit = gapUnit(kpi.unit) === "Punkte" && n === "1" ? "Punkt" : gapUnit(kpi.unit);
    return { text: `${sign}${n} ${unit} vs. Pfad`, delta };
  }
  if (expected === 0) return null;
  const pct = delta / Math.abs(expected) * 100;
  if (Math.abs(pct) < 0.05) return null;
  return { text: `${sign}${Math.abs(pct).toLocaleString("de-DE", { maximumFractionDigits: 1 })} % vs. Pfad`, delta };
}

/* Status gegen Untergrenze (Solvenz) */
function computeGuardrailStatus(k) {
  const c = k.current.value;
  if (typeof c !== "number") return null;
  if (c >= 200) return "green";
  if (c >= 175) return "amber";
  return "red";
}

function resolve(k) {
  const kpi = effKpi(k);
  let status = kpi.status, computed = false;
  /* KPIs mit YTD-Messung: Status aus dem kumulierten Vergleich */
  const ytd = ytdProgress(kpi);
  if (ytd) return { kpi, status: ytd.status, computed: true, ytd };
  /* Status wird berechnet, sobald ein Planwert vorliegt. */
  const s = kpi.guardrail ? computeGuardrailStatus(kpi) : computeStatus(kpi);
  if (s) { status = s; computed = true; }
  return { kpi, status, computed };
}

/* ---------- Zwei Arten von Status ----------
   Leistung: Auf Kurs / Beobachten / Handlungsbedarf (nur mit Plan).
   Verfügbarkeit: Auszuwerten / Zu entwickeln (Messung fehlt). */
function statusKind(k) {
  return ["green", "amber", "red"].includes(resolve(k).status) ? "perf" : "avail";
}

/* ---------- Werte anzeigen ---------- */
function targetDisplay(t) {
  if (!t) return `<span class="tbd-text">TBD</span>`;
  const txt = t.text == null ? "" : String(t.text).trim();
  if (!txt) {
    if (typeof t.value === "number") return `<b>${fmtNum(t.value)}</b>`;
    return `<span class="tbd-text">TBD</span>`;
  }
  if (txt === "TBD") return `<span class="tbd-text">TBD</span>`;
  if (txt.startsWith("TBD")) return `<span class="tbd-text">${esc(txt)}</span>`;
  return `<b>${esc(txt)}</b>`;
}

function currentDisplay(kpi) {
  const v = kpi.current.value;
  if (v === null || v === undefined) return `<span class="tbd-text">—</span>`;
  return `<b>${fmtNum(v)}</b><span class="knode-val-unit">${esc(kpi.unit)}</span>`;
}

/* ---------- Verlauf gegen Plan ----------
   Ist durchgezogen, Plan gestrichelt. */
function seriesOf(kpiId) {
  if (typeof KPI_DATA === "undefined" || !KPI_DATA[kpiId]) return null;
  const d = KPI_DATA[kpiId];
  const pts = [];
  (d.series || []).forEach(s => {
    if (typeof s.value === "number") pts.push({ period: s.period, value: s.value, actual: !!s.isActual });
  });
  if (pts.length < 2) return null;
  const kpi = effKpi(kpiById(kpiId));
  const path = chartPathOf(kpi);
  return { pts, path };
}

/* Planpunkte für die Liniencharts */
function chartPathOf(kpi) {
  return derivedPathOf(kpi, {})
    .filter(r => typeof r.value === "number")
    .map(r => ({ period: r.period, value: r.value, source: r.source }));
}

/* ---------- Hochrechnung kumulierter KPIs ----------
   Jedes Quartal wird auf das Jahr hochgerechnet: YTD ÷ geplanter
   Jahresanteil (ui_logic.js). Vor Planbeginn gibt es keine
   Phasierung; dort steht nur das Jahresergebnis. */
function annualizedActuals(kpi) {
  const doc = documentedPathOf(kpi.id);
  const w = PathDerive.deriveSeasonalWeights(doc);
  return actualPoints(kpi.id).map(p => {
    const qp = quarterOf(p.period);
    if (!qp) return null;
    const v = UiLogic.annualizeYtd(p.value, UiLogic.phasingShare(doc, Number(qp.year), qp.q, w));
    return v === null ? null : { period: p.period, value: v, ytd: p.value, year: qp.year, q: qp.q };
  }).filter(Boolean);
}

/* Ist-Wert für die Anzeige; kumulierte KPIs hochgerechnet, YTD darunter */
function istView(k) {
  const kpi = effKpi(k);
  if (pathOptsOf(kpi).cumulative) {
    const last = annualizedActuals(kpi).pop();
    if (last) {
      const sub = last.q === 4
        ? `Geschäftsjahr ${last.year}`
        : `Hochrechnung ${last.year} · YTD ${fmtNum(last.ytd)} (Q${last.q})`;
      return { value: last.value, html: `<b>${fmtNum(Math.round(last.value * 10) / 10)}</b><span class="knode-val-unit">${esc(kpi.unit)}</span>`, sub, last };
    }
  }
  return { value: kpi.current.value, html: currentDisplay(kpi), sub: kpi.current.label || "", last: null };
}

/* Planlinie als getrennte Segmente je `seg`, sonst eine Linie */
function planPolylines(path, toXY) {
  const groups = new Map();
  path.forEach(p => {
    const key = p.seg === undefined ? "_" : p.seg;
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(toXY(p));
  });
  return [...groups.values()].filter(g => g.length >= 2).map(g => g.map(q => q.join(",")).join(" "));
}

/* Datenpunkte für die Charts: Serie plus erfasste Ist-Werte */
function chartSeries(kpi) {
  /* Kumulierte KPIs: Ist hochgerechnet, Plan als Jahresziel je Jahr */
  if (pathOptsOf(kpi).cumulative) {
    const eff = effKpi(kpiById(kpi.id));
    const ist = annualizedActuals(eff);
    if (!ist.length) return null;
    const startYear = Number(ist[0].year) + (ist[0].q === 4 ? 1 : 0);
    const path = [];
    for (let y = startYear; y <= 2031; y++) {
      const v = pathValueAt(eff, `${y}-Q4`);
      if (typeof v !== "number") continue;
      path.push({ period: `${y}-Q1`, value: v, seg: y }, { period: `${y}-Q4`, value: v, seg: y });
    }
    return { pts: ist.map(p => ({ period: p.period, value: p.value, actual: true })), path, annualized: true };
  }
  const s = seriesOf(kpi.id);
  const act = actualPoints(kpi.id);
  if (!s && act.length < 2) return null;
  const path = s ? s.path : chartPathOf(effKpi(kpiById(kpi.id)));
  const byP = {};
  (s ? s.pts : []).forEach(p => { byP[p.period] = p; });
  act.forEach(p => { byP[p.period] = { period: p.period, value: p.value, actual: true }; });
  return { pts: Object.keys(byP).sort().map(k => byP[k]), path };
}

function sparkline(kpi, status, opts = {}) {
  const act = actualPoints(kpi.id);
  if (act.length === 1) return `<span class="spark-empty">erste Messung ${esc(act[0].period)}</span>`;
  const data = chartSeries(kpi);
  const hasActual = data && data.pts.some(p => p.actual);
  if (!data || !hasActual) {
    const why = kpi.maturity === "zu-entwickeln" ? "Nullmessung/Methodik ausstehend"
      : kpi.maturity === "auszuwerten" ? "Auswertung ausstehend" : "keine Daten";
    return `<div class="spark-empty">Kein Verlauf — ${why}</div>`;
  }
  let { pts: raw, path } = data;
  const st = status || kpi.status;
  const W = 220, H = 38, pad = 4;
  /* Tabellen-Sparkline: Fenster bis zum nächsten Zieljahr */
  if (opts.window) {
    let axis = [];
    raw.forEach(p => { if (!axis.includes(p.period)) axis.push(p.period); });
    path.forEach(p => { if (!axis.includes(p.period)) axis.push(p.period); });
    axis.sort();
    const lastAct = raw.filter(p => p.actual).map(p => p.period).sort().pop();
    const start = Math.max(0, axis.indexOf(lastAct) - 7);
    const end = lastAct < "2028-Q4" ? "2028-Q4" : "2031-Q4";
    const windowAxis = axis.slice(start).filter(p => p <= end);
    raw = raw.filter(p => windowAxis.includes(p.period));
    path = path.filter(p => windowAxis.includes(p.period));
  }
  /* x-Position nach Zeit, nicht nach Index */
  const yfOf = p => PathDerive.periodToYearFraction(p);
  const allYf = raw.map(p => yfOf(p.period)).concat(path.map(p => yfOf(p.period)));
  const minYf = Math.min(...allYf), maxYf = Math.max(...allYf);
  const yfSpan = (maxYf - minYf) || 1;
  const xAt = period => pad + ((yfOf(period) - minYf) / yfSpan) * (W - 2 * pad);
  const all = raw.map(p => p.value).concat(path.map(p => p.value));
  const min = Math.min(...all), max = Math.max(...all);
  const span = (max - min) || 1;
  const yAt = v => H - pad - ((v - min) / span) * (H - 2 * pad);
  const pts = raw.map(p => [xAt(p.period), yAt(p.value)]);
  /* Ist-Linie endet am letzten gemessenen Wert. */
  const lastActualIdx = raw.reduce((acc, p, i) => p.actual ? i : acc, -1);
  const actualPts = pts.slice(0, lastActualIdx + 1);
  const line = actualPts.map(p => p.join(",")).join(" ");
  const color = cssVar("--navy");
  const last = actualPts[actualPts.length - 1] || pts[pts.length - 1];
  const unit = String(kpi.unit || "").replace(/"/g, "&quot;");
  const planLines = planPolylines(path, p => [xAt(p.period), yAt(p.value)]);
  return `
    <svg class="spark" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" aria-hidden="true"
         data-points='${JSON.stringify(pts)}' data-values='${JSON.stringify(raw.map(p => p.value))}'
         data-periods='${JSON.stringify(raw.map(p => p.period))}' data-unit="${unit}">
      ${planLines.map(l => `<polyline points="${l}" fill="none" stroke="${cssVar("--grey-3")}" stroke-width="1.5" stroke-dasharray="4 3" vector-effect="non-scaling-stroke"></polyline>`).join("")}
      <polyline points="${line}" fill="none" stroke="${color}" stroke-width="2" stroke-linejoin="round" stroke-linecap="round" vector-effect="non-scaling-stroke"></polyline>
      <circle cx="${last[0]}" cy="${last[1]}" r="2.6" fill="${color}" vector-effect="non-scaling-stroke"></circle>
      <line class="spark-crosshair" x1="0" y1="0" x2="0" y2="${H}" style="display:none"></line>
      <circle class="spark-hover-dot" cx="0" cy="0" r="4" fill="${color}" style="display:none"></circle>
      <rect class="spark-hit" x="0" y="0" width="${W}" height="${H}" fill="transparent" pointer-events="all"></rect>
    </svg>`;
}

/* ---------- Detail-Chart (Modal) ----------
   Wie die Sparkline, zusätzlich Jahreszahlen und drei Werte an der
   y-Achse; kein Gitter. */
function detailChart(kpi, status) {
  const data = chartSeries(kpi);
  const hasActual = data && data.pts.some(p => p.actual);
  if (!data || !hasActual) {
    const why = kpi.maturity === "zu-entwickeln" ? "Nullmessung/Methodik ausstehend"
      : kpi.maturity === "auszuwerten" ? "Auswertung ausstehend" : "keine Daten";
    return `<div class="spark-empty">Kein Verlauf — ${why}</div>`;
  }
  const { pts: raw, path, annualized } = data;
  const limit = CHART_FULL ? "2031-Q4" : "2028-Q4";
  const pathW = path.filter(p => p.period <= limit);
  const st = status || kpi.status;
  const W = 720, H = 260;
  const padL = 62, padR = 16, padT = 18, padB = 46;
  const iw = W - padL - padR, ih = H - padT - padB;
  const all = raw.map(p => p.value).concat(pathW.map(p => p.value));
  let min = Math.min(...all), max = Math.max(...all);
  if (min === max) { min -= 1; max += 1; }
  const pad = (max - min) * 0.08;
  min -= pad; max += pad;
  const span = max - min;
  /* x-Position nach Zeit, nicht nach Index */
  const yfOf = p => PathDerive.periodToYearFraction(p);
  const allYf = raw.map(p => yfOf(p.period)).concat(pathW.map(p => yfOf(p.period)));
  const minYf = Math.min(...allYf), maxYf = Math.max(...allYf);
  const yfSpan = (maxYf - minYf) || 1;
  const xAt = period => padL + (allYf.length <= 1 ? iw / 2 : ((yfOf(period) - minYf) / yfSpan) * iw);
  const yAt = v => padT + ih - ((v - min) / span) * ih;
  const pts = raw.map(p => [xAt(p.period), yAt(p.value)]);
  const color = cssVar("--navy");

  /* y-Achse: drei Beschriftungen, Nachkommastellen nach Spanne */
  const dec = span >= 20 ? 0 : span >= 2 ? 1 : 2;
  const ticks = [];
  for (let t = 0; t <= 2; t++) {
    const v = min + span * (t / 2);
    const y = yAt(v);
    ticks.push(`<text class="dc-ytick" x="${padL - 8}" y="${(y + 3.5).toFixed(1)}" text-anchor="end">${fmtNum(Number(v.toFixed(dec)))}</text>`);
  }

  /* x-Achse: Jahreszahl am Jahresanfang (am linken Rand, falls davor) */
  const xLabels = [];
  for (let y = Math.floor(minYf); y <= Math.floor(maxYf); y++) {
    const x = y < minYf ? padL : padL + ((y - minYf) / yfSpan) * iw;
    xLabels.push(`<text class="dc-xtick" x="${x.toFixed(1)}" y="${H - padB + 18}" text-anchor="${y < minYf ? "start" : "middle"}">${y}</text>`);
  }

  /* Planlinie gestrichelt; bei der Hochrechnung ein Segment je Jahr */
  const planLines = planPolylines(pathW, p => [xAt(p.period), yAt(p.value)]);
  /* Ist-Linie endet am letzten gemessenen Wert. */
  const lastActualIdx = raw.reduce((acc, p, i) => p.actual ? i : acc, -1);
  const actualPts = pts.slice(0, lastActualIdx + 1);
  const actualLine = actualPts.map(p => p.join(",")).join(" ");
  const last = actualPts[actualPts.length - 1] || pts[pts.length - 1];

  return `
  <div class="detail-chart">
    <svg class="dchart" viewBox="0 0 ${W} ${H}" preserveAspectRatio="xMidYMid meet" role="img"
         aria-label="Verlauf ${esc(kpi.name)}: Ist durchgezogen, Plan gestrichelt"
         data-points='${JSON.stringify(pts)}' data-values='${JSON.stringify(raw.map(p => p.value))}'
         data-periods='${JSON.stringify(raw.map(p => p.period))}' data-unit="${esc(kpi.unit)}">
      ${ticks.join("")}
      <line class="dc-axis" x1="${padL}" y1="${padT + ih}" x2="${W - padR}" y2="${padT + ih}"></line>
      ${planLines.map(l => `<polyline class="dc-plan" points="${l}" fill="none" stroke="${cssVar("--grey-3")}" stroke-width="2" stroke-dasharray="6 4" vector-effect="non-scaling-stroke"></polyline>`).join("")}
      <polyline class="dc-ist" points="${actualLine}" fill="none" stroke="${color}" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round" vector-effect="non-scaling-stroke"></polyline>
      ${actualPts.map((p, i) => `<circle class="dc-dot" cx="${p[0].toFixed(1)}" cy="${p[1].toFixed(1)}" r="3" fill="${color}" vector-effect="non-scaling-stroke"></circle>`).join("")}
      <circle class="dc-last" cx="${last[0].toFixed(1)}" cy="${last[1].toFixed(1)}" r="4.5" fill="${color}" vector-effect="non-scaling-stroke"></circle>
      ${xLabels.join("")}
      <text class="dc-unit" x="${padL - 8}" y="${padT - 6}" text-anchor="end">${esc(kpi.unit)}</text>
      <line class="spark-crosshair" x1="0" y1="${padT}" x2="0" y2="${padT + ih}" style="display:none"></line>
      <circle class="spark-hover-dot" cx="0" cy="0" r="5" fill="${color}" style="display:none"></circle>
      <rect class="spark-hit" x="${padL}" y="${padT}" width="${iw}" height="${ih}" fill="transparent" pointer-events="all"></rect>
    </svg>
    <div class="spark-legend">
      <span class="sl-ist">${annualized ? "Ist: Hochrechnung auf 12 Monate (YTD ÷ Planphasierung; Q4 = Jahresergebnis)" : "Ist (durchgezogen)"}</span>
      <span class="sl-path">${annualized ? "Plan: Jahresziel (gestrichelt)" : "Plan (gestrichelt)"}</span>
    </div>
  </div>`;
}

/* ---------- KPI-Karte ----------
   Status oder Verfügbarkeit, Verlauf gegen Plan; per Tastatur bedienbar. */
/* Zeile zur kumulierten Messung: Jahresziel und YTD-Fortschritt */
function ytdBlock(kpi, ytd) {
  if (!ytd) return "";
  const pct = ytd.target ? Math.round(ytd.actual / ytd.target * 100) : 0;
  const barW = Math.max(0, Math.min(100, pct));
  const missing = ytd.missing.length
    ? `<span class="ytd-missing">${ytd.missing.length} Quartal${ytd.missing.length === 1 ? "" : "e"} ohne Ist</span>` : "";
  /* Kumulierte KPIs: YTD ist der letzte Wert, keine Summe. */
  const kum = ytd.mode === "kumuliert";
  const ytdLabel = kum ? `Stand ${esc(ytd.year)} (bis Q${ytd.quarter})` : `YTD ${esc(ytd.year)} (bis Q${ytd.quarter})`;
  const targetLabel = ytd.targetSource === "pfad"
    ? `Zielpfad ${esc(ytd.year)} (bis Q${ytd.quarter})`
    : `anteiliges Ziel (${Math.round((ytd.share || 0) * 100)} %)`;
  const modeNote = ytd.targetSource === "pfad"
    ? `<span class="ytd-mode">gegen Zielpfad</span>`
    : `<span class="ytd-mode">${ytd.linear ? "linear verteilt" : "saisonal gewichtet"}</span>`;
  return `
  <div class="knode-annual">
    <span class="knode-annual-label">Jahresziel ${esc(ytd.year)}</span>
    <span class="knode-annual-val">${esc(ytd.annualLabel || fmtNum(ytd.annual))}</span>
  </div>
  <div class="knode-ytd">
    <div class="ytd-row">
      <span class="ytd-label">${ytdLabel}</span>
      <span class="ytd-val"><b>${fmtNum(ytd.actual)}</b> ${esc(kpi.unit)}</span>
    </div>
    <div class="ytd-row ytd-row-target">
      <span class="ytd-label">${targetLabel}</span>
      <span class="ytd-val">${fmtNum(ytd.target)} ${esc(kpi.unit)}</span>
    </div>
    <div class="ytd-bar" role="img" aria-label="${pct} % des ${ytd.targetSource === "pfad" ? "Zielpfads" : "anteiligen Jahresziels"} erreicht">
      <span class="ytd-bar-fill ${ytd.status}" style="width:${barW}%"></span>
    </div>
    <div class="ytd-foot">
      <span class="ytd-pct">${pct} % ${ytd.targetSource === "pfad" ? "des Zielpfads" : "des anteiligen Ziels"}</span>
      ${modeNote}
      ${missing}
    </div>
  </div>`;
}

function kpiCard(k, opts = {}) {
  const { kpi, ytd } = resolve(k);
  const s = statusKey(k);
  const kind = statusKind(k);
  const edited = hasEdits(k.id) || hasEnteredValues(k.id);
  const cls = [
    "knode",
    s,
    kind === "avail" ? "knode-avail" : "",
    opts.hero ? "knode-hero" : "",
    opts.row1 ? "knode-row1" : "",
    opts.compact ? "knode-compact" : ""
  ].filter(Boolean).join(" ");
  const pathNote = kpi.pathNote ? `<div class="knode-pathnote">${esc(kpi.pathNote)}</div>` : "";
  const interim = kpi.interim ? kpiById(kpi.interim) : null;
  const interimNote = interim
    ? `<div class="knode-interim">Interim: <button class="kpi-link" data-kpi-link="${interim.id}">${esc(interim.name)} →</button></div>`
    : "";
  return `
  <div class="${cls}" data-kpi="${k.id}" tabindex="0" role="button"
       aria-label="${esc(kpi.name)} — ${esc(statusLabel(s))}. Details öffnen.">
    <div class="knode-head">
      <span class="knode-name">${esc(kpi.name)}</span>
      ${edited ? editedChip(k) : ""}
      ${statusBadge(k)}
    </div>
    ${ytdBlock(kpi, ytd)}
    <div class="knode-values">
      <div class="knode-val">
        <div class="knode-val-label">Ist</div>
        <div class="knode-val-value">${currentDisplay(kpi)}</div>
        <div class="knode-val-sub">${esc(kpi.current.label || "")}</div>
      </div>
      <div class="knode-val">
        <div class="knode-val-label">Ziel 2028</div>
        <div class="knode-val-value">${targetDisplay(kpi.target2028)}</div>
      </div>
      <div class="knode-val">
        <div class="knode-val-label">Ziel 2031</div>
        <div class="knode-val-value">${targetDisplay(kpi.target2031)}</div>
      </div>
    </div>
    <div class="knode-spark">${sparkline(kpi, s)}</div>
    ${pathNote}
    ${interimNote}
  </div>`;
}

/* ---------- Veränderung zur Vorperiode ---------- */
function actualPoints(kpiId) {
  const byP = {};
  const d = (typeof KPI_DATA !== "undefined" && KPI_DATA[kpiId]) ? KPI_DATA[kpiId] : null;
  ((d && d.series) || []).forEach(s => { if (s.isActual && typeof s.value === "number") byP[s.period] = s.value; });
  PERIODS.forEach(p => { const e = getEnteredValue(kpiId, p); if (e && typeof e.value === "number") byP[p] = e.value; });
  return Object.keys(byP).sort().map(p => ({ period: p, value: byP[p] }));
}

function deltaOf(k) {
  /* Kumulierte KPIs: aufeinanderfolgende Hochrechnungen vergleichen */
  const cumulative = ytdMode(k) === "kumuliert";
  const pts = cumulative ? annualizedActuals(effKpi(k)) : actualPoints(k.id);
  if (pts.length < 2) return null;
  const last = pts[pts.length - 1];
  const prev = pts[pts.length - 2];
  const d = UiLogic.periodDelta(last.value, prev.value, {
    isRate: isRateUnit(k.unit),
    unitLabel: /%/.test(k.unit || "") ? "pp" : devUnit(k.unit),
    direction: k.direction
  });
  if (!d) return null;
  d.against = cumulative ? `${prev.period} (hochgerechnet)` : prev.period;
  return d;
}

function deltaHtml(k) {
  const d = deltaOf(k);
  if (!d) return `<span class="delta delta-none">—</span>`;
  const cls = d.good === null ? "" : (d.good ? "delta-good" : "delta-bad");
  const arrow = d.delta > 0 ? "▲" : d.delta < 0 ? "▼" : "";
  return `<span class="delta ${cls}" title="gegenüber ${esc(d.against)}">${arrow ? `<span aria-hidden="true">${arrow}</span> ` : ""}${esc(d.text)}<span class="sr-only"> gegenüber ${esc(d.against)}</span></span>`;
}

function devShort(text) {
  return String(text || "").replace(" vs. Pfad", "").replace(" vs. anteiliges Ziel", "").replace(" vs. Zielpfad", "");
}

/* „auf Pfad" nur bei Grün; Gelb/Rot ohne angezeigte Abweichung:
   „knapp neben Pfad". */
function pathText(s, dev) {
  if (dev) return devShort(dev.text);
  return s === "green" ? "auf Pfad" : "knapp neben Pfad";
}

/* ---------- Ertragslücke ----------
   Große Zahl = letztes volles Geschäftsjahr (jüngster Q4-Wert),
   sonst DATA.meta. */
function earningsGap() {
  const e = DATA.meta.ertragsziel.hgb;
  const fy = UiLogic.latestFullYear(actualPoints("konzernergebnis"), { value: e.current, year: e.currentLabel });
  return { value: e.target - fy.value, base: fy.value, year: fy.year, target: e.target, targetLabel: e.targetLabel };
}

function earningsBlock() {
  const k = kpiById("konzernergebnis");
  const g = earningsGap();
  const ytd = resolve(k).ytd;
  let bar = "";
  if (ytd && typeof ytd.annual === "number" && ytd.annual > 0) {
    const pct = v => Math.max(0, Math.min(100, v / ytd.annual * 100));
    const rest = Math.round((ytd.annual - ytd.actual) * 10) / 10;
    const dev = deviationInfo(k);
    bar = `
    <div class="earn-ytd">
      <div class="earn-ytd-line">
        <span>${esc(ytd.year)} bis Q${ytd.quarter}: <b>${fmtNum(ytd.actual)}</b> von ${fmtNum(ytd.annual)} Mio. EUR Jahresziel (Planannahme)</span>
        <span class="earn-ytd-rest">noch ${fmtNum(rest)}</span>
      </div>
      ${(() => {
        const iv = istView(k);
        return iv.last && iv.last.q !== 4 && iv.last.year === String(ytd.year)
          ? `<div class="earn-proj">Hochrechnung ${esc(ytd.year)}: <b>${fmtNum(Math.round(iv.value * 10) / 10)}</b> von ${fmtNum(ytd.annual)} Mio. EUR</div>`
          : "";
      })()}
      <div class="earn-bar" role="img" aria-label="${fmtNum(ytd.actual)} von ${fmtNum(ytd.annual)} Mio. EUR erreicht; Zielpfad bis Q${ytd.quarter}: ${fmtNum(ytd.target)}">
        <span class="earn-bar-fill" style="width:${pct(ytd.actual).toFixed(1)}%"></span>
        <span class="earn-bar-tick" style="left:${pct(ytd.target).toFixed(1)}%"></span>
      </div>
      <div class="earn-ytd-foot">Strich = Zielpfad bis Q${ytd.quarter} (${fmtNum(ytd.target)}) · <span class="dev-${ytd.status}">${esc(pathText(ytd.status, dev))}</span></div>
    </div>`;
  }
  return `
  <div class="earnings" data-kpi="konzernergebnis" tabindex="0" role="button" aria-label="Konzernergebnis — Details öffnen">
    <div class="strip-label">Konzernergebnis HGB ${esc(g.year)}</div>
    <div class="earn-main"><span class="earn-val">${fmtNum(g.base)}</span><span class="earn-unit">Mio. EUR</span></div>
    <div class="earn-gap">Lücke zum Ziel 2031 (${esc(String(g.targetLabel).replace(/\s*\(2031\)/, ""))}): <b>${fmtNum(Math.round(g.value * 10) / 10)} Mio. EUR</b></div>
    ${bar}
  </div>`;
}

/* ---------- Urteil und Ertrag ---------- */
function statusStrip() {
  const all = [...DATA.finance, ...DATA.central, ...DATA.drivers];
  const perf = all.filter(k => statusKind(k) === "perf");
  const n = s => perf.filter(k => statusKey(k) === s).length;
  const red = n("red"), amber = n("amber"), green = n("green");
  const worst = red ? "red" : amber ? "amber" : "green";
  const head = { red: "Handlungsbedarf", amber: "Beobachten", green: "Auf Kurs" }[worst];
  const parts = [];
  if (red) parts.push(`<b class="t-red">${red}</b> mit Handlungsbedarf`);
  if (amber) parts.push(`<b>${amber}</b> beobachten`);
  if (green) parts.push(`<b>${green}</b> auf Kurs`);
  return `
  <section class="status-strip" id="status-strip">
    <div class="strip-verdict">
      <div class="strip-label">Urteil · Stand ${esc(DATA.meta.asOf)}</div>
      <div class="strip-head"><span class="rag-dot ${worst}" aria-hidden="true"></span>${head}</div>
      <p class="strip-counts">Von ${perf.length} bewerteten Kennzahlen: ${parts.join(" · ")}.</p>
      <p class="strip-base">${all.length - perf.length} der ${all.length} Steuerungskennzahlen noch nicht messbar (+ ${DATA.suggestions.length} Vorschläge).</p>
    </div>
    ${earningsBlock()}
  </section>`;
}

/* ---------- Abweichungen und Maßnahmen ----------
   Kennzahl, Abweichung, Maßnahme, Owner, Frist. Die Ursache steht
   im Modal. Abweichungen ohne Maßnahme bleiben sichtbar. */
function actionsSection() {
  const chain = [...DATA.finance, ...DATA.central, ...DATA.drivers];
  const flagged = UiLogic.sortFlagged(
    chain.filter(k => ["amber", "red"].includes(statusKey(k))).map(k => ({ k, s: statusKey(k) })));
  const actionsByKpi = {};
  DATA.actions.forEach(a => { actionsByKpi[a.kpi] = a; });
  const openCount = flagged.filter(({ k }) => !actionsByKpi[k.id]).length;
  const rows = flagged.map(({ k, s }) => {
    const a = actionsByKpi[k.id];
    const r = resolve(k);
    const dev = deviationInfo(k);
    /* Kumulierte KPIs: Ist = Wert, gegen den die Abweichung gerechnet ist */
    const istVal = r.ytd ? r.ytd.actual : r.kpi.current.value;
    const istLbl = r.ytd ? `${r.ytd.mode === "kumuliert" ? "Stand" : "YTD"} ${r.ytd.year}` : (r.kpi.current.label || "");
    return `
    <tr class="act-row" data-kpi="${k.id}" tabindex="0" role="button" aria-label="${esc(k.name)} — ${esc(statusLabel(s))}. Details öffnen.">
      <td class="kr-name"><span class="rag-dot ${s}" aria-hidden="true"></span>${esc(k.name)}<span class="sr-only"> — ${esc(statusLabel(s))}</span></td>
      <td class="num kr-ist">${(() => {
        /* Kumulierte KPIs: hochgerechnet, YTD darunter */
        const iv = istView(k);
        return iv.last
          ? `<b>${fmtNum(Math.round(iv.value * 10) / 10)}</b> <span class="unit">${esc(devUnit(r.kpi.unit))}</span><span class="kr-period">${esc(iv.sub)}</span>`
          : `<b>${fmtNum(istVal)}</b> <span class="unit">${esc(devUnit(r.kpi.unit))}</span><span class="kr-period">${esc(istLbl)}</span>`;
      })()}</td>
      <td class="num dev-${s}">${esc(pathText(s, dev))}</td>
      <td class="num">${deltaHtml(k)}</td>
      <td class="act-massnahme">${a ? esc(a.massnahme) : `<span class="missing-action">Keine Maßnahme</span>`}</td>
      <td>${a ? esc(a.owner) : ""}</td>
      <td class="act-frist">${a ? esc(a.frist) : ""}</td>
    </tr>`;
  });
  return `
  <section class="section actions-section" id="actions-section">
    <h2 class="section-title">Wo ist das Problem?</h2>
    <div class="actions-sub">${flagged.length} Abweichungen${openCount ? ` · <b>${openCount} ohne Maßnahme</b>` : " · alle mit Maßnahme"}</div>
    ${flagged.length ? `
    <div class="table-wrap">
      <table class="data kpi-table actions-table">
        <thead><tr><th>Kennzahl</th><th class="num">Ist</th><th class="num">vs. Pfad</th><th class="num">Δ Vorperiode</th><th>Maßnahme</th><th>Owner</th><th>Frist</th></tr></thead>
        <tbody>${rows.join("")}</tbody>
      </table>
    </div>` : `<div class="note-inline">Keine Abweichungen.</div>`}
  </section>`;
}

/* ---------- Zielbausteine ----------
   Ohne eigene Messgröße; Status aus den zugehörigen KPIs. */
function buildingBlockStrip() {
  const chips = DATA.buildingBlocks.map(b => {
    const kpis = b.kpis.map(kpiById).filter(Boolean);
    const perf = kpis.filter(k => statusKind(k) === "perf");
    const worst = perf.some(k => statusKey(k) === "red") ? "red"
      : perf.some(k => statusKey(k) === "amber") ? "amber"
      : perf.length ? "green" : "avail";
    const label = worst === "avail" ? "im Aufbau" : statusLabel(worst);
    return `<span class="bb-chip bb-${worst}" title="${esc(b.name)} — Status aus ${kpis.length} zugehörigen Kennzahlen abgeleitet">
      <span class="bb-dot ${worst}"></span>${esc(b.name)}<span class="bb-state">${esc(label)}</span>
    </span>`;
  }).join("");
  return `
  <div class="bb-strip">
    <span class="bb-strip-label">Zielbausteine</span>
    ${chips}
  </div>`;
}

/* ---------- Reifegrad und Fahrplan ----------
   Wann wird welche Kennzahl messbar? */
function maturityBand() {
  const all = [...DATA.finance, ...DATA.central, ...DATA.drivers, ...DATA.suggestions];
  const counts = { etabliert: 0, auszuwerten: 0, "zu-entwickeln": 0 };
  all.forEach(k => { if (counts[k.maturity] !== undefined) counts[k.maturity]++; });
  const roadmap = DATA.maturityRoadmap.map(m =>
    `<div class="mat-item"><span class="mat-when">${esc(m.when)}</span><span class="mat-what">${esc(m.what)}</span></div>`).join("");
  return `
  <div class="humble-block">
    <div class="humble-head">
      <span class="humble-title">Reifegrad & Instrumentalisierung</span>
      <span class="humble-counts">
        <span><i class="mat-glyph mat-glyph-etabliert"></i>${counts.etabliert} etabliert</span>
        <span><i class="mat-glyph mat-glyph-auszuwerten"></i>${counts.auszuwerten} auszuwerten</span>
        <span><i class="mat-glyph mat-glyph-zu-entwickeln"></i>${counts["zu-entwickeln"]} zu entwickeln</span>
      </span>
    </div>
    <div class="mat-roadmap">${roadmap}</div>
  </div>`;
}

/* ---------- Offene Entscheidungen ---------- */
function openItemsBlock() {
  const items = DATA.openItems.map(o =>
    `<div class="oi-item"><span class="oi-topic">${esc(o.topic)}</span><span class="oi-who">${esc(o.who)}</span><span class="oi-what">${esc(o.what)}</span></div>`).join("");
  return `
  <div class="humble-block">
    <div class="humble-head">
      <span class="humble-title">Offene Entscheidungen</span>
      <span class="humble-counts"><span>${DATA.openItems.length} Punkte</span></span>
    </div>
    <div class="oi-list">${items}</div>
  </div>`;
}

/* ---------- Steuerungsrhythmus ---------- */
function governanceBlock() {
  const rows = DATA.governance.cadences.map(c =>
    `<div class="gov-item"><span class="gov-takt">${esc(c.takt)}</span><span class="gov-name">${esc(c.name)}</span><span class="gov-purpose">${esc(c.purpose)}</span></div>`).join("");
  return `
  <div class="humble-block">
    <div class="humble-head">
      <span class="humble-title">Steuerungsrhythmus</span>
      <span class="humble-counts"><span>nur Abweichungen auf der Tagesordnung</span></span>
    </div>
    <div class="gov-list">${rows}</div>
  </div>`;
}

/* ---------- Vorschläge (nicht im Strategiepapier) ----------
   Eigene Gruppe, getrennt von den Strategie-Kennzahlen. */
/* Zeitplan einer noch nicht messbaren Kennzahl */
function availWhen(k) {
  const short = k.name.replace(/^NÜRNBERGER\s+/, "");
  const m = DATA.maturityRoadmap.find(x => x.what.includes(short));
  return m ? m.when : "";
}

/* Bullet: Ist-Balken, Marke Planwert, Marke Ziel; Werte als
   Datenattribute für den Tooltip. */
function bulletBar(k) {
  const kpi = effKpi(k);
  const ist = kpi.current.value;
  const exp = expectedValue(kpi);
  const t28 = kpi.target2028 && typeof kpi.target2028.value === "number" ? kpi.target2028.value : null;
  const t31 = kpi.target2031 && typeof kpi.target2031.value === "number" ? kpi.target2031.value : null;
  /* Maßstab umfasst beide Zielmarken */
  const vals = [ist, exp, t28, t31].filter(v => typeof v === "number");
  if (typeof ist !== "number" || vals.length < 2) return sparkline(kpi, statusKey(k), { window: true });
  const lo = Math.min(0, ...vals), hi = Math.max(...vals) * 1.1 || 1;
  const W = 150, H = 18;
  const x = v => ((v - lo) / (hi - lo)) * W;
  const unit = String(kpi.unit || "").replace(/"/g, "&quot;");
  const marke = (v, cls, label, y, h, fill) => v === null ? ""
    : `<rect class="bullet-marke ${cls}" x="${(x(v) - 1).toFixed(1)}" y="${y}" width="2" height="${h}"
        fill="${fill}" data-tip="${label}" data-v="${v}"></rect>`;
  const a11y = [
    `Ist ${fmtNum(ist)}`,
    exp !== null ? `Pfad ${fmtNum(Math.round(exp * 100) / 100)}` : null,
    t28 !== null ? `Ziel 2028 ${fmtNum(t28)}` : null,
    t31 !== null ? `Ziel 2031 ${fmtNum(t31)}` : null
  ].filter(Boolean).join(", ");
  return `<svg class="bullet" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}" role="img"
    aria-label="${esc(a11y)}" data-unit="${unit}">
    <rect class="bullet-bar" x="0" y="6" width="${W}" height="6" fill="${cssVar("--line")}"></rect>
    <rect class="bullet-ist" x="0" y="6" width="${x(ist).toFixed(1)}" height="6" fill="${cssVar("--navy")}"
          fill-opacity="0.75" data-tip="Ist" data-v="${ist}"></rect>
    ${exp !== null ? marke(exp, "bullet-pfad", "Pfad", 2, 14, cssVar("--ink")) : ""}
    ${t28 !== null ? marke(t28, "bullet-ziel-28", "Ziel 2028", 0, 18, cssVar("--line")) : ""}
    ${t31 !== null ? marke(t31, "bullet-ziel-31", "Ziel 2031", 0, 18, cssVar("--navy")) : ""}
  </svg>`;
}

function kpiTableHead(opts = {}) {
  /* Zwei Zielspalten: Ziel 2028 und Ziel 2031 */
  return `<thead><tr>${opts.lever ? "<th>Hebel</th>" : ""}<th>Kennzahl</th><th class="num">Ist</th><th class="num">vs. Pfad</th><th class="num">Δ Vorperiode</th><th>${opts.visual === "bullet" ? "Ist · Pfad · Ziel" : "Verlauf gegen Plan"}</th><th class="num">Ziel 2028</th><th class="num">Ziel 2031</th></tr></thead>`;
}

/* Eine Zeile je Kennzahl mit gleichen Spalten; nicht messbare
   Kennzahlen als schlichte Zeile. */
function kpiTableRow(k, opts = {}) {
  const { kpi } = resolve(k);
  const s = statusKey(k);
  const kind = statusKind(k);
  const edited = hasEdits(k.id) || hasEnteredValues(k.id);
  const lead = opts.lever ? `<td class="kr-lever">${esc(leverName(k.lever))}</td>` : "";
  const name = `<td class="kr-name">${kind === "perf" ? `<span class="rag-dot ${s}" aria-hidden="true"></span>` : `<span class="avail-ring" aria-hidden="true"></span>`}${esc(kpi.name)}${kpi.vorschlag ? " " + vorschlagChip() : ""}${edited ? " " + editedChip(k) : ""}</td>`;
  const aria = `aria-label="${esc(kpi.name)} — ${esc(statusLabel(s))}. Details öffnen."`;
  if (kind === "avail") {
    const when = availWhen(kpi);
    const interim = kpi.interim ? kpiById(kpi.interim) : null;
    return `<tr class="kpi-row kpi-row-avail" data-kpi="${k.id}" tabindex="0" role="button" ${aria}>${lead}${name}
      <td class="kr-avail" colspan="6">${esc(statusLabel(s))}${when ? ` · Zeitplan: ${esc(when)}` : ""}${interim ? ` · Interim: ${esc(interim.name)}` : ""}</td></tr>`;
  }
  const dev = deviationInfo(k);
  const visual = opts.visual === "bullet" ? bulletBar(k) : sparkline(kpi, s, { window: true });
  return `<tr class="kpi-row" data-kpi="${k.id}" tabindex="0" role="button" ${aria}>${lead}${name}
    <td class="num kr-ist">${currentDisplay(kpi)}<span class="kr-period">${esc(kpi.current.label || "")}</span></td>
    <td class="num dev-${s}">${esc(pathText(s, dev))}</td>
    <td class="num">${deltaHtml(k)}</td>
    <td class="kr-trend">${visual}</td>
    <td class="num kr-target">${targetText(kpi.target2028)}</td>
    <td class="num kr-target kr-target-31">${targetText(kpi.target2031)}</td>
  </tr>`;
}

function driverGroups(levers, opts = {}) {
  return levers.map(l => {
    const drivers = DATA.drivers.filter(d => d.lever === l.id);
    const flagged = drivers.filter(d => ["amber", "red"].includes(statusKey(d)));
    const shown = UiLogic.sortFlagged((opts.all ? drivers : flagged).map(k => ({ k, s: statusKey(k) }))).map(x => x.k);
    const restN = drivers.length - flagged.length;
    const count = flagged.length ? `${flagged.length} von ${drivers.length} auffällig` : `${drivers.length} Treiber, keine Abweichung`;
    return `<tbody>
      ${opts.all ? "" : `<tr class="group-row"><th colspan="7">${esc(l.name)} <span class="group-count">${count}</span></th></tr>`}
      ${shown.map(d => kpiTableRow(d)).join("")}
      ${!opts.all && restN ? `<tr class="more-row"><td colspan="7"><button class="link-btn" data-goto-lever="${l.id}" type="button">${restN} ${restN === 1 ? "weiterer" : "weitere"} ohne Abweichung — Scorecard ${esc(l.name)} →</button></td></tr>` : ""}
    </tbody>`;
  }).join("");
}

function suggestionsStrip() {
  const ks = (DATA.suggestions || []).filter(k => k.id !== "nettoverzinsung");
  if (!ks.length) return "";
  return `
  <section class="board-row board-row-suggest" id="row-suggest">
    <h2 class="row-q">Vorschläge — nicht im Strategiepapier</h2>
    <div class="table-wrap"><table class="data kpi-table">${kpiTableHead()}<tbody>${ks.map(k => kpiTableRow(k)).join("")}</tbody></table></div>
  </section>`;
}

/* ---------- Board ----------
   Urteil → Abweichungen → drei Fragen als Tabellen → Vorschläge →
   Hintergrund (eingeklappt). */
function viewBoard() {
  const net = kpiById("nettoverzinsung");
  return `
  ${statusStrip()}
  ${actionsSection()}
  <section class="board-row" id="row-1">
    <h2 class="row-q">Gewinnen wir wirtschaftlich?</h2>
    <div class="table-wrap"><table class="data kpi-table">${kpiTableHead({ visual: "bullet" })}<tbody>
      ${["kostenquote", "solvenzquote"].map(id => kpiTableRow(kpiById(id), { visual: "bullet" })).join("")}
      ${net ? kpiTableRow(net, { visual: "bullet" }) : ""}
    </tbody></table></div>
  </section>
  <section class="board-row" id="row-2">
    <h2 class="row-q">Wirken die vier Hebel?</h2>
    <div class="table-wrap"><table class="data kpi-table">${kpiTableHead({ lever: true })}<tbody>
      ${DATA.levers.map(l => kpiTableRow(DATA.central.find(x => x.id === l.centralKpi), { lever: true })).join("")}
    </tbody></table></div>
  </section>
  <section class="board-row" id="row-3">
    <h2 class="row-q">Tun wir die richtigen Dinge?</h2>
    <div class="table-wrap"><table class="data kpi-table">${kpiTableHead()}${driverGroups(DATA.levers)}</table></div>
  </section>
  ${suggestionsStrip()}
  <details class="board-background" id="board-background">
    <summary>Hintergrund zur Strategie — Zielbausteine, Reifegrad, Steuerungsrhythmus, offene Entscheidungen</summary>
    ${buildingBlockStrip()}
    <div class="humble-grid">
      ${maturityBand()}
      ${governanceBlock()}
      ${openItemsBlock()}
    </div>
  </details>`;
}

/* ---------- Hebel-Scorecard ---------- */
function viewLever(leverId) {
  const l = DATA.levers.find(x => x.id === leverId);
  if (!l) return "";
  const central = DATA.central.find(x => x.id === l.centralKpi);
  const stops = DATA.portfolio.stopDoing[leverId] || [];
  return `
  <div class="view-header">
    <h1>${esc(l.name)}</h1>
    <div class="sub">${esc(l.claim)}</div>
  </div>

  <div class="section">
    <h2 class="section-title">Zentrale Wirkungskennzahl</h2>
    <div class="knode-grid knode-grid-single">${kpiCard(central, {})}</div>
  </div>

  <div class="section">
    <h2 class="section-title">Treiber</h2>
    <div class="table-wrap"><table class="data kpi-table">${kpiTableHead()}${driverGroups([l], { all: true })}</table></div>
  </div>

  ${stops.length ? `
  <div class="section">
    <h2 class="section-title">Was machen wir nicht mehr?</h2>
    <ul class="stop-list">${stops.map(s => `<li>${esc(s)}</li>`).join("")}</ul>
  </div>` : ""}`;
}

/* ---------- Datenbasis ----------
   Je KPI: Eckwerte, gerechneter Plan mit Herkunft je Periode,
   gemessene Werte, Splits, Datenqualität. */
let BASIS_KPI = null;

/* Die vier Gruppen der Kette */
function basisGroups() {
  return [
    { label: "Gewinnen wir wirtschaftlich?", kpis: DATA.finance },
    { label: "Wirken die vier Hebel?", kpis: DATA.central },
    { label: "Tun wir die richtigen Dinge?", kpis: DATA.drivers },
    { label: "Vorschläge", kpis: DATA.suggestions }
  ];
}

/* Übersicht: jede Zeile öffnet das Blatt der Kennzahl. */
function basisOverview() {
  const planCell = (k, d) => (k.guardrail || (d && d.guardrail)) ? "Untergrenze"
    : anchorsOf(effKpi(k)).length < 2 ? `<span class="db-empty">noch kein Plan</span>`
    : (d && d.documentedPath) ? "aus Eckwerten + Planannahme"
    : "aus Eckwerten";
  /* Ohne Messung Reifegrad statt „0/6" anzeigen */
  const covCell = (k, q) => {
    if (k.maturity === "zu-entwickeln") return `<td class="num db-empty">zu entwickeln</td>`;
    if (q && q.pct === 0 && k.maturity === "auszuwerten") return `<td class="num db-empty">noch keine Messung</td>`;
    if (!q || !q.expectedCount) return `<td class="num db-empty">im Aufbau</td>`;
    return `<td class="num">${coverageCell(k)}</td>`;
  };
  return basisGroups().map(g => `
  <div class="section">
    <div class="section-title">${esc(g.label)}</div>
    <div class="table-wrap">
      <table class="data db-table">
        <thead><tr>
          <th>Kennzahl</th><th>Status</th><th class="num">Erfasst / erwartet</th>
          <th>Plan</th><th>Quellsystem</th><th>Stand</th>
        </tr></thead>
        <tbody>
          ${g.kpis.map(k => {
            const d = KPI_DATA[k.id];
            const q = k.maturity === "zu-entwickeln" ? null : qualityOf(k);
            const dq = (d && d.dataQuality) || {};
            return `
            <tr class="db-row ${k.id === BASIS_KPI ? "is-open" : ""}" data-basis-kpi="${k.id}"
                tabindex="0" role="button"
                aria-label="${esc(k.name)} — ${esc(statusLabel(statusKey(k)))}. Blatt öffnen. Erfasst ${q && q.expectedCount ? `${q.have} von ${q.expectedCount}` : "keine Messung"}.">
              <td class="kpi-td-name">${esc(k.name)}${k.vorschlag ? " " + vorschlagChip() : ""}</td>
              <td>${statusInline(k)}</td>
              ${covCell(k, q)}
              <td>${planCell(k, d)}</td>
              <td class="db-src">${esc(dq.sourceSystem || k.source || "—")}</td>
              <td class="db-empty">${esc(dq.lastUpdated || "—")}</td>
            </tr>`;
          }).join("")}
        </tbody>
      </table>
    </div>
  </div>`).join("");
}

function basisDetail(kpi) {
  const eff = effKpi(kpi);
  const anchors = anchorsOf(eff);
  const path = derivedPathOf(eff);
  const d = (typeof KPI_DATA !== "undefined" && KPI_DATA[kpi.id]) ? KPI_DATA[kpi.id] : null;
  const series = (d && d.series) || [];
  const splits = (d && d.splits) || null;
  const dq = (d && d.dataQuality) || {};

  const anchorRows = [
    { label: "Basis", a: eff.baseline, key: "baseline" },
    { label: "Ziel 2028", a: eff.target2028, key: "target2028" },
    { label: "Ziel 2031", a: eff.target2031, key: "target2031" }
  ].map(r => {
    const num = (r.a && typeof r.a.value === "number") ? r.a.value : "";
    const txt = (r.a && r.a.text) ? r.a.text : "";
    return `<tr>
      <td class="basis-anchor-label">${esc(r.label)}</td>
      <td><input class="basis-input" type="number" step="any" inputmode="decimal"
            data-anchor="${r.key}" data-anchor-field="value"
            data-orig="${num === "" ? "" : esc(String(num))}"
            value="${num === "" ? "" : esc(String(num))}"
            aria-label="${esc(r.label)} Wert"></td>
      <td><input class="basis-input basis-input-text" type="text"
            data-anchor="${r.key}" data-anchor-field="text"
            data-orig="${esc(txt)}"
            value="${esc(txt)}" placeholder="Anzeige (optional)"
            aria-label="${esc(r.label)} Anzeige"></td>
    </tr>`;
  }).join("");

  /* Herkunft eines Planwerts */
  const srcLabel = {
    dokumentiert: "Planannahme (Phasierung)",
    interpoliert: "aus Eckwerten",
    saisonal: "aus Eckwerten (saisonal verteilt)",
    keine: "—"
  };
  const pathRows = path.map(r => {
    const isDoc = r.source === "dokumentiert";
    return `<tr class="${isDoc ? "basis-doc" : ""}">
      <td>${esc(r.period)}</td>
      <td class="num">${typeof r.value === "number" ? fmtNum(r.value) : "—"}</td>
      <td class="basis-src basis-src-${r.source}">${esc(srcLabel[r.source] || r.source)}</td>
    </tr>`;
  }).join("");

  /* Wert je Split: erster numerischer Schlüssel außer `name` */
  const splitHtml = splits
    ? Object.entries(splits).map(([dim, arr]) => `
        <div class="basis-split">
          <div class="basis-split-dim">${esc(SPLIT_LABELS[dim] || dim)}</div>
          <ul>${arr.map(x => {
            const vk = Object.keys(x).find(k => k !== "name" && typeof x[k] === "number");
            return `<li>${esc(x.name)}${vk ? ` — ${fmtNum(x[vk])}` : ""}</li>`;
          }).join("")}</ul>
        </div>`).join("")
    : `<div class="db-empty">Keine Splits vorgesehen.</div>`;

  return `
  <div class="basis-detail">
    <div class="basis-head">
      <div>
        <div class="basis-title">${esc(kpi.name)} ${kpi.vorschlag ? vorschlagChip() : ""}</div>
        <div class="basis-sub">Einheit ${esc(kpi.unit)} · Takt ${esc(kpi.cadence)} · Owner ${esc(dq.steward || kpi.owner)} · Quelle ${esc(dq.sourceSystem || kpi.source)}</div>
      </div>
      <div class="basis-status">${statusBadge(kpi)}</div>
    </div>

    <div class="basis-block">
      <div class="basis-block-title">Eckwerte <span class="basis-hint">der Plan entsteht aus diesen Werten</span></div>
      <div class="table-wrap">
        <table class="data basis-table">
          <thead><tr><th>Eckwert</th><th>Wert</th><th>Anzeige</th></tr></thead>
          <tbody>${anchorRows}</tbody>
        </table>
      </div>
    </div>

    <div class="basis-actions">
      <button class="btn-primary" data-save-anchors type="button" disabled>Eckwerte speichern</button>
      <span class="basis-actions-note">Änderungen wirken sofort auf Plan und Status.</span>
    </div>

    <div class="basis-block">
      <div class="basis-block-title">Plan <span class="basis-hint">aus den Eckwerten gerechnet${path.some(r => r.source === "dokumentiert") ? ` · ${path.filter(r => r.source === "dokumentiert").length} Quartalswerte als Planannahme hinterlegt` : ""}</span></div>
      <div class="table-wrap basis-path-wrap">
        <table class="data basis-table">
          <thead><tr><th>Periode</th><th class="num">Wert</th><th>Herkunft</th></tr></thead>
          <tbody>${pathRows}</tbody>
        </table>
      </div>
    </div>

    <div class="basis-block">
      <div class="basis-block-title">Ist- und Planwerte <span class="basis-hint">Werte je Periode erfassen, Plan übersteuern</span></div>
      ${sheetSection(kpi)}
    </div>

    <div class="basis-block">
      <div class="basis-block-title">Splits <span class="basis-hint">Vorlage für die Ursachenanalyse</span></div>
      <div class="basis-splits">${splitHtml}</div>
    </div>
  </div>`;
}

/* Eckwerte speichern: in EDITS und ins Änderungs-Log */
function saveAnchors(kpiId) {
  const kpi = kpiById(kpiId);
  if (!kpi) return 0;
  const view = $("#view");
  const inputs = $$("[data-anchor]", view);
  let saved = 0;
  const groups = { baseline: {}, target2028: {}, target2031: {} };
  inputs.forEach(inp => {
    const g = inp.dataset.anchor;
    const f = inp.dataset.anchorField;
    if (!groups[g]) return;
    if (f === "value") {
      const raw = inp.value.trim();
      groups[g].value = raw === "" ? null : parseFloat(raw.replace(",", "."));
      if (raw !== "" && isNaN(groups[g].value)) groups[g].value = null;
    } else {
      groups[g].text = inp.value.trim();
    }
  });
  /* Vergleich gegen den effektiven Stand, damit gleiches Speichern
       keine Änderung protokolliert */
  const eff = effKpi(kpi);
  Object.keys(groups).forEach(g => {
    const next = groups[g];
    const cur = eff[g] || {};
    const changed = (next.value !== undefined && next.value !== (typeof cur.value === "number" ? cur.value : null))
      || (next.text !== undefined && next.text !== (cur.text || ""));
    if (!changed) return;
    EDITS[kpiId] = EDITS[kpiId] || {};
    EDITS[kpiId][g] = Object.assign({}, EDITS[kpiId][g] || {}, next);
    addLogEntry({
      actor: logActor(), kpi: kpiId, kpiName: kpi.name,
      field: `Eckwert ${g}`, kind: "korrigiert",
      oldValue: typeof cur.value === "number" ? cur.value : null,
      newValue: next.value === undefined ? null : next.value
    });
    saved++;
  });
  if (saved) saveEdits();
  return saved;
}

function viewDatenbasis() {
  const all = allKpis();
  if (!BASIS_KPI || !all.find(k => k.id === BASIS_KPI)) BASIS_KPI = all[0].id;
  const kpi = kpiById(BASIS_KPI);
  const qs = qualitySummary();
  const milestones = DATA.maturityRoadmap.map(m =>
    `<div class="mat-item"><span class="mat-when">${esc(m.when)}</span><span class="mat-what">${esc(m.what)}</span></div>`).join("");
  return `
  <div class="view-header">
    <h1>Datenbasis</h1>
    <div class="sub">Die Nachschlagefläche: Übersicht aller ${qs.total} Kennzahlen, darunter das Blatt der gewählten. Hier werden Eckwerte (Plan), Ist-Werte und Plan-Ausnahmen je Kennzahl gepflegt — alles andere rechnet sich daraus.</div>
  </div>

  <div class="section">
    <div class="db-summary">
      <div class="db-stat"><b>${qs.full}</b> vollständig erfasst</div>
      <div class="db-stat"><b>${qs.partial}</b> teilweise</div>
      <div class="db-stat"><b>${qs.empty}</b> ohne Messung</div>
      <div class="db-stat"><b>${qs.aufbau}</b> im Aufbau</div>
    </div>
    ${basisOverview()}
  </div>

  ${kpi ? basisDetail(kpi) : ""}

  <div class="humble-block">
    <div class="humble-head">
      <span class="humble-title">Wann wird was steuerbar?</span>
      <span class="humble-counts"><span>${DATA.maturityRoadmap.length} Meilensteine</span></span>
    </div>
    <div class="mat-roadmap">${milestones}</div>
  </div>`;
}

/* ---------- Datenpflege ----------
   Pflichten, Datenblatt je KPI, Änderungs-Log, Datenqualität.
   Erfasste Werte fließen über effKpi ins Board. */
let SHEET_KPI = null;
let LOG_ALL = false;

/* Chip für lokale Daten: geändert (Modal) oder erfasst (Blatt) */
function editedChip(k) {
  if (hasEdits(k.id)) return `<span class="chip chip-edited">geändert</span>`;
  if (hasEnteredValues(k.id)) return `<span class="chip chip-edited">erfasst</span>`;
  return "";
}

function dutyDotCls(status) {
  return { faellig: "red", demnaechst: "amber", "im-aufbau": "tbd" }[status] || null;
}

/* Pflicht-Text: welche Periode steht aus? */
function dutyWord(kpi, period) {
  if (!period) return "—";
  const cad = cadenceOf(kpi);
  const m = period.match(/^(\d{4})-Q([1-4])$/);
  if (!m) return period;
  if (cad === "Halbjährlich") return `Halbjahreswert ${m[1]}-H${m[2] === "2" ? "1" : "2"}`;
  if (cad === "Jährlich") return `Jahreswert ${m[1]}`;
  return `Quartalswert ${period}`;
}

function fmtDateShort(d) {
  if (!d) return "—";
  return d.toLocaleDateString("de-DE", { day: "2-digit", month: "2-digit", year: "numeric" });
}

function fmtTs(iso) {
  if (!iso) return "—";
  const d = new Date(iso);
  return d.toLocaleDateString("de-DE", { day: "2-digit", month: "2-digit" }) + ", " +
    d.toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" });
}

/* Vorheriger Wert (erfasst oder Basis) */
function previousValue(kpi, period) {
  const periods = entryPeriods(kpi);
  const idx = periods.indexOf(period);
  if (idx <= 0) return null;
  const prev = periods[idx - 1];
  const e = getEnteredValue(kpi.id, prev);
  if (e) return e.value;
  const d = (typeof KPI_DATA !== "undefined" && KPI_DATA[kpi.id]) ? KPI_DATA[kpi.id] : null;
  const s = d && d.series ? d.series.find(x => x.period === prev && x.value !== null) : null;
  return s ? s.value : null;
}

/* ---------- Datenblatt ----------
   Jede Zeile zeigt ihren Zustand: geändert, ungültig, erfasst. */
/* Eine Zeile je Periode und Typ (Wide-Format); gespeichert wird im
   Long-Format. */
function sheetRow(kpi, period, type) {
  const isPlan = type === "plan";
  const entered = isPlan ? getPlanValue(kpi.id, period) : getEnteredValue(kpi.id, period);
  /* Plan-Zeilen zeigen den gerechneten Planwert */
  const basis = (typeof KPI_DATA !== "undefined" && KPI_DATA[kpi.id])
    ? (isPlan
        ? (() => {
            const pv = pathValueAt(effKpi(kpi), period);
            return typeof pv === "number" ? { value: pv } : null;
          })()
        : (KPI_DATA[kpi.id].series || []).find(s => s.period === period && s.value !== null))
    : null;
  const isFuture = periodEndDate(period) > new Date();
  let value = "";
  let statusHtml = `<span class="sheet-st-none">—</span>`;
  if (entered) {
    value = UiLogic.formatDecimalDe(entered.value);
    statusHtml = `<span class="sheet-st-ok">erfasst ${fmtDateShort(new Date(entered.enteredAt))}</span>`;
  } else if (basis) {
    value = UiLogic.formatDecimalDe(basis.value);
    statusHtml = `<span class="sheet-st-basis">${isPlan ? "Plan (gerechnet)" : "Basis"}</span>`;
  } else if (!isPlan && !isFuture && period === lastExpectedPeriod(kpi)) {
    statusHtml = `<span class="sheet-st-due">fällig seit ${fmtDateShort(dutyDeadline(kpi))}</span>`;
  }
  const msgId = `st-${type}-${period}`;
  return `
  <tr class="sheet-row${isFuture && !isPlan ? " sheet-future" : ""}" data-row="${period}" data-type="${type}">
    <td class="sheet-period">${period}</td>
    <td><input class="sheet-input" type="text" inputmode="decimal" autocomplete="off" spellcheck="false" data-period="${period}" data-type="${type}" data-orig="${esc(value)}" value="${esc(value)}" aria-label="${isPlan ? "Planwert" : "Ist-Wert"} für ${period}" aria-describedby="${msgId}"></td>
    <td class="sheet-type">${isPlan ? "Plan" : (isFuture ? "offen" : "Ist")}</td>
    <td class="sheet-status" id="${msgId}" data-status data-base="${esc(statusHtml.replace(/<[^>]+>/g, "").trim())}">${statusHtml}</td>
  </tr>`;
}

function sheetSection(kpi) {
  const periods = entryPeriods(kpi);
  const r = resolve(kpi);
  const next = nextDuePeriod(kpi);
  const ytd = ytdProgress(kpi);
  const confirmHtml = (LAST_SAVE && LAST_SAVE.kpiId === kpi.id)
    ? `Gespeichert ${LAST_SAVE.ts.toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" })} · ${LAST_SAVE.n} ${LAST_SAVE.n === 1 ? "Wert" : "Werte"} · <a href="#board">im Board sichtbar →</a>`
    : "";
  const ytdNote = ytd ? `
    <div class="sheet-ytd">
      <b>Kumulierte Messung:</b> ${ytd.mode === "kumuliert" ? `Stand ${esc(ytd.year)} bis Q${ytd.quarter}` : `YTD ${esc(ytd.year)} bis Q${ytd.quarter}`} —
      Ist <b>${fmtNum(ytd.actual)}</b> ${esc(kpi.unit)} gegen
      ${ytd.targetSource === "pfad" ? "Zielpfad" : "anteiliges Ziel"}
      <b>${fmtNum(ytd.target)}</b> ${esc(kpi.unit)}${ytd.targetSource === "pfad"
        ? ` (Pfadwert ${esc(ytd.year)}-Q${ytd.quarter})`
        : ` (${Math.round((ytd.share || 0) * 100)} % des Jahresziels, ${ytd.linear ? "linear verteilt" : "saisonal gewichtet"})`}.
      Jahresziel ${esc(ytd.year)}: <b>${esc(ytd.annualLabel || fmtNum(ytd.annual))}</b>.
    </div>` : "";
  return `
  <div class="sheet" id="sheet">
    <div class="sheet-head">
      <div>
        <div class="sheet-title">${esc(kpi.name)} ${kpi.vorschlag ? vorschlagChip() : ""}</div>
        <div class="sheet-sub">Einheit ${esc(kpi.unit)} · Takt ${esc(kpi.cadence)} · Richtung ${kpi.direction === "up" ? "aufwärts" : "fallend"} · im Board angezeigt: <b>${fmtNum(r.kpi.current.value)}</b> (${esc(r.kpi.current.label || "—")})</div>
      </div>
      <div class="sheet-actions">
        <button class="btn-mini" data-paste-toggle type="button">Aus Excel einfügen</button>
      </div>
    </div>
    ${ytdNote}
    <div class="sheet-paste" id="sheet-paste" hidden>
      <textarea class="paste-area" placeholder="Periode und Wert je Zeile — getrennt durch Tab, Semikolon oder Leerzeichen. Beispiel:&#10;2026-Q1 11,0&#10;2026-Q2 15,5"></textarea>
      <div class="sheet-paste-row"><button class="btn-mini" data-paste-fill type="button">Übernehmen</button></div>
    </div>
    <div class="sheet-block">
      <div class="sheet-block-title">Ist-Werte <span class="sheet-block-hint">gemessene Werte je Periode</span></div>
      <div class="table-wrap">
        <table class="data sheet-table">
          <thead><tr><th>Periode</th><th>Wert (${esc(kpi.unit)})</th><th>Typ</th><th>Status</th></tr></thead>
          <tbody>${periods.map(p => sheetRow(kpi, p, "ist")).join("")}</tbody>
        </table>
      </div>
    </div>
    <details class="sheet-block sheet-plan">
      <summary class="sheet-block-title">Planwerte überschreiben <span class="sheet-block-hint">aus den Eckwerten gerechnet — nur ändern, wenn die Planung abweicht</span></summary>
      <div class="table-wrap">
        <table class="data sheet-table">
          <thead><tr><th>Periode</th><th>Wert (${esc(kpi.unit)})</th><th>Typ</th><th>Status</th></tr></thead>
          <tbody>${periods.map(p => sheetRow(kpi, p, "plan")).join("")}</tbody>
        </table>
      </div>
    </details>
    <div class="sheet-foot">Leere Eingabe löscht einen erfassten Wert. Enter springt zur nächsten Zeile, Strg+S speichert.${next ? ` Nächste Periode: ${next}.` : ""}</div>
    <div class="unsaved-bar" id="unsaved-bar" role="alertdialog" aria-label="Ungespeicherte Werte" hidden>
      <span class="unsaved-msg"></span>
      <button class="btn-primary" data-unsaved-save type="button">Speichern</button>
      <button class="btn-mini" data-unsaved-discard type="button">Verwerfen</button>
      <button class="btn-mini" data-unsaved-cancel type="button">Abbrechen</button>
    </div>
    <div class="sheet-savebar">
      <span class="savebar-count" aria-live="polite"></span>
      <span class="savebar-confirm" role="status">${confirmHtml}</span>
      <button class="btn-primary" data-save-sheet type="button" disabled>Speichern</button>
    </div>
  </div>`;
}

/* ---------- Datenqualität ---------- */
/* Zählregel: erfasste bzw. vorhandene Ist-Perioden gegen erwartete */
function qualitySummary() {
  let full = 0, partial = 0, empty = 0, aufbau = 0;
  allKpis().forEach(k => {
    if (k.maturity === "zu-entwickeln") { aufbau++; return; }
    const q = qualityOf(k);
    if (!q.expectedCount) { aufbau++; return; }
    if (q.pct === 100) full++;
    else if (q.pct >= 50) partial++;
    else empty++;
  });
  return { total: allKpis().length, full, partial, empty, aufbau };
}

function coverageCell(k) {
  const q = k.maturity === "zu-entwickeln" ? null : qualityOf(k);
  if (!q || !q.expectedCount) return `<span class="dq-none">im Aufbau</span>`;
  return `<span class="dq-bar" aria-hidden="true"><span style="width:${q.pct}%"></span></span> ${q.have}/${q.expectedCount}`;
}

function statusInline(k) {
  const s = statusKey(k);
  return statusKind(k) === "perf"
    ? `<span class="status-inline"><span class="rag-dot ${s}" aria-hidden="true"></span>${esc(statusLabel(s))}</span>`
    : `<span class="status-inline status-avail"><span class="avail-ring" aria-hidden="true"></span>${esc(statusLabel(s))}</span>`;
}

/* ---------- Datenpflege-Ansicht ---------- */
function viewDatenpflege() {
  const all = kpisOfRole();
  const duties = allDuties();
  const due = duties.filter(d => d.status === "faellig");
  const soon = duties.filter(d => d.status === "demnaechst");
  const building = duties.filter(d => d.status === "im-aufbau");
  if (!SHEET_KPI || !all.find(k => k.id === SHEET_KPI)) {
    SHEET_KPI = (due[0] ? due[0].kpi.id : null) || (all[0] ? all[0].id : null);
  }
  const dutyRow = (d, cls, frist, btn) => `
    <div class="duty-item">
      <span class="rag-dot ${cls}" aria-hidden="true"></span>
      <span class="duty-text"><b>${esc(d.kpi.name)}</b> — ${esc(dutyWord(d.kpi, d.period))}${d.kpi.vorschlag ? " " + vorschlagChip() : ""}</span>
      <span class="duty-deadline${cls === "red" ? " due" : ""}">${frist}</span>
      <button class="btn-mini" data-duty-goto="${d.kpi.id}" data-duty-period="${esc(d.period || "")}" type="button">${btn}</button>
    </div>`;
  const dutiesHtml = `
  <div class="section">
    <h2 class="section-title">Pflichten</h2>
    <div class="duties-panel">
      ${due.map(d => dutyRow(d, "red", `fällig seit ${fmtDateShort(d.deadline)}`, "jetzt erfassen")).join("")}
      ${soon.map(d => dutyRow(d, "amber", `Frist ${fmtDateShort(d.deadline)}`, "erfassen")).join("")}
      ${(!due.length && !soon.length) ? `<div class="duty-item duty-none">Nichts fällig.</div>` : ""}
      ${building.length ? `<div class="duty-building">${building.length} ${building.length === 1 ? "Kennzahl" : "Kennzahlen"} im Aufbau, keine Erfassung: ${building.map(d => esc(d.kpi.name)).join(" · ")}</div>` : ""}
    </div>
  </div>`;
  const pillsAndSheet = `
  <div class="section">
    <div class="section-title">Datenblatt</div>
    <div class="kpi-pills">
      ${all.map(k => {
        const dot = dutyDotCls(dutyStatus(k));
        return `<button class="kpi-pill ${k.id === SHEET_KPI ? "active" : ""}" data-sheet-kpi="${k.id}" type="button">${dot ? `<span class="rag-dot ${dot}"></span>` : ""}${esc(k.name)}</button>`;
      }).join("")}
    </div>
    ${SHEET_KPI ? sheetSection(kpiById(SHEET_KPI)) : ""}
  </div>`;
  const log = loadLog();
  const logHtml = `
  <div class="section">
    <div class="section-title">Änderungs-Log</div>
    <div class="log-toolbar">
      <button class="btn-mini" data-export-log type="button">Log als Markdown</button>
      <button class="btn-mini" data-export-state type="button">Daten exportieren</button>
      <button class="btn-mini" data-import-state type="button">Daten importieren</button>
      <input type="file" id="import-file" accept=".json,application/json" hidden>
      <button class="btn-mini btn-danger-quiet" data-clear-entry type="button">Lokale Erfassung löschen</button>
    </div>
    ${log.length ? `
    <div class="table-wrap">
      <table class="data log-table">
        <thead><tr><th>Zeit</th><th>Kennzahl</th><th>Periode / Feld</th><th>Art</th><th>Änderung</th></tr></thead>
        <tbody>
          ${(LOG_ALL ? log.slice().reverse() : log.slice().reverse().slice(0, 5)).map(e => `
          <tr>
            <td class="log-ts">${fmtTs(e.ts)}</td>
            <td class="kpi-td-name">${esc(e.kpiName || e.kpi)}</td>
            <td>${esc(e.period || e.field || "—")}</td>
            <td><span class="log-kind kind-${String(e.kind || "").replace("ö", "oe").replace("ü", "ue")}">${esc(e.kind || "—")}</span></td>
            <td class="log-change">${e.oldValue === null || e.oldValue === undefined ? "—" : fmtNum(e.oldValue)}&nbsp;→&nbsp;${e.newValue === null || e.newValue === undefined ? "—" : fmtNum(e.newValue)}</td>
          </tr>`).join("")}
        </tbody>
      </table>
    </div>
    ${log.length > 5 ? `<button class="link-btn" data-log-all type="button">${LOG_ALL ? "nur die letzten 5" : `alle ${log.length} anzeigen`}</button>` : ""}` : `<div class="log-empty">Noch keine Einträge — Erfassungen und Korrekturen erscheinen hier automatisch.</div>`}
  </div>`;
  return `
  <div class="view-header">
    <h1>Datenpflege</h1>
    <div class="sub">Werte je Kennzahl erfassen — das Board rechnet den Status neu. Die Datenqualität aller Kennzahlen steht in der <a class="kpi-link" href="#datenbasis">Datenbasis</a>.</div>
  </div>
  ${dutiesHtml}
  ${pillsAndSheet}
  ${logHtml}`;
}

/* ---------- Blatt-Aktionen ---------- */
/* Zweiter Klick auf die offene Zeile springt zum Datenblatt,
   ohne neu zu zeichnen. */
function scrollToSheet() {
  const el = $("#sheet");
  if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
}

function selectSheetKpi(id, scroll, period) {
  SHEET_KPI = id;
  render(CURRENT_VIEW, { noScroll: true });
  setTimeout(() => {
    const el = $("#sheet");
    if (scroll && el) el.scrollIntoView({ behavior: "smooth", block: "start" });
    const target = (period && $(`.sheet-input[data-type="ist"][data-period="${period}"]`))
      || $$('.sheet-input[data-type="ist"]').find(i => !i.value);
    if (target) target.focus();
  }, 60);
}

let LAST_SAVE = null;

/* Die im Datenblatt offene Kennzahl (Datenpflege: SHEET_KPI,
   Datenbasis: BASIS_KPI) */
function sheetKpiId() {
  return CURRENT_VIEW === "datenbasis" ? BASIS_KPI : SHEET_KPI;
}
function sheetKpi() {
  const id = sheetKpiId();
  return id ? kpiById(id) : null;
}

/* Speichert das ganze Formular: erst Eckwerte, dann Ist- und Planwerte. */
function saveSheet() {
  const kpi = sheetKpi();
  if (!kpi) return false;
  saveAnchors(kpi.id);
  const view = $("#view");
  const inputs = $$(".sheet-input", view);
  inputs.forEach(validateSheetInput);
  const firstInvalid = inputs.find(i => i.classList.contains("invalid"));
  if (firstInvalid) { firstInvalid.focus(); refreshSheetSaveState(); return false; }
  const act = document.activeElement;
  const focusSel = act && act.classList && act.classList.contains("sheet-input")
    ? `.sheet-input[data-period="${act.dataset.period}"][data-type="${act.dataset.type}"]` : null;
  let saved = 0;
  inputs.forEach(inp => {
    if (!inp.classList.contains("changed")) return;
    const period = inp.dataset.period;
    const type = inp.dataset.type || "ist";
    const hadEntered = type === "plan" ? !!getPlanValue(kpi.id, period) : !!getEnteredValue(kpi.id, period);
    const num = UiLogic.parseDecimal(inp.value);
    /* writeValue validiert; null löscht den Wert. */
    const prev = writeValue(kpi.id, period, num, currentRole(), type);
    const kind = num === null ? "gelöscht" : (hadEntered ? "korrigiert" : "erfasst");
    addLogEntry({ actor: logActor(), kpi: kpi.id, kpiName: kpi.name, period: period + (type === "plan" ? " (Plan)" : ""), kind, oldValue: prev, newValue: num });
    saved++;
  });
  if (saved && EDITS[kpi.id] && EDITS[kpi.id].current) {
    delete EDITS[kpi.id].current;
    if (!Object.keys(EDITS[kpi.id]).length) delete EDITS[kpi.id];
    saveEdits();
  }
  if (saved) LAST_SAVE = { ts: new Date(), n: saved, kpiId: kpi.id };
  render(CURRENT_VIEW, { noScroll: true });
  if (focusSel) { const f = $(focusSel); if (f) f.focus(); }
  return true;
}

function applyPaste() {
  const ta = $(".paste-area");
  if (!ta) return;
  const view = $("#view");
  const lines = ta.value.split(/\n+/).map(l => l.trim()).filter(Boolean);
  let filled = 0;
  const problems = [];
  lines.forEach(line => {
    const parts = line.split(/[\t;\s]+/).filter(Boolean);
    if (parts.length < 2) { problems.push(`„${line}"`); return; }
    const period = parts[0];
    const num = UiLogic.parseDecimal(parts[1]);
    const inp = $(`.sheet-input[data-period="${period}"][data-type="ist"]`, view);
    if (!inp) { problems.push(`Periode ${period} unbekannt`); return; }
    if (typeof num !== "number" || Number.isNaN(num)) { problems.push(`„${parts[1]}" ist keine Zahl`); return; }
    inp.value = UiLogic.formatDecimalDe(num);
    validateSheetInput(inp);
    filled++;
  });
  refreshSheetSaveState();
  /* Rückmeldung direkt am Einfügefeld */
  const hint = $(".sheet-paste-row", view);
  if (hint) {
    const msg = problems.length
      ? `${filled} übernommen · ${problems.length} nicht übernommen: ${problems.join(", ")}`
      : `${filled} ${filled === 1 ? "Wert" : "Werte"} übernommen`;
    let el = $(".paste-feedback", view);
    if (!el) { el = document.createElement("span"); el.className = "paste-feedback"; hint.appendChild(el); }
    el.textContent = msg;
    el.classList.toggle("err", problems.length > 0);
  }
}

/* ---------- Export / Import ---------- */
function downloadFile(name, content, mime) {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

/* ---------- Fälligkeiten im Kopf ---------- */
function renderDutyBadge() {
  const el = $("#role-switch");
  if (!el) return;
  const n = countDueDuties();
  if (!n) { el.innerHTML = ""; return; }
  el.innerHTML = `<button class="duty-badge has-due" data-goto-duties type="button"><span class="rag-dot red"></span>${n} ${n === 1 ? "Kennzahl" : "Kennzahlen"} fällig</button>`;
  const duty = $("[data-goto-duties]", el);
  if (duty) duty.addEventListener("click", () => { location.hash = "datenpflege"; });
}

function updateDutyBadge() { renderDutyBadge(); }

/* ---------- Rückmeldung beim Tippen ----------
   Zeile markieren, Status setzen, Speichern aktivieren. */
function validateSheetInput(inp) {
  const row = inp.closest(".sheet-row");
  const kpi = sheetKpi();
  if (!row || !kpi) return { valid: true, changed: false };
  const raw = inp.value.trim();
  const orig = inp.dataset.orig || "";
  const num = UiLogic.parseDecimal(raw);
  const origNum = UiLogic.parseDecimal(orig);
  /* Geändert = anderer Zahlenwert („1,70" = „1,7") */
  const changed = raw === "" ? orig !== "" : !(typeof num === "number" && num === origNum);
  const statusEl = row.querySelector("[data-status]");
  const isPlan = inp.dataset.type === "plan";
  let valid = true, level = "", msg = "";
  if (raw === "") {
    msg = changed ? "wird gelöscht" : "";
  } else if (Number.isNaN(num)) {
    valid = false;
    msg = "keine Zahl — z. B. 1,85";
  } else {
    const prev = isPlan ? null : previousValue(kpi, inp.dataset.period);
    const chk = UiLogic.checkPlausible(num, kpi.plausible, prev);
    if (chk.level === "error") { valid = false; msg = chk.msg; }
    else if (chk.level === "warn") { level = "warn"; msg = chk.msg; }
    else if (isPlan) msg = "Plan geändert";
    else if (typeof prev === "number" && (kpi.direction === "up" ? num < prev : num > prev)) msg = "gegen Richtung";
  }
  inp.classList.toggle("changed", changed);
  inp.classList.toggle("invalid", !valid);
  inp.classList.toggle("warn", valid && level === "warn");
  inp.setAttribute("aria-invalid", String(!valid));
  if (statusEl) {
    if (!valid) statusEl.innerHTML = `<span class="sheet-st-err">${esc(msg)}</span>`;
    else if (level === "warn") statusEl.innerHTML = `<span class="sheet-st-warn">${esc(msg)}</span>`;
    else if (changed) statusEl.innerHTML = `<span class="sheet-st-changed">${esc(msg || "geändert")}</span>`;
    else statusEl.innerHTML = `<span class="sheet-st-none">${esc(statusEl.dataset.base || "—")}</span>`;
  }
  return { valid, changed };
}

function sheetDirtyCount() { return $$(".sheet-input.changed").length; }

/* Geänderte Eckwerte zählen wie geänderte Blattwerte. */
function anchorDirtyCount() { return $$(".basis-input.changed").length; }
function dirtyCount() { return sheetDirtyCount() + anchorDirtyCount(); }
function markAnchorDirty(inp) {
  if (!inp) return;
  const orig = inp.dataset.orig !== undefined
    ? inp.dataset.orig
    : (inp.dataset.orig = inp.value, inp.value);
  inp.classList.toggle("changed", inp.value.trim() !== String(orig).trim());
  refreshSheetSaveState();
}

/* Ein Speicherzustand für das ganze Formular */
function refreshSheetSaveState() {
  const n = dirtyCount();
  const anyInvalid = $$(".sheet-input.invalid").length > 0;
  const btn = $("[data-save-sheet]");
  const ancBtn = $("[data-save-anchors]");
  const cnt = $(".savebar-count");
  const parts = [];
  if (anchorDirtyCount()) parts.push(`${anchorDirtyCount()} Eckwert${anchorDirtyCount() === 1 ? "" : "e"}`);
  if (sheetDirtyCount()) parts.push(`${sheetDirtyCount()} Wert${sheetDirtyCount() === 1 ? "" : "e"}`);
  if (cnt) {
    cnt.textContent = anyInvalid ? "Eingabe prüfen" : (parts.length ? `${parts.join(" · ")} ungespeichert` : "");
    cnt.classList.toggle("err", anyInvalid);
  }
  if (btn) btn.disabled = !n || anyInvalid;
  if (ancBtn) ancBtn.disabled = !anchorDirtyCount();
}

/* Enter = nächste Zeile, Shift+Enter = vorige */
function moveSheetFocus(inp, dir) {
  const list = $$(`.sheet-input[data-type="${inp.dataset.type}"]`);
  const next = list[list.indexOf(inp) + dir];
  if (next) { next.focus(); next.select(); }
}

/* ---------- Ungespeicherte Werte ----------
   Wechsel von Kennzahl oder Ansicht fragt nach, solange etwas
   ungespeichert ist. */
let PENDING = null;
function runPending() { const f = PENDING; PENDING = null; if (f) f(); }
function showUnsavedBar(fn) {
  PENDING = fn;
  const bar = $("#unsaved-bar");
  if (!bar) { runPending(); return; }
  const n = dirtyCount();
  $(".unsaved-msg", bar).textContent = `${n} ungespeicherte${n === 1 ? "r Wert" : " Werte"}`;
  bar.hidden = false;
  $("[data-unsaved-save]", bar).focus();
}
/* Die Sperre hängt am vorhandenen Datenblatt, nicht an der Ansicht. */
function hasDirtySheet() { return !!$(".sheet-input"); }
function guardSheet(fn) {
  if (hasDirtySheet() && dirtyCount()) showUnsavedBar(fn);
  else fn();
}

function onViewInput(e) {
  const t = e.target;
  if (t && t.classList && t.classList.contains("sheet-input")) {
    validateSheetInput(t);
    refreshSheetSaveState();
  }
  if (t && t.classList && t.classList.contains("basis-input")) {
    markAnchorDirty(t);
  }
}

function onViewChange(e) {
  const t = e.target;
  if (!t || !t.dataset) return;
  if (t.id === "import-file") {
    const f = t.files && t.files[0];
    if (!f) return;
    const reader = new FileReader();
    reader.onload = () => {
      const ok = importState(String(reader.result));
      render(CURRENT_VIEW, { noScroll: true });
      flashButton("[data-import-state]", ok ? "Importiert" : "Import fehlgeschlagen");
    };
    reader.readAsText(f);
    return;
  }
  if (t.dataset.logFilter !== undefined) {
    return;
  }
}

/* ---------- Detail-Modal ---------- */
function editForm(kpi) {
  const e = EDITS[kpi.id] || {};
  const t28 = Object.assign({}, kpi.target2028, e.target2028 || {});
  const t31 = Object.assign({}, kpi.target2031, e.target2031 || {});
  const cur = Object.assign({}, kpi.current, e.current || {});
  const numVal = v => (typeof v === "number" ? v : "");
  return `
  <div class="edit-grid">
    <div class="edit-group">
      <div class="edit-group-title">Ziel 2028</div>
      <label class="edit-field"><span>Wert</span><input type="number" step="any" data-edit="target2028.value" value="${numVal(t28.value)}" placeholder="leer = TBD"></label>
      <label class="edit-field"><span>Anzeigetext</span><input type="text" data-edit="target2028.text" value="${esc(t28.text || "")}"></label>
    </div>
    <div class="edit-group">
      <div class="edit-group-title">Ziel 2031</div>
      <label class="edit-field"><span>Wert</span><input type="number" step="any" data-edit="target2031.value" value="${numVal(t31.value)}" placeholder="leer = TBD"></label>
      <label class="edit-field"><span>Anzeigetext</span><input type="text" data-edit="target2031.text" value="${esc(t31.text || "")}"></label>
    </div>
    <div class="edit-group">
      <div class="edit-group-title">Ist-Wert</div>
      <label class="edit-field"><span>Wert</span><input type="number" step="any" data-edit="current.value" value="${numVal(cur.value)}"></label>
      <label class="edit-field"><span>Bezeichnung</span><input type="text" data-edit="current.label" value="${esc(cur.label || "")}"></label>
    </div>
  </div>
  <div class="edit-actions">
    <button class="btn-reset-kpi" ${hasEdits(kpi.id) ? "" : "disabled"}>Zurücksetzen</button>
    <span class="edit-note">Wird lokal gespeichert; der Status rechnet sich neu.</span>
  </div>`;
}

let CHART_FULL = false;

function targetText(t) { return targetDisplay(t).replace(/<\/?b>/g, ""); }

/* Zieltext ohne HTML, für Antworten und den Textblock. */
function targetPlain(t) {
  if (!t) return "TBD";
  const txt = t.text == null ? "" : String(t.text).trim();
  if (txt) return txt;
  return typeof t.value === "number" ? fmtNum(t.value) : "TBD";
}

/* Verbundene Kennzahlen: Wirkung ↔ Treiber */
function drillBlock(k) {
  let title, list;
  if (DATA.central.some(c => c.id === k.id)) {
    title = "Treiber dieses Hebels";
    list = UiLogic.sortFlagged(DATA.drivers.filter(d => d.lever === k.lever).map(d => ({ k: d, s: statusKey(d) }))).map(x => x.k);
  } else if (DATA.drivers.some(d => d.id === k.id)) {
    const l = DATA.levers.find(x => x.id === k.lever);
    const c = l ? kpiById(l.centralKpi) : null;
    if (!c) return "";
    title = "Wirkt auf";
    list = [c];
  } else return "";
  if (!list.length) return "";
  return `
  <div class="modal-drill">
    <h4>${title}</h4>
    <table class="data kpi-table drill-table"><tbody>
      ${list.map(d => {
        const kd = effKpi(d);
        const s = statusKey(d);
        const perf = statusKind(d) === "perf";
        const dev = deviationInfo(d);
        return `
        <tr data-kpi="${d.id}" tabindex="0" role="button" aria-label="${esc(d.name)} — ${esc(statusLabel(s))}. Details öffnen.">
          <td class="kr-name">${perf ? `<span class="rag-dot ${s}" aria-hidden="true"></span>` : `<span class="avail-ring" aria-hidden="true"></span>`}${esc(d.name)}</td>
          <td class="num kr-ist">${perf ? currentDisplay(kd) : ""}</td>
          <td class="num dev-${s}">${perf ? esc(pathText(s, dev)) : esc(statusLabel(s))}</td>
        </tr>`;
      }).join("")}
    </tbody></table>
  </div>`;
}

/* ---------- Fragen an diese Kennzahl (kpi_chat.js) ----------
   Liefert dem Fragen-Modul die Fakten einer Kennzahl. Alle Zahlen
   kommen aus denselben Funktionen wie Karte und Tabelle. */
const PROV_LABELS = { basis: "Basis", ziel2028: "Ziel 2028", ziel2031: "Ziel 2031", ist: "Ist", verlauf: "Verlauf" };

const MATURITY_TEXT = {
  "etabliert": "Baseline gemessen und Zielwert bestimmt.",
  "auszuwerten": "Baseline oder Zielwert stehen noch aus.",
  "zu-entwickeln": "Kennzahl wird bis 2028 entwickelt."
};

/* Fahrplan-Eintrag zu einer Kennzahl aus DATA.maturityRoadmap, sonst null */
function maturityRoadmapFor(kpi) {
  const tokens = String(kpi.name || "").toLowerCase().split(/[^a-zäöü0-9]+/).filter(t => t.length >= 7);
  if (!tokens.length) return null;
  const hit = (DATA.maturityRoadmap || []).find(r => {
    const what = String(r.what || "").toLowerCase();
    return tokens.some(t => what.includes(t));
  });
  return hit ? `${hit.when}: ${hit.what}` : null;
}

/* Lesbare Namen der Aufteilungen in data_basis.js */
const SPLIT_LABELS = {
  gesellschaft: "Gesellschaft", kostenblock: "Kostenblock", berichtsebene: "Berichtsebene",
  geschaftsfeld: "Geschäftsfeld", kanal: "Vertriebskanal", segment: "Segment",
  komponente: "Komponente", tool: "Tool", dimension: "Dimension", prozess: "Prozess",
  kernprozess: "Kernprozess", service: "Service", sparte: "Sparte", region: "Region",
  maklergroesse: "Maklergröße", anlageklasse: "Anlageklasse", bestand_neu: "Bestand / Neugeschäft"
};

/* Aufteilungen mit Zahlen; Einträge ohne Wert fallen weg. */
function splitGroupsOf(id) {
  const d = (typeof KPI_DATA !== "undefined" && KPI_DATA[id]) ? KPI_DATA[id] : null;
  if (!d || !d.splits) return [];
  return Object.entries(d.splits).map(([dim, arr]) => {
    const entries = (arr || []).map(x => {
      const vk = Object.keys(x).find(k => k !== "name" && typeof x[k] === "number");
      return vk ? { name: x.name, value: x[vk], stand: vk === "value2025" ? "2025" : null } : null;
    }).filter(Boolean);
    return { dim, label: SPLIT_LABELS[dim] || dim, stand: entries.length && entries[0].stand, entries };
  }).filter(g => g.entries.length);
}

const CADENCE_TEXT = { Quartal: "quartalsweise", Monatlich: "monatlich", Halbjährlich: "halbjährlich", Jährlich: "jährlich" };

/* Veränderung vom ersten zum letzten Wert, in derselben Schreibweise
   wie die Spalte „Δ Vorperiode". */
function changeText(k, first, last) {
  const d = UiLogic.periodDelta(last, first, {
    isRate: isRateUnit(k.unit),
    unitLabel: /%/.test(k.unit || "") ? "pp" : devUnit(k.unit),
    direction: k.direction
  });
  return d ? d.text : null;
}

function chatFacts(id) {
  const k = kpiById(id);
  if (!k || typeof KpiChat === "undefined") return null;
  const { kpi, status } = resolve(k);
  const perf = statusKind(k) === "perf";
  const dev = deviationInfo(k);
  const u = String(kpi.unit || "").replace(/\s*\(.*?\)/g, "").trim();
  const path = derivedPathOf(kpi).filter(r => typeof r.value === "number");
  const cumulative = pathOptsOf(kpi).cumulative;
  const iv = istView(k);
  const meas = actualPoints(id);
  const ytd = ytdProgress(kpi);
  const q = k.maturity === "zu-entwickeln" ? null : qualityOf(k);
  const a = DATA.actions.find(x => x.kpi === id);
  const d = (typeof KPI_DATA !== "undefined" && KPI_DATA[id]) ? KPI_DATA[id] : null;
  const dq = (d && d.dataQuality) || null;
  const entered = (typeof effectiveValue === "function") ? effectiveValue(id) : null;
  const first = meas.length ? meas[0] : null;
  const last = meas.length ? meas[meas.length - 1] : null;
  const prov = Object.entries(kpi.prov || {}).map(([field, level]) => ({ label: PROV_LABELS[field] || field, level }));
  const ausstehend = prov.filter(p => p.level === "ausstehend").map(p => p.label);
  const methodik = (kpi.methodology && kpi.methodology.open) || [];
  const splitGroups = splitGroupsOf(id);
  const anchorLabel = { basis: `Basis ${String(kpi.baseline.label || "").replace(/\s*\(.*?\)/g, "")}`, ziel2028: "Ziel 2028", ziel2031: "Ziel 2031" };

  /* Kumulierte KPIs (Konzernergebnis): Karte zeigt die Hochrechnung,
     der Status misst YTD gegen den Zielpfad. */
  let cumulativeText = null, ytdText = null;
  if (cumulative && iv.last) {
    const fy = UiLogic.latestFullYear(meas, null);
    const parts = [];
    if (fy) parts.push(`Jahresergebnis ${fy.year}: ${fmtNum(fy.value)} ${u}.`);
    if (iv.last.q !== 4) {
      parts.push(`${iv.last.year} bis Q${iv.last.q}: ${fmtNum(iv.last.ytd)} ${u}, hochgerechnet auf das Gesamtjahr ${fmtNum(Math.round(iv.last.value * 10) / 10)} ${u}.`);
      ytdText = `Das ist die Hochrechnung auf das Gesamtjahr. Tatsächlich erreicht sind bis Q${iv.last.q} ${iv.last.year} ${fmtNum(iv.last.ytd)} ${u}.`;
    }
    cumulativeText = parts.join("\n");
  }

  return {
    id, name: kpi.name, unit: u, lever: leverName(kpi.lever),
    rowLabel: kpi.row === 1 ? "Gewinnen wir wirtschaftlich?"
      : kpi.row === 2 ? "Wirken die vier Hebel?"
      : "Tun wir die richtigen Dinge?",

    status: {
      perf,
      label: perf ? statusLabel(status) : null,
      verdict: perf ? pathText(status, dev) : null,
      deviation: perf && dev ? dev.text : null,
      expected: perf && !ytd && !kpi.guardrail ? expectedValue(kpi) : null,
      guardrail: !!kpi.guardrail,
      ytd: perf && ytd ? { actual: ytd.actual, target: ytd.target, period: `Q${ytd.quarter} ${ytd.year}` } : null,
      thresholds: kpi.thresholds || null
    },
    ist: {
      has: typeof iv.value === "number",
      value: (cumulative && typeof iv.value === "number") ? Math.round(iv.value * 10) / 10 : iv.value,
      label: (cumulative && iv.last) ? `Hochrechnung ${iv.last.year}` : (kpi.current.label || null),
      entered: !!(entered && entered.source === "erfasst"),
      periods: meas.length,
      ytdText
    },
    plan: {
      has: path.length > 0,
      anchors: anchorsOf(kpi).map(x => ({ period: x.period, value: x.value, label: anchorLabel[x.source] || x.period })),
      target2028: targetPlain(kpi.target2028),
      target2031: targetPlain(kpi.target2031),
      documented: path.filter(r => r.source === "dokumentiert").length,
      note: kpi.pathNote || null
    },
    series: {
      has: meas.length >= 2,
      count: meas.length,
      from: first ? first.period : null,
      to: last ? last.period : null,
      first: first ? first.value : null,
      last: last ? last.value : null,
      change: first && last ? changeText(kpi, first.value, last.value) : null,
      cumulativeText,
      planLine: path.length > 0,
      gap: meas.length === 1
        ? `Erste Messung ${meas[0].period}. Für einen Verlauf braucht es zwei Werte.`
        : null
    },
    messung: {
      has: !!(kpi.formula || kpi.measurement || kpi.thresholds),
      formula: kpi.formula || null,
      type: (kpi.measurement && kpi.measurement.type) || null,
      detail: (kpi.measurement && kpi.measurement.detail) || null,
      thresholds: kpi.thresholds || null,
      note: kpi.maturity === "zu-entwickeln" ? "Die Methodik wird bis 2028 festgelegt." : null
    },
    verantwortung: {
      has: !!(kpi.owner || kpi.cadence || kpi.source),
      owner: kpi.owner || null,
      cadence: kpi.cadence ? (CADENCE_TEXT[kpi.cadence] || kpi.cadence) : null,
      source: kpi.source || null,
      steward: (dq && dq.steward) || null
    },
    belastbarkeit: {
      has: !!(prov.length || q),
      prov,
      quality: q ? q.pct : null,
      have: q ? q.have : null,
      expected: q ? q.expectedCount : null,
      lastUpdated: (dq && dq.lastUpdated) || null,
      sourceSystem: (dq && dq.sourceSystem) || null
    },
    action: a
      ? { has: true, ursache: a.ursache, massnahme: a.massnahme, owner: a.owner, frist: a.frist, status: a.status || "offen" }
      : { has: false },
    splits: { has: splitGroups.length > 0, groups: splitGroups },
    maturity: {
      has: !!kpi.maturity,
      label: maturityLabel(kpi.maturity) || null,
      explain: MATURITY_TEXT[kpi.maturity] || null,
      roadmap: maturityRoadmapFor(kpi),
      components: kpi.components || null
    },
    explain: { has: !!kpi.explain, text: kpi.explain || null },
    offen: {
      has: !!(methodik.length || ausstehend.length),
      methodik, ausstehend
    }
  };
}

/* ---------- Fragen-Panel im Detail-Modal ----------
   Vorschläge = beantwortbare Fragen; die übrigen werden als fehlend
   genannt. Freitext wird einer festen Frage zugeordnet. */
function chatParagraphs(text) {
  return String(text).split("\n").filter(l => l.trim())
    .map(l => `<p>${esc(l).replace(/\*\*(.+?)\*\*/g, "<b>$1</b>")}</p>`).join("");
}

function chatAnswerHtml(res) {
  if (!res) return "";
  return `<div class="chat-a${res.ok ? "" : " chat-a-none"}">${chatParagraphs(res.text)}</div>`;
}

function chatBlock(k) {
  if (typeof KpiChat === "undefined") return "";
  const facts = chatFacts(k.id);
  if (!facts) return "";
  const open = KpiChat.suggestedQuestions(facts);
  const missing = KpiChat.missingQuestions(facts);
  const buttons = open.map(q => `<button class="chat-q" type="button" data-chat-q="${esc(q.id)}">${esc(q.label)}</button>`).join("");
  const missingLine = missing.length
    ? `<div class="chat-missing">Nicht beantwortbar, weil die Angabe fehlt: ${missing.map(q => esc(q.label.replace(/\?$/, ""))).join(" · ")}.</div>`
    : "";
  return `
  <section class="chat-block" data-chat="${esc(k.id)}">
    <div class="chat-head">
      <h4>Fragen an diese Kennzahl</h4>
      <button class="chat-copy" type="button" data-chat-copy title="Kopiert die Angaben zu dieser Kennzahl, z. B. zum Einfügen in eine E-Mail">Als Text kopieren</button>
    </div>
    <div class="chat-suggest">
      ${buttons || `<span class="chat-empty">Für diese Kennzahl ist noch keine Frage beantwortbar: Baseline, Ziel oder Messung fehlen.</span>`}
    </div>
    <form class="chat-form" data-chat-form>
      <input class="chat-input" type="text" data-chat-input autocomplete="off" spellcheck="false"
             placeholder="Eigene Frage, z. B. Wer ist verantwortlich?" aria-label="Frage zu ${esc(k.name)}">
      <button class="chat-send" type="submit">Fragen</button>
    </form>
    <div class="chat-answers" data-chat-answers aria-live="polite"></div>
    <div class="chat-followup" data-chat-followup hidden>Eine neue Frage ersetzt die Antwort oben.</div>
    ${missingLine}
    <div class="chat-foot">Die Antworten stützen sich nur auf die Angaben in diesem Board.</div>
  </section>`;
}

function detailHTML(k) {
  const { kpi, status } = resolve(k);
  const edited = hasEdits(k.id);
  const m = kpi.methodology;
  const kind = statusKind(k);
  const dev = deviationInfo(k);
  const dl = deltaOf(k);
  const expected = expectedValue(kpi);
  const rowLabel = kpi.row === 1 ? "Gewinnen wir wirtschaftlich?" : kpi.row === 2 ? "Wirken die vier Hebel?" : "Tun wir die richtigen Dinge?";
  const action = DATA.actions.find(a => a.kpi === k.id);
  const series = chartSeries(k);
  /* Oben Status, Plan-Vergleich und Maßnahme; Steckbrief eingeklappt */
  const ytd = ytdProgress(kpi);
  /* Vergleichsbasis: Planwert der Periode, ohne Plan das anteilige Jahresziel */
  const ytdRef = ytd
    ? `${ytd.targetSource === "pfad" ? "Zielpfad" : "anteiliges Jahresziel"} ${fmtNum(ytd.target)} ${esc(kpi.unit)} — ${ytd.mode === "kumuliert" ? `Stand ${esc(ytd.year)}` : `YTD ${esc(ytd.year)}`} bis Q${ytd.quarter}${ytd.targetSource === "pfad" ? "" : ` (${Math.round((ytd.share || 0) * 100)} % des Jahresziels, ${ytd.linear ? "linear verteilt" : "saisonal gewichtet"})`}`
    : `Zielpfad ${expected !== null ? fmtNum(expected) : "—"} ${esc(kpi.unit)} für ${esc(kpi.current.label || "—")}`;
  const actionBlock = action
    ? `<div class="modal-action">
         <h4>Maßnahme</h4>
         <div class="ma-row"><span class="ma-label">Ursache</span><span>${esc(action.ursache)}</span></div>
         <div class="ma-row"><span class="ma-label">Maßnahme</span><span>${esc(action.massnahme)}</span></div>
         <div class="ma-row"><span class="ma-label">Owner</span><span>${esc(action.owner)} · Frist ${esc(action.frist)} · Status ${esc(action.status || "offen")}</span></div>
       </div>`
    : (kind === "perf" && ["amber", "red"].includes(status)
        ? `<div class="modal-action modal-action-missing"><h4>Maßnahme</h4><p class="missing-action">Keine Maßnahme erfasst.</p></div>`
        : "");
  return `
  <div class="modal-head">
    <div class="modal-head-main">
      <div class="modal-title">${esc(kpi.name)} ${kpi.vorschlag ? vorschlagChip() : ""} ${editedChip(k)}</div>
      <div class="modal-sub">${esc(leverName(kpi.lever))} · ${rowLabel}</div>
    </div>
    <button class="modal-close" aria-label="Schließen">×</button>
  </div>
  <div class="modal-body">
    <div class="modal-values">
      <div class="modal-val modal-val-status">
        <div class="modal-val-label">Status</div>
        <div class="modal-val-value">${statusInline(k)}</div>
      </div>
      <div class="modal-val modal-val-ist">
        <div class="modal-val-label">Ist</div>
        <div class="modal-val-value">${istView(k).html}</div>
        <div class="modal-val-sub">${esc(istView(k).sub)}</div>
      </div>
      <div class="modal-val modal-val-dev">
        <div class="modal-val-label">vs. Pfad</div>
        <div class="modal-val-value dev-${statusKey(k)}">${kind === "perf" ? esc(pathText(statusKey(k), dev)) : "—"}</div>
        <div class="modal-val-sub">${kind === "perf" ? ytdRef : "noch kein Pfadvergleich möglich"}</div>
      </div>
      <div class="modal-val modal-val-delta">
        <div class="modal-val-label">Δ Vorperiode</div>
        <div class="modal-val-value">${deltaHtml(k)}</div>
        <div class="modal-val-sub" aria-hidden="true">${dl ? `gegenüber ${esc(dl.against)}` : ""}</div>
      </div>
    </div>
    <div class="modal-targets">
      <span class="modal-val-t28">Ziel 2028 <span class="modal-val-value">${targetText(kpi.target2028)}</span></span>
      <span class="modal-val-t31">Ziel 2031 <span class="modal-val-value">${targetText(kpi.target2031)}</span></span>
    </div>
    ${drillBlock(k)}
    ${series ? `<div class="modal-spark">${detailChart(kpi, status)}<button class="link-btn" data-chart-range type="button">${CHART_FULL ? "nur bis 2028 zeigen" : "bis 2031 zeigen"}</button></div>` : ""}
    ${(() => {
      /* Herkunft des Plans unter dem Chart */
      const path = derivedPathOf(kpi);
      if (!path.length) return "";
      const docCount = path.filter(r => r.source === "dokumentiert").length;
      const a = anchorsOf(kpi);
      const parts = [];
      if (a.length >= 2) {
        /* Alle Eckwerte nennen */
        parts.push("gerechnet aus " + a.map(x =>
          `${fmtNum(x.value)} (${x.period})`).join(" → "));
      } else if (a.length === 1) {
        parts.push(`kein Plan — nur ein Eckwert (${fmtNum(a[0].value)}, ${a[0].period})`);
      } else {
        parts.push("kein numerischer Eckwert");
      }
      if (docCount) parts.push(`${docCount} Quartalswerte als Planannahme`);
      return `<div class="modal-pathnote">Plan: ${esc(parts.join(" · "))}.</div>`;
    })()}
    ${actionBlock}
    <div class="detail-block wide"><h4>Was misst diese Kennzahl?</h4><p>${esc(kpi.explain)}</p></div>
    ${kpi.pathNote ? `<div class="detail-block wide"><h4>Zielpfad</h4><p>${esc(kpi.pathNote)}</p></div>` : ""}
    ${kpi.interim ? `<div class="detail-block wide"><h4>Interim</h4><p>Bis zur Methodik-Freigabe gilt <button class="kpi-link" data-kpi-link="${kpi.interim}">${esc((kpiById(kpi.interim) || {}).name || kpi.interim)} →</button></p></div>` : ""}
    ${m ? `
    <div class="detail-block wide">
      <h4>Methodik (zu entwickeln)</h4>
      <p style="margin-bottom:6px"><b>Definition:</b> ${esc(m.definition)}</p>
      ${m.approach ? `<p style="margin-bottom:4px"><b>Vorgehen:</b></p><ul>${m.approach.map(a => `<li>${esc(a)}</li>`).join("")}</ul>` : ""}
      ${m.open ? `<p style="margin-top:6px"><b>Offene Punkte:</b> ${m.open.map(esc).join(" · ")}</p>` : ""}
    </div>` : ""}
    <details class="modal-steckbrief">
      <summary>Steckbrief — Formel, Quelle, Owner, Takt</summary>
      <div class="modal-grid">
        ${kpi.formula ? `<div class="detail-block"><h4>Formel</h4><p>${esc(kpi.formula)}</p></div>` : ""}
        ${kpi.measurement ? `<div class="detail-block"><h4>Messung</h4><p>${esc(kpi.measurement.type)} — ${esc(kpi.measurement.detail)}</p></div>` : ""}
        <div class="detail-block"><h4>Datenquelle</h4><p>${esc(kpi.source)}</p></div>
        <div class="detail-block"><h4>Owner</h4><p>${esc(kpi.owner)}</p></div>
        <div class="detail-block"><h4>Takt</h4><p>${esc(kpi.cadence)}</p></div>
        ${kpi.maturity ? `<div class="detail-block"><h4>Reifegrad</h4><p>${esc(maturityLabel(kpi.maturity))}</p></div>` : ""}
        ${kpi.thresholds ? `<div class="detail-block"><h4>Schwellenwerte (RAG)</h4><p>${esc(kpi.thresholds)}</p></div>` : ""}
        ${kpi.notes ? `<div class="detail-block"><h4>Hinweise</h4><p>${esc(kpi.notes)}</p></div>` : ""}
        ${kpi.components ? `<div class="detail-block wide"><h4>Komponenten</h4><p>${kpi.components.map(esc).join(" · ")}</p></div>` : ""}
      </div>
    </details>
    <details class="modal-steckbrief">
      <summary>Werte bearbeiten</summary>
      ${editForm(kpi)}
    </details>
    ${chatBlock(k)}
  </div>`;
}

function openDetail(id) {
  const k = kpiById(id);
  if (!k) return;
  closeDetail();
  const backdrop = document.createElement("div");
  backdrop.className = "modal-backdrop";
  backdrop.id = "detail-backdrop";
  backdrop.innerHTML = `<div class="modal" role="dialog" aria-modal="true" aria-label="${esc(k.name)}">${detailHTML(k)}</div>`;
  document.body.appendChild(backdrop);
  backdrop.addEventListener("click", e => {
    if (e.target === backdrop) { closeDetail(); return; }
    const link = e.target.closest && e.target.closest("[data-kpi-link]");
    if (link) { openDetail(link.dataset.kpiLink); return; }
    const row = e.target.closest && e.target.closest("[data-kpi]");
    if (row) openDetail(row.dataset.kpi);
  });
  document.body.classList.add("modal-open");
  bindDetail(backdrop, k);
  const closeBtn = $(".modal-close", backdrop);
  if (closeBtn) closeBtn.focus();
}

function closeDetail() {
  const b = $("#detail-backdrop");
  if (b) b.remove();
  document.body.classList.remove("modal-open");
}

function refreshModal(backdrop, id) {
  const k = kpiById(id);
  if (!k) return;
  const { kpi, status, computed } = resolve(k);
  const edited = hasEdits(id);
  const set = (sel, html) => { const el = $(sel, backdrop); if (el) el.innerHTML = html; };
  set(".modal-val-ist .modal-val-value", istView(k).html);
  set(".modal-val-ist .modal-val-sub", esc(istView(k).sub));
  set(".modal-val-t28 .modal-val-value", targetText(kpi.target2028));
  set(".modal-val-t31 .modal-val-value", targetText(kpi.target2031));
  set(".modal-val-status .modal-val-value", statusInline(k));
  set(".modal-val-delta .modal-val-value", deltaHtml(k));
  const title = $(".modal-title", backdrop);
  if (title) title.innerHTML = `${esc(kpi.name)} ${kpi.vorschlag ? vorschlagChip() : ""} ${editedChip(kpiById(id))}`;
  const resetBtn = $(".btn-reset-kpi", backdrop);
  if (resetBtn) resetBtn.disabled = !edited;
}

function bindDetail(backdrop, k) {
  $(".modal-close", backdrop).addEventListener("click", closeDetail);

  $$("[data-edit]", backdrop).forEach(inp => {
    inp.addEventListener("change", () => {
      const [group, key] = inp.dataset.edit.split(".");
      let v = inp.value;
      if (key === "value") v = v === "" ? null : parseFloat(v);
      EDITS[k.id] = EDITS[k.id] || {};
      EDITS[k.id][group] = EDITS[k.id][group] || {};
      EDITS[k.id][group][key] = v;
      saveEdits();
      const prev = (group === "current" && key === "value") ? (k.current && k.current.value) : null;
      if (group === "current" && key === "value") {
        addLogEntry({ actor: logActor(), kpi: k.id, kpiName: k.name, field: "Ist-Wert (Schnellkorrektur)", kind: v === null ? "gelöscht" : "korrigiert", oldValue: prev, newValue: v });
      }
      refreshModal(backdrop, k.id);
      render(CURRENT_VIEW, { noScroll: true });
    });
  });

  const resetBtn = $(".btn-reset-kpi", backdrop);
  if (resetBtn) resetBtn.addEventListener("click", () => {
    resetKpi(k.id);
    const modal = $(".modal", backdrop);
    if (modal) modal.innerHTML = detailHTML(k);
    bindDetail(backdrop, k);
    render(CURRENT_VIEW, { noScroll: true });
  });
  const rangeBtn = $("[data-chart-range]", backdrop);
  if (rangeBtn) rangeBtn.addEventListener("click", () => {
    CHART_FULL = !CHART_FULL;
    const modal = $(".modal", backdrop);
    if (modal) modal.innerHTML = detailHTML(k);
    bindDetail(backdrop, k);
  });
  bindChat(backdrop, k);
}

/* ---------- Fragen-Panel bedienen ----------
   Eine neue Frage ersetzt die vorige Antwort. */
function chatAnswer(backdrop, k, textOrId) {
  const box = $("[data-chat-answers]", backdrop);
  if (!box) return;
  const facts = chatFacts(k.id);
  const res = KpiChat.answerText(facts, textOrId);
  box.innerHTML = chatAnswerHtml(res);
  const frag = $("[data-chat-followup]", backdrop);
  if (frag) frag.hidden = false;
  box.scrollIntoView({ block: "nearest" });
}

function bindChat(backdrop, k) {
  if (typeof KpiChat === "undefined") return;
  const block = $(".chat-block", backdrop);
  if (!block) return;
  /* Klicks auf die Fragen per Delegation am Block */
  block.addEventListener("click", e => {
    const q = e.target.closest && e.target.closest("[data-chat-q]");
    if (q) chatAnswer(backdrop, k, q.dataset.chatQ);
  });
  /* Freitext per Formular (Enter) */
  const form = $("[data-chat-form]", backdrop);
  if (form) form.addEventListener("submit", e => {
    e.preventDefault();
    const inp = $("[data-chat-input]", backdrop);
    const v = inp ? inp.value : "";
    if (String(v).trim()) { chatAnswer(backdrop, k, v); inp.value = ""; }
  });
  /* Angaben der Kennzahl als Text in die Zwischenablage. */
  const copy = $("[data-chat-copy]", backdrop);
  if (copy) copy.addEventListener("click", () => {
    const facts = chatFacts(k.id);
    copyToClipboard(KpiChat.contextBlock(facts), copy);
  });
}

/* Kurze Rückmeldung am Knopf, danach wieder der ursprüngliche Text */
function flashButton(sel, text) {
  const btn = $(sel);
  if (!btn) return;
  const orig = btn.dataset.label || btn.textContent;
  btn.dataset.label = orig;
  btn.textContent = text;
  window.setTimeout(() => { btn.textContent = orig; }, 2200);
}

/* Zwischenablage mit Rückmeldung am Knopf; ohne navigator.clipboard
   über ein temporäres Textfeld. */
function copyToClipboard(text, btn) {
  const done = ok => { if (btn) btn.textContent = ok ? "Kopiert" : "Kopieren nicht möglich"; };
  const fallback = () => {
    try {
      const ta = document.createElement("textarea");
      ta.value = text;
      ta.setAttribute("readonly", "");
      ta.setAttribute("aria-hidden", "true");
      ta.setAttribute("tabindex", "-1");
      ta.className = "clip-helper";
      document.body.appendChild(ta);
      ta.select();
      const ok = document.execCommand("copy");
      ta.remove();
      done(ok);
    } catch (e) { done(false); }
  };
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(text).then(() => done(true), fallback);
  } else fallback();
  window.setTimeout(() => { if (btn) btn.textContent = "Als Text kopieren"; }, 2200);
}

/* ---------- Chart-Hover ----------
   Ein fixierter Tooltip für alle Charts (Board und Modal).
   - Verlauf (.spark, .dchart): nächster Datenpunkt zur Zeigerposition
   - Bullet-Leiste (.bullet): Marke unter dem Zeiger bzw. die nächste */
function ensureChartTip() {
  let tip = document.getElementById("chart-tip");
  if (!tip) {
    tip = document.createElement("div");
    tip.className = "chart-tooltip";
    tip.id = "chart-tip";
    tip.setAttribute("role", "tooltip");
    document.body.appendChild(tip);
  }
  return tip;
}

function hideChartTip() {
  $$(".spark-crosshair, .spark-hover-dot").forEach(el => { el.style.display = "none"; });
  const tip = document.getElementById("chart-tip");
  if (tip) tip.classList.remove("visible");
}

/* Umrechnung Viewport ↔ SVG über getScreenCTM(); ohne Matrix über
   das Element-Rechteck. */
function chartMapper(el, rect, vb) {
  const m = (el.getScreenCTM && vb && vb.width) ? el.getScreenCTM() : null;
  if (m && m.a && m.d) {
    return {
      mapX: v => m.a * v + m.e,
      mapY: v => m.d * v + m.f,
      toVbX: px => (px - m.e) / m.a
    };
  }
  return {
    mapX: v => rect.left + (v / vb.width) * rect.width,
    mapY: v => rect.top + (v / vb.height) * rect.height,
    toVbX: px => ((px - rect.left) / rect.width) * vb.width
  };
}

/* Nächster Datenpunkt zu einer Viewport-x-Position */
function nearestSeriesPoint(el, clientX) {
  const rect = el.getBoundingClientRect();
  const vb = el.viewBox.baseVal;
  const pts = JSON.parse(el.dataset.points || "[]");
  if (!pts.length || !vb || !vb.width) return null;
  const { mapX, mapY, toVbX } = chartMapper(el, rect, vb);
  const vbX = toVbX(clientX);
  let idx = 0, best = Infinity;
  pts.forEach((p, i) => {
    const d = Math.abs(p[0] - vbX);
    if (d < best) { best = d; idx = i; }
  });
  const p = pts[idx];
  return { idx, x: mapX(p[0]), y: mapY(p[1]), vbX: p[0], vbY: p[1] };
}

function showSeriesTip(el, e, cardEl) {
  const hit = nearestSeriesPoint(el, e.clientX);
  if (!hit) return false;
  const vals = JSON.parse(el.dataset.values || "[]");
  const periods = JSON.parse(el.dataset.periods || "[]");
  const unit = el.dataset.unit || "";
  /* Fadenkreuz und Punkt in viewBox-Koordinaten */
  const cross = el.querySelector(".spark-crosshair");
  const dot = el.querySelector(".spark-hover-dot");
  if (cross) { cross.setAttribute("x1", hit.vbX); cross.setAttribute("x2", hit.vbX); cross.style.display = ""; }
  if (dot) { dot.setAttribute("cx", hit.vbX); dot.setAttribute("cy", hit.vbY); dot.style.display = ""; }
  const tip = ensureChartTip();
  tip.innerHTML = `<span class="tt-year">${esc(periods[hit.idx] || "")}</span><span class="tt-val">${fmtNum(vals[hit.idx])}${unit ? ` ${esc(unit)}` : ""}</span>`;
  tip.classList.add("visible");
  placeTip(cardEl, hit.x, hit.y);
  return true;
}

/* Bullet-Leiste: Marke unter dem Zeiger, sonst die nächste */
function showBulletTip(el, e) {
  const unit = el.dataset.unit || "";
  const hovered = e.target.closest && e.target.closest("[data-v]");
  let marke = (hovered && el.contains(hovered)) ? hovered : null;
  if (!marke) {
    let best = Infinity;
    $$("[data-v]", el).forEach(node => {
      const b = node.getBoundingClientRect();
      const d = Math.abs((b.left + b.width / 2) - e.clientX);
      if (d < best) { best = d; marke = node; }
    });
  }
  if (!marke) return false;
  const b = marke.getBoundingClientRect();
  const tip = ensureChartTip();
  tip.innerHTML = `<span class="tt-label">${esc(marke.dataset.tip || "")}</span><span class="tt-val">${fmtNum(Number(marke.dataset.v))}${unit ? ` ${esc(unit)}` : ""}</span>`;
  tip.classList.add("visible");
  placeTip(el, b.left + b.width / 2, b.top + b.height / 2);
  return true;
}

/* Grenze, innerhalb der der Tooltip bleibt (Karte oder Dialog) */
function tipBoundsFor(el) {
  return el.closest(".modal") || el.closest(".knode") ||
         el.closest(".card") || el.closest(".board-row") || document.body;
}

function bindChartHover() {
  if (bindChartHover._bound) return;
  bindChartHover._bound = true;
  ensureChartTip();

  document.addEventListener("mousemove", e => {
    const target = e.target;
    if (!target || !target.closest) return;
    const series = target.closest(".spark, .dchart");
    const bullet = target.closest(".bullet");
    let shown = false;
    if (series) shown = showSeriesTip(series, e, tipBoundsFor(series));
    else if (bullet) shown = showBulletTip(bullet, e);
    if (!shown) {
      hideChartTip();
      return;
    }
    /* Nur ein Fadenkreuz zur Zeit */
    const active = series || bullet;
    $$(".spark-crosshair, .spark-hover-dot").forEach(node => {
      const host = node.closest(".spark, .dchart");
      if (host && host !== active) node.style.display = "none";
    });
  }, { passive: true });

  document.addEventListener("mouseleave", hideChartTip);
  window.addEventListener("scroll", hideChartTip, { passive: true });
}

/* Tooltip positionieren (Viewport-Koordinaten, position: fixed),
   begrenzt durch `boundsEl`. */
function placeTip(boundsEl, x, y) {
  const t = ensureChartTip();
  const bounds = boundsEl.getBoundingClientRect();
  const pad = 8;
  const tw = t.offsetWidth, th = t.offsetHeight;
  let left = x - tw / 2;
  let top = y - th - 12;
  const minL = bounds.left + pad;
  const maxL = bounds.right - tw - pad;
  const minT = bounds.top + pad;
  const maxT = bounds.bottom - th - pad;
  if (maxL >= minL) left = Math.max(minL, Math.min(left, maxL));
  if (maxT >= minT) top = Math.max(minT, Math.min(top, maxT));
  /* Unterhalb der klebenden Tab-Leiste halten */
  const V = pad;
  const bar = document.querySelector(".tabs-bar");
  const vTop = V + (bar ? bar.getBoundingClientRect().height : 0);
  const vBottom = window.innerHeight - V - th;
  const vLeft = V, vRight = window.innerWidth - V - tw;
  if (vBottom >= vTop) top = Math.max(vTop, Math.min(top, vBottom));
  if (vRight >= vLeft) left = Math.max(vLeft, Math.min(left, vRight));
  t.style.left = `${left}px`;
  t.style.top = `${top}px`;
}

/* ---------- Interaktion ---------- */
function onViewClick(e) {
  const t = e.target;
  if (!t.closest) return;
  const link = t.closest("[data-kpi-link]");
  if (link) { openDetail(link.dataset.kpiLink); return; }
  const goto = t.closest("[data-goto-lever]");
  if (goto) { location.hash = goto.dataset.gotoLever; return; }
  /* --- Datenpflege --- */
  const dutyBtn = t.closest("[data-duty-goto]");
  if (dutyBtn) { guardSheet(() => selectSheetKpi(dutyBtn.dataset.dutyGoto, true, dutyBtn.dataset.dutyPeriod)); return; }
  const pillBtn = t.closest("[data-sheet-kpi]");
  if (pillBtn) {
    if (pillBtn.dataset.sheetKpi === SHEET_KPI) return;
    guardSheet(() => selectSheetKpi(pillBtn.dataset.sheetKpi, false));
    return;
  }
  if (t.closest("[data-unsaved-save]")) { if (saveSheet()) { updateDutyBadge(); runPending(); } return; }
  if (t.closest("[data-unsaved-discard]")) { render(CURRENT_VIEW, { noScroll: true }); runPending(); return; }
  if (t.closest("[data-unsaved-cancel]")) { PENDING = null; const b = $("#unsaved-bar"); if (b) b.hidden = true; return; }
  /* Neuzeichnen nur über die Ungespeichert-Prüfung */
  if (t.closest("[data-log-all]")) { guardSheet(() => { LOG_ALL = !LOG_ALL; render(CURRENT_VIEW, { noScroll: true }); }); return; }
  const pasteBtn = t.closest("[data-paste-toggle]");
  if (pasteBtn) { const p = $("#sheet-paste"); if (p) p.hidden = !p.hidden; return; }
  const fillBtn = t.closest("[data-paste-fill]");
  if (fillBtn) { applyPaste(); return; }
  const saveBtn = t.closest("[data-save-sheet]");
  if (saveBtn) { saveSheet(); updateDutyBadge(); return; }
  const expLog = t.closest("[data-export-log]");
  if (expLog) { downloadFile("aenderungs-log.md", changelogMarkdown(), "text/markdown"); return; }
  const expState = t.closest("[data-export-state]");
  if (expState) { downloadFile("kpi-daten-export.json", JSON.stringify(exportState(), null, 2), "application/json"); return; }
  const impState = t.closest("[data-import-state]");
  if (impState) { guardSheet(() => { const f = $("#import-file"); if (f) f.click(); }); return; }
  const clearBtn = t.closest("[data-clear-entry]");
  if (clearBtn) {
    guardSheet(() => {
      if (confirm("Alle lokal erfassten und geänderten Werte löschen? Das Änderungs-Log bleibt bestehen.")) {
        clearEnteredValues(); resetAllEdits(); render(CURRENT_VIEW, { noScroll: true }); updateDutyBadge(); flashButton("[data-clear-entry]", "Gelöscht");
      }
    });
    return;
  }
  const sel = window.getSelection && window.getSelection().toString();
  if (sel) return;
  /* Der Eckwerte-Knopf speichert ebenfalls das ganze Formular. */
  const saveAnchorsBtn = t.closest("[data-save-anchors]");
  if (saveAnchorsBtn) {
    const n = anchorDirtyCount();
    saveSheet();
    render(CURRENT_VIEW, { noScroll: true });
    const btn = $("[data-save-anchors]");
    if (btn && n) {
      btn.textContent = `${n} ${n === 1 ? "Eckwert" : "Eckwerte"} gespeichert`;
      btn.classList.add("saved");
      setTimeout(() => { btn.classList.remove("saved"); }, 2200);
    }
    return;
  }
  const basisBtn = t.closest("[data-basis-kpi]");
  if (basisBtn) {
    if (basisBtn.dataset.basisKpi === BASIS_KPI) { scrollToSheet(); return; }
    guardSheet(() => { BASIS_KPI = basisBtn.dataset.basisKpi; render(CURRENT_VIEW, { noScroll: true }); });
    return;
  }
  const card = t.closest("[data-kpi]");
  if (card && card.dataset.kpi) { openDetail(card.dataset.kpi); return; }
}

/* ---------- Router ----------
   Board, vier Hebel, Datenbasis, Datenpflege. */
const VIEWS = {
  board: { label: "Board", render: viewBoard, primary: true },
  mitarbeitende: { label: "Mitarbeitende", render: () => viewLever("mitarbeitende"), primary: true },
  prozesse: { label: "Prozesse", render: () => viewLever("prozesse"), primary: true },
  kunden: { label: "Kunden", render: () => viewLever("kunden"), primary: true },
  vermittler: { label: "Vermittler", render: () => viewLever("vermittler"), primary: true },
  datenbasis: { label: "Datenbasis", render: viewDatenbasis },
  datenpflege: { label: "Datenpflege", render: viewDatenpflege }
};

/* Alte oder unbekannte Hashes: #lexikon → #datenbasis, sonst #board */
function resolveHash(hash) {
  const id = hash.replace("#", "") || "board";
  if (id === "lexikon") return "datenbasis";
  if (id === "portfolio") return "board";
  if (!VIEWS[id]) return "board";
  return id;
}

function visibleViewIds() { return Object.keys(VIEWS); }

function renderTabs() {
  const bar = $(".tabs-bar");
  if (!bar) return;
  const ids = visibleViewIds();
  const primary = ids.filter(id => VIEWS[id].primary);
  const secondary = ids.filter(id => !VIEWS[id].primary);
  bar.innerHTML = `
    <div class="tabs-bar-inner">
      <div class="tabs" id="tabs">
        ${primary.map(id => `<button class="tab" data-view="${id}">${VIEWS[id].label}</button>`).join("")}
        <span class="tabs-sep" aria-hidden="true"></span>
        ${secondary.map(id => `<button class="tab tab-secondary" data-view="${id}">${VIEWS[id].label}</button>`).join("")}
      </div>
    </div>`;
  $$(".tab").forEach(t => t.addEventListener("click", () => { location.hash = t.dataset.view; }));
}

function render(viewId, opts = {}) {
  const changed = viewId !== CURRENT_VIEW;
  CURRENT_VIEW = viewId;
  const v = VIEWS[viewId] || VIEWS.board;
  const viewEl = $("#view");
  viewEl.innerHTML = v.render();
  /* Im Board Chips unterdrücken */
  viewEl.classList.toggle("view-quiet", viewId === "board");
  /* Tooltip einmal je Sitzung binden (Delegation) */
  bindChartHover();
  hideChartTip();
  $$(".tab").forEach(t => t.classList.toggle("active", t.dataset.view === viewId));
  if (location.hash.replace("#", "") !== viewId) history.replaceState(null, "", "#" + viewId);
  updateDutyBadge();
  if (changed && !opts.noScroll) window.scrollTo({ top: 0 });
}

function init() {
  renderTabs();
  $("#view").addEventListener("click", onViewClick);
  $("#view").addEventListener("input", onViewInput);
  $("#view").addEventListener("change", onViewChange);
  window.addEventListener("hashchange", () => {
    const next = resolveHash(location.hash);
    if (hasDirtySheet() && dirtyCount()) {
      history.replaceState(null, "", "#" + CURRENT_VIEW);
      showUnsavedBar(() => { location.hash = next; });
      return;
    }
    render(next);
  });
  window.addEventListener("beforeunload", e => {
    if (hasDirtySheet() && dirtyCount()) { e.preventDefault(); e.returnValue = ""; }
  });
  document.addEventListener("keydown", e => {
    const a = document.activeElement;
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "s" && $("[data-save-sheet]")) {
      e.preventDefault();
      if (dirtyCount()) { saveSheet(); updateDutyBadge(); }
      return;
    }
    if (e.key === "Enter" && a && a.classList && a.classList.contains("sheet-input")) {
      e.preventDefault();
      moveSheetFocus(a, e.shiftKey ? -1 : 1);
      return;
    }
    if (e.key === "Escape") { closeDetail(); return; }
    /* Karten sind role=button: Enter/Leertaste öffnen */
    if (e.key === "Enter" || e.key === " ") {
      const el = document.activeElement;
      if (el && el.dataset && el.dataset.kpi) { e.preventDefault(); openDetail(el.dataset.kpi); }
    }
  });
  renderDutyBadge();
  /* Stand aus DATA.meta.asOf */
  const metaDate = $("#meta-date");
  if (metaDate) metaDate.textContent = DATA.meta.asOf;
  render(resolveHash(location.hash));
}

document.addEventListener("DOMContentLoaded", init);