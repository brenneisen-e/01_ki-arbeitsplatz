Option Explicit
' ============================================================================
' modLaden – Rohdaten (OPAG- und Verbund-Rueckstandsabzuege) laden, Anwesenheitsliste importieren
'
' Ablauf "Neue Daten laden":
'   1. Ordner "Rohdaten" (relativ zur Master-Datei, Konfiguration!B3) nach Excel-Dateien durchsuchen
'   2. In jeder Datei jedes Blatt pruefen: Stichtag aus "Rückstandsstichtag = …", Quelle aus den Spaltenkoepfen
'      (OPS_AUFTR_ID vorhanden = OPAG, sonst Verbund)
'   3. Alle gefundenen Staende nach Stichtag und Quelle sortieren, bereits geladene ueberspringen
'   4. Je Stand: Rueckstand je Sparte/VSS/Themenpostkorb/GeVo mit Altersklassen zaehlen,
'      Eingaenge (Schluessel neu gegenueber dem letzten Stand) und Abgaenge (Schluessel weg) bestimmen,
'      Zeilen an "Fakten" anhaengen, Snapshot der Schluessel ersetzen, Zeile in "Verlauf" ergaenzen
'   5. Ladeprotokoll fortschreiben, neu berechnen
' Fremde Dateien werden ohne Makros, ohne Dialoge und schreibgeschuetzt geoeffnet (QuelleOeffnen).
' Waehrend des Ladens ist die Eingabe gesperrt (LadeModusEin/-Aus), Fehler raeumen immer auf.
' ============================================================================

Private Const FAKTEN_SPALTEN As Long = 16       ' A..O Daten, P = Aktiv (Formel)
Private Const FAKTEN_MAX As Long = 300000       ' Ende der benannten Bereiche F_* (Fakten!X2:X300000)
Private Const VERLAUF_MAX As Long = 1000        ' Ende der Verlauf-Bezuege
Private Const MAX_KOPFZEILEN As Long = 15
Private Const TRENNER As String = "|"
Public Const MA_START As Long = 5               ' erste Mitarbeiterzeile im Blatt Mitarbeiter
Public Const MA_ZEILEN As Long = 60             ' reservierte Mitarbeiterzeilen
Public Const PL_VERSATZ As Long = 2             ' Planung-Zeile = Mitarbeiter-Zeile + 2 (Planung beginnt in Zeile 7)
Public Const PK_VON As Long = 5                 ' Filter!B5:B44 Themenpostkoerbe
Public Const PK_BIS As Long = 44

Private Type Stand
    Datei As String
    Blatt As String
    Quelle As String
    Stichtag As Date
End Type

Private calcVorher As XlCalculation
Private logPfad As String                      ' Ladelog.txt neben der Master-Datei
Private importMeldung As String                ' Ergebnis des letzten Anwesenheits-Imports (fuer die gemeinsame Meldung)
Private lademodusAktiv As Boolean

' ---------------------------------------------------------------- Lademodus (Sperre, Zustand sichern und zurueckgeben)
Private Sub LadeModusEin(titel As String)
    If Not lademodusAktiv Then calcVorher = Application.Calculation
    lademodusAktiv = True
    modFortschritt.FortschrittZeigen titel
    Application.ScreenUpdating = False
    Application.EnableEvents = False            ' kein SelectionChange, keine Ereignisse fremder Dateien
    ' Application.Interactive wird bewusst nicht gesetzt: zusammen mit DoEvents und Workbooks.Open kann Excel abstuerzen.
    ' Die Schaltflaechen pruefen stattdessen LadenLaeuft() und tun waehrend des Ladens nichts.
    Application.Calculation = xlCalculationManual
End Sub

Private Sub LadeModusAus()
    On Error Resume Next
    modFortschritt.FortschrittSchliessen
    If calcVorher = 0 Then calcVorher = xlCalculationAutomatic
    Application.Calculation = calcVorher
    Application.EnableEvents = True
    Application.StatusBar = False
    Application.ScreenUpdating = True
    lademodusAktiv = False
    On Error GoTo 0
End Sub

Public Function LadenLaeuft() As Boolean
    LadenLaeuft = lademodusAktiv
End Function

Public Sub LogSchreiben(text As String)
    ' Ladelog.txt neben der Master-Datei: jeder Schritt eine Zeile (Datei wird je Zeile geoeffnet und geschlossen,
    ' damit nach einem Absturz von Excel der letzte Schritt sichtbar ist)
    Dim f As Integer
    On Error Resume Next
    If Len(logPfad) = 0 Then logPfad = BasisOrdner() & Application.PathSeparator & "Ladelog.txt"
    f = FreeFile
    Open logPfad For Append As #f
    Print #f, Format(Now, "yyyy-mm-dd hh:nn:ss") & "  " & text
    Close #f
    On Error GoTo 0
End Sub

' ---------------------------------------------------------------- Einstieg
Public Sub NeueDatenLaden()
    Dim ordner As String, datei As String, pfad As String
    Dim staende() As Stand, n As Long, i As Long, j As Long, st As Stand
    Dim wbQ As Workbook, ws As Worksheet
    Dim geladen As Long, uebersprungen As Long, meldung As String
    Dim dateien() As String, nDateien As Long, d As Long, protokolliert As Object

    If lademodusAktiv Then Exit Sub
    On Error Resume Next
    ordner = RohdatenOrdner()
    If Err.Number <> 0 Then
        modFortschritt.HinweisZeigen "Fehler", Err.Description, True
        Exit Sub
    End If
    On Error GoTo 0
    If Not OrdnerVorhanden(ordner) Then
        modFortschritt.HinweisZeigen "Fehler", "Der Rohdaten-Ordner wurde nicht gefunden:" & vbCrLf & ordner & vbCrLf & vbCrLf & _
               "Bitte den Ordner neben der Master-Datei anlegen oder den Pfad in 'Konfiguration' anpassen " & _
               "(bei OneDrive/SharePoint den lokalen Ordner in Konfiguration!B7).", True
        Exit Sub
    End If

    LogSchreiben "---- NeueDatenLaden Start, Ordner " & ordner
    LadeModusEin "Rohdaten werden geladen"
    Application.StatusBar = "Rohdaten werden gesucht …"
    On Error GoTo Fehler

    ' 1. Dateien sammeln (Dir nicht verschachteln), nur echte Excel-Endungen
    nDateien = 0
    datei = Dir(ordner & "*.xls*")
    Do While Len(datei) > 0
        If Left$(datei, 2) <> "~$" And IstExcelDatei(datei) Then
            ReDim Preserve dateien(0 To nDateien)
            dateien(nDateien) = datei
            nDateien = nDateien + 1
        End If
        datei = Dir()
    Loop
    ' 2. Staende erkennen
    n = 0
    For d = 0 To nDateien - 1
        datei = dateien(d)
        modFortschritt.FortschrittSetzen 0.05 + 0.25 * d / IIf(nDateien = 0, 1, nDateien), "Prüfe " & datei
        pfad = ordner & datei
        LogSchreiben "Pruefe Datei " & datei
        Set wbQ = QuelleOeffnen(pfad)
        LogSchreiben "  geoeffnet, Blaetter: " & wbQ.Worksheets.Count
        For Each ws In wbQ.Worksheets
            If BlattErkennen(ws, st) Then
                LogSchreiben "  erkannt: " & ws.Name & " = " & st.Quelle & " " & Format(st.Stichtag, "dd.mm.yyyy")
                st.Datei = datei
                st.Blatt = ws.Name
                ReDim Preserve staende(0 To n)
                staende(n) = st
                n = n + 1
            End If
        Next ws
        wbQ.Close SaveChanges:=False
        Set wbQ = Nothing
        LogSchreiben "  geschlossen"
    Next d

    If n = 0 Then
        LadeModusAus
        modFortschritt.HinweisZeigen "Hinweis", "Im Ordner " & ordner & " wurde kein Rückstandsabzug erkannt." & vbCrLf & _
               "Erwartet werden Blätter mit 'Rückstandsstichtag = …' in den ersten Zeilen und einer Kopfzeile mit 'Themenpostkorb'.", False
        Exit Sub
    End If

    ' 3. sortieren nach Stichtag, dann Quelle
    For i = 0 To n - 2
        For j = i + 1 To n - 1
            If staende(j).Stichtag < staende(i).Stichtag Or _
               (staende(j).Stichtag = staende(i).Stichtag And staende(j).Quelle < staende(i).Quelle) Then
                st = staende(i): staende(i) = staende(j): staende(j) = st
            End If
        Next j
    Next i

    ' 4. verarbeiten (Protokoll einmal lesen statt je Stand zu suchen)
    Set protokolliert = ProtokollLesen()
    For i = 0 To n - 1
        If protokolliert.Exists(staende(i).Quelle & TRENNER & CLng(staende(i).Stichtag)) Then
            uebersprungen = uebersprungen + 1
        ElseIf staende(i).Stichtag < LetzterStand(staende(i).Quelle) Then
            Protokoll staende(i), 0, 0, 0, 0, "übersprungen: Stichtag liegt vor dem zuletzt geladenen Stand (" & Format(LetzterStand(staende(i).Quelle), "dd.mm.yyyy") & ")"
            protokolliert.Add staende(i).Quelle & TRENNER & CLng(staende(i).Stichtag), True
            uebersprungen = uebersprungen + 1
        Else
            Application.StatusBar = "Verarbeite " & staende(i).Quelle & " " & Format(staende(i).Stichtag, "dd.mm.yyyy") & " (" & staende(i).Datei & ") …"
            modFortschritt.FortschrittSetzen 0.3 + 0.6 * i / n, "Verarbeite " & staende(i).Quelle & " " & Format(staende(i).Stichtag, "dd.mm.yyyy") & " (" & staende(i).Datei & ")"
            LogSchreiben "Stand " & staende(i).Quelle & " " & Format(staende(i).Stichtag, "dd.mm.yyyy") & " aus " & staende(i).Datei & " / " & staende(i).Blatt
            StandVerarbeiten ordner, staende(i)
            LogSchreiben "  Stand fertig"
            protokolliert.Add staende(i).Quelle & TRENNER & CLng(staende(i).Stichtag), True
            geladen = geladen + 1
        End If
    Next i

    ' 5. neu berechnen
    modFortschritt.FortschrittSetzen 0.92, "Kennzahlen und Diagramme werden neu berechnet"
    LogSchreiben "Neuberechnung"
    Application.Calculation = xlCalculationAutomatic
    Application.Calculate
    LogSchreiben "Diagramme anpassen"
    modCockpit.DiagrammeAnpassen True
    LogSchreiben "Fertig: " & geladen & " geladen, " & uebersprungen & " uebersprungen"
    modFortschritt.FortschrittSetzen 1, "Fertig"
    LadeModusAus
    If geladen = 0 Then
        meldung = "Keine neuen Stände geladen"
    Else
        meldung = StaendeText(geladen) & " geladen"
    End If
    If uebersprungen > 0 Then meldung = meldung & ", " & StaendeText(uebersprungen) & " bereits vorhanden oder übersprungen"
    If IsEmpty(ThisWorkbook.Worksheets("Mitarbeiter").Range("A" & MA_START).Value) Then
        ' Noch keine MAK-Liste geladen: direkt im Anschluss importieren, eine gemeinsame Meldung am Ende
        AnwesenheitLaden True
        If Len(importMeldung) > 0 Then meldung = meldung & "." & vbCrLf & importMeldung
    End If
    modFortschritt.HinweisZeigen "Fertig", meldung & ".", False
    Exit Sub

Fehler:
    ' Beschreibung zuerst sichern: jedes On Error in einer aufgerufenen Prozedur leert das Err-Objekt
    Dim fehlertext As String
    fehlertext = "Fehler " & Err.Number & ": " & Err.Description
    On Error Resume Next
    LogSchreiben "FEHLER " & fehlertext
    If Not wbQ Is Nothing Then wbQ.Close SaveChanges:=False
    Application.Calculation = xlCalculationAutomatic
    Application.Calculate
    LadeModusAus
    modFortschritt.HinweisZeigen "Fehler", "Fehler beim Laden: " & fehlertext & vbCrLf & vbCrLf & "Bis dahin geladen: " & StaendeText(geladen) & _
           ", übersprungen: " & StaendeText(uebersprungen) & ". Bereits geladene Stände bleiben erhalten.", True
End Sub

' "1 Stand" / "3 Stände" – Zaehlwort mit korrektem Singular und Plural
Private Function StaendeText(n As Long) As String
    If n = 1 Then
        StaendeText = "1 Stand"
    Else
        StaendeText = n & " Stände"
    End If
End Function

' ---------------------------------------------------------------- Fremde Datei sicher oeffnen
Private Function IstExcelDatei(datei As String) As Boolean
    Select Case LCase$(Mid$(datei, InStrRev(datei, ".") + 1))
        Case "xlsx", "xlsm", "xlsb", "xls": IstExcelDatei = True
    End Select
End Function

Private Function QuelleOeffnen(pfad As String) As Workbook
    ' Ohne Makros (AutomationSecurity), ohne Dialoge, schreibgeschuetzt; bereits offene Datei wird nicht erneut geoeffnet
    Dim sicherheit As MsoAutomationSecurity, nm As String, wb As Workbook
    Dim fehlerNr As Long, fehlerText As String
    nm = Mid$(pfad, InStrRev(pfad, Application.PathSeparator) + 1)
    On Error Resume Next
    Set wb = Workbooks(nm)
    On Error GoTo 0
    If Not wb Is Nothing Then Err.Raise vbObjectError + 8, , "Die Datei " & nm & " ist bereits in Excel geöffnet. Bitte schließen und erneut laden."
    sicherheit = Application.AutomationSecurity
    Application.AutomationSecurity = msoAutomationSecurityForceDisable
    Application.DisplayAlerts = False
    On Error Resume Next
    Set wb = Workbooks.Open(FileName:=pfad, UpdateLinks:=0, ReadOnly:=True, IgnoreReadOnlyRecommended:=True)
    fehlerNr = Err.Number: fehlerText = Err.Description
    On Error GoTo 0
    Application.DisplayAlerts = True
    Application.AutomationSecurity = sicherheit
    If fehlerNr <> 0 Then Err.Raise fehlerNr, , "Datei " & nm & " konnte nicht geöffnet werden: " & fehlerText & vbCrLf & _
        "(Aus dem Internet oder Teams heruntergeladene Dateien: Eigenschaften > 'Zulassen' setzen oder den Ordner als vertrauenswürdigen Speicherort eintragen.)"
    If wb Is Nothing Then Err.Raise vbObjectError + 9, , "Datei " & nm & " wurde in der geschützten Ansicht geöffnet und kann nicht gelesen werden."
    Set QuelleOeffnen = wb
End Function

' ---------------------------------------------------------------- Blatt erkennen
Private Function BlattErkennen(ws As Worksheet, ByRef st As Stand) As Boolean
    Dim r As Long, c As Long, t As String, kopf As Long, letzteSpalte As Long
    Dim stichtag As Date, gefunden As Boolean, kopfdaten As Variant
    BlattErkennen = False
    If ws.UsedRange.Rows.Count < 3 Then Exit Function
    letzteSpalte = ws.UsedRange.Column + ws.UsedRange.Columns.Count - 1
    kopfdaten = ws.Range(ws.Cells(1, 1), ws.Cells(MAX_KOPFZEILEN, letzteSpalte)).Value2     ' MAX_KOPFZEILEN >= 2 -> immer 2D
    kopf = 0
    For r = 1 To MAX_KOPFZEILEN
        For c = 1 To letzteSpalte
            t = Trim$(CStr(Nz(kopfdaten(r, c))))
            If Not gefunden And InStr(1, t, "stichtag", vbTextCompare) > 0 Then
                stichtag = StichtagAusText(t)
                If stichtag > 0 Then gefunden = True
            End If
            If t = "Themenpostkorb" Then kopf = r
        Next c
        If kopf > 0 Then Exit For
    Next r
    If kopf = 0 Or Not gefunden Then Exit Function
    st.Stichtag = stichtag
    st.Quelle = "Verbund"
    For c = 1 To letzteSpalte
        If UCase$(Trim$(CStr(Nz(kopfdaten(kopf, c))))) = "OPS_AUFTR_ID" Then st.Quelle = "OPAG"
    Next c
    BlattErkennen = True
End Function

Public Function StichtagAusText(t As String) As Date
    ' "Rückstandsstichtag = Mittwoch, 23. September 2026" / "= 23. September 2026" / "= 23.09.2026" -> 23.09.2026
    Dim s As String, teile() As String, tag As Long, jahr As Long, monat As Long, i As Long
    Dim monate As Variant
    monate = Array("januar", "februar", "märz", "april", "mai", "juni", "juli", "august", "september", "oktober", "november", "dezember")
    s = t
    If InStr(s, "=") > 0 Then s = Mid$(s, InStr(s, "=") + 1)
    If InStr(s, ",") > 0 Then s = Mid$(s, InStrRev(s, ",") + 1)
    s = Trim$(s)
    ' numerisches Datum dd.mm.yyyy
    teile = Split(s, ".")
    If UBound(teile) = 2 Then
        If IsNumeric(Trim$(teile(0))) And IsNumeric(Trim$(teile(1))) And IsNumeric(Trim$(teile(2))) Then
            If Len(Trim$(teile(2))) = 4 Then
                StichtagAusText = DateSerial(CLng(teile(2)), CLng(teile(1)), CLng(teile(0)))
                Exit Function
            End If
        End If
    End If
    s = Trim$(Replace(s, ".", " "))
    Do While InStr(s, "  ") > 0: s = Replace(s, "  ", " "): Loop
    teile = Split(s, " ")
    If UBound(teile) < 2 Then Exit Function
    If Not IsNumeric(teile(0)) Or Not IsNumeric(teile(2)) Then Exit Function
    tag = CLng(teile(0)): jahr = CLng(teile(2))
    For i = 0 To 11
        If LCase$(teile(1)) = monate(i) Then monat = i + 1
    Next i
    If monat = 0 Then Exit Function
    StichtagAusText = DateSerial(jahr, monat, tag)
End Function

' ---------------------------------------------------------------- Stand verarbeiten
Private Sub StandVerarbeiten(ordner As String, st As Stand)
    Dim wbQ As Workbook, ws As Worksheet, daten As Variant, kopfdaten As Variant
    Dim kopf As Long, r As Long, c As Long, letzteZeile As Long, letzteSpalte As Long
    Dim cVss As Long, cOb As Long, cLnr As Long, cPk As Long, cAlt As Long, cGevo As Long, cAuf As Long, cArb As Long
    Dim sparten As Object, alt As Object, neu As Object, agg As Object
    Dim key As String, vss As String, sparte As String, pk As String, gevo As String, typ As String, nr As Long
    Dim aggKey As String, werte As Variant, k As Variant, letzte As Range
    Dim zeilen As Long, rueckstand As Long, eingang As Long, abgang As Long

    Set sparten = SpartenZuordnung()
    Set alt = SnapshotLesen(st.Quelle)          ' Nothing beim ersten Stand
    Set neu = CreateObject("Scripting.Dictionary")
    Set agg = CreateObject("Scripting.Dictionary")
    On Error GoTo Fehler

    LogSchreiben "  oeffne " & st.Datei
    Set wbQ = QuelleOeffnen(ordner & st.Datei)
    Set ws = wbQ.Worksheets(st.Blatt)
    letzteSpalte = ws.UsedRange.Column + ws.UsedRange.Columns.Count - 1
    LogSchreiben "  Blatt " & st.Blatt & ", Spalten bis " & letzteSpalte
    kopfdaten = ws.Range(ws.Cells(1, 1), ws.Cells(MAX_KOPFZEILEN, letzteSpalte)).Value2
    For r = 1 To MAX_KOPFZEILEN
        For c = 1 To letzteSpalte
            If Trim$(CStr(Nz(kopfdaten(r, c)))) = "Themenpostkorb" Then kopf = r
        Next c
        If kopf > 0 Then Exit For
    Next r
    For c = 1 To letzteSpalte
        Select Case UCase$(Trim$(CStr(Nz(kopfdaten(kopf, c)))))
            Case "VERWALTUNGSSYSTEMSCHLÜSSEL": cVss = c
            Case "ORDNUNGSBEGRIFF": cOb = c
            Case "VORG_VERBU_LNR": cLnr = c
            Case "THEMENPOSTKORB": cPk = c
            Case "RÜCKSTANDSALTER_TAGE": cAlt = c
            Case "GEVO_SL": cGevo = c
            Case "OPS_AUFTR_ID": cAuf = c
            Case "OPS_ARBGUT_LNR": cArb = c
        End Select
    Next c
    If cVss = 0 Or cOb = 0 Or cLnr = 0 Or cPk = 0 Or cAlt = 0 Or cGevo = 0 Then
        Err.Raise vbObjectError + 1, , "Spaltenköpfe unvollständig in " & st.Datei & " / " & st.Blatt
    End If
    ' letzte belegte Zeile auch bei ausgeblendeten/gefilterten Zeilen
    Set letzte = ws.Columns(cVss).Find(What:="*", LookIn:=xlValues, SearchOrder:=xlByRows, SearchDirection:=xlPrevious)
    If letzte Is Nothing Then letzteZeile = kopf Else letzteZeile = letzte.Row
    If letzteZeile <= kopf Then
        wbQ.Close SaveChanges:=False
        Set wbQ = Nothing
        Protokoll st, 0, 0, 0, 0, "keine Datensätze unter der Kopfzeile"
        Exit Sub
    End If
    LogSchreiben "  lese Zeilen " & (kopf + 1) & " bis " & letzteZeile
    daten = ws.Range(ws.Cells(kopf + 1, 1), ws.Cells(letzteZeile, letzteSpalte)).Value2
    wbQ.Close SaveChanges:=False
    Set wbQ = Nothing
    LogSchreiben "  Quelle geschlossen, zaehle"

    ' Rueckstand, Altersklassen, Eingaenge
    For r = 1 To UBound(daten, 1)
        vss = Sauber(daten(r, cVss))
        If Len(vss) > 0 Then
            zeilen = zeilen + 1
            key = vss & TRENNER & Sauber(daten(r, cOb)) & TRENNER & Sauber(daten(r, cLnr))
            If st.Quelle = "OPAG" Then key = key & TRENNER & Sauber(daten(r, cAuf)) & TRENNER & Sauber(daten(r, cArb))
            If sparten.Exists(vss) Then sparte = sparten(vss) Else sparte = "Sonstige"
            pk = PostkorbNorm(CStr(Nz(daten(r, cPk))))
            gevo = Verdichten(CStr(Nz(daten(r, cGevo))))
            aggKey = sparte & TRENNER & vss & TRENNER & pk & TRENNER & gevo
            If Not agg.Exists(aggKey) Then agg.Add aggKey, Array(0, 0, 0, 0, 0, 0, 0)
            werte = agg(aggKey)
            werte(0) = werte(0) + 1
            werte(3 + AlterKlasse(daten(r, cAlt))) = werte(3 + AlterKlasse(daten(r, cAlt))) + 1
            If Not alt Is Nothing Then
                If Not alt.Exists(key) Then werte(1) = werte(1) + 1
            End If
            agg(aggKey) = werte
            If Not neu.Exists(key) Then neu.Add key, Array(sparte, vss, pk, gevo)
        End If
    Next r
    If agg.Count = 0 Then
        Protokoll st, zeilen, 0, 0, 0, "keine Datensätze mit Verwaltungssystemschlüssel"
        Exit Sub
    End If

    ' Abgaenge: Schluessel des Vortags, die heute fehlen – zugeordnet nach den Vortagsmerkmalen
    If Not alt Is Nothing Then
        For Each k In alt.Keys
            If Not neu.Exists(k) Then
                werte = alt(k)
                aggKey = werte(0) & TRENNER & werte(1) & TRENNER & werte(2) & TRENNER & werte(3)
                If Not agg.Exists(aggKey) Then agg.Add aggKey, Array(0, 0, 0, 0, 0, 0, 0)
                werte = agg(aggKey)
                werte(2) = werte(2) + 1
                agg(aggKey) = werte
            End If
        Next k
    End If

    ' Fakten schreiben (ein Block), Formelspalte P aus Zeile 2 fortschreiben
    Dim wsF As Worksheet, start As Long, aus() As Variant, i As Long, teile() As String, neuePostkoerbe As Object
    Set wsF = ThisWorkbook.Worksheets("Fakten")
    Set neuePostkoerbe = CreateObject("Scripting.Dictionary")
    start = wsF.Cells(wsF.Rows.Count, 1).End(xlUp).Row + 1
    If start + agg.Count - 1 > FAKTEN_MAX Then Err.Raise vbObjectError + 2, , "Das Blatt Fakten ist voll (mehr als " & FAKTEN_MAX & " Zeilen). Bitte Fakten, Verlauf, Ladeprotokoll und Snapshots leeren und die Abzüge neu laden."
    ReDim aus(1 To agg.Count, 1 To 15)
    i = 0
    For Each k In agg.Keys
        i = i + 1
        teile = Split(k, TRENNER)
        werte = agg(k)
        GevoTyp teile(3), typ, nr
        aus(i, 1) = st.Stichtag: aus(i, 2) = st.Quelle: aus(i, 3) = teile(0): aus(i, 4) = teile(1)
        aus(i, 5) = teile(2): aus(i, 6) = teile(3): aus(i, 7) = typ: aus(i, 8) = nr
        aus(i, 9) = werte(0): aus(i, 10) = werte(1): aus(i, 11) = werte(2)
        aus(i, 12) = werte(3): aus(i, 13) = werte(4): aus(i, 14) = werte(5): aus(i, 15) = werte(6)
        rueckstand = rueckstand + werte(0): eingang = eingang + werte(1): abgang = abgang + werte(2)
        If Not neuePostkoerbe.Exists(teile(2)) Then neuePostkoerbe.Add teile(2), True
    Next k
    LogSchreiben "  gezaehlt: " & agg.Count & " Faktenzeilen, " & zeilen & " Saetze, Rueckstand " & rueckstand & ", Ein " & eingang & ", Abg " & abgang & "; schreibe ab Fakten-Zeile " & start
    ' Protokoll zuerst: ein Abbruch danach hinterlaesst keinen unprotokollierten Halbstand
    If alt Is Nothing Then
        Protokoll st, zeilen, rueckstand, 0, 0, "erster Stand dieser Quelle – Eingänge und Abgänge ab dem nächsten Stichtag"
    Else
        Protokoll st, zeilen, rueckstand, eingang, abgang, ""
    End If
    wsF.Range(wsF.Cells(start, 1), wsF.Cells(start + agg.Count - 1, 15)).Value = aus
    wsF.Range(wsF.Cells(start, 1), wsF.Cells(start + agg.Count - 1, 1)).NumberFormat = "dd.mm.yyyy"
    LogSchreiben "  Fakten geschrieben, Formelspalte"
    wsF.Range(wsF.Cells(start, FAKTEN_SPALTEN), wsF.Cells(start + agg.Count - 1, FAKTEN_SPALTEN)).FormulaR1C1 = wsF.Cells(2, FAKTEN_SPALTEN).FormulaR1C1   ' relative Bezuege je Zeile
    LogSchreiben "  Postkoerbe"
    PostkoerbeRegistrieren neuePostkoerbe
    LogSchreiben "  Snapshot"
    SnapshotSchreiben st.Quelle, st.Stichtag, neu
    LogSchreiben "  Verlauf"
    VerlaufErgaenzen st.Stichtag, start - 1, start + agg.Count - 2
    Exit Sub

Fehler:
    Dim fehlerNr As Long, fehlerText As String
    fehlerNr = Err.Number: fehlerText = Err.Description
    On Error Resume Next
    If Not wbQ Is Nothing Then wbQ.Close SaveChanges:=False
    On Error GoTo 0
    Err.Raise fehlerNr, "StandVerarbeiten", fehlerText & " (" & st.Datei & " / " & st.Blatt & ")"
End Sub

' ---------------------------------------------------------------- Hilfsfunktionen Verarbeitung
Private Function Nz(v As Variant) As Variant
    If IsError(v) Or IsEmpty(v) Or IsNull(v) Then Nz = "" Else Nz = v
End Function

Private Function Sauber(v As Variant) As String
    ' Text ohne Rand und ohne das Trennzeichen der Schluessel
    Sauber = Replace(Trim$(CStr(Nz(v))), TRENNER, "/")
End Function

Public Function Verdichten(t As String) As String
    Dim s As String
    s = Trim$(Replace(Replace(Replace(t, vbTab, " "), vbLf, " "), TRENNER, "/"))
    Do While InStr(s, "  ") > 0: s = Replace(s, "  ", " "): Loop
    Verdichten = s
End Function

Public Function PostkorbNorm(t As String) As String
    Dim s As String
    s = Verdichten(t)
    If Len(s) = 0 Then s = "(ohne Postkorb)"
    PostkorbNorm = s
End Function

Public Sub GevoTyp(gevo As String, ByRef typ As String, ByRef nr As Long)
    ' "SV 108 Bestandsübertragung" -> "108 Bestandsübertragung", 108 ; ". Ohne Zuordnung" -> "Ohne Zuordnung", 0
    Dim s As String, p As Long, erstes As String, zahl As String, i As Long
    s = Verdichten(gevo)
    nr = 0
    zahl = ""
    If Len(s) = 0 Then typ = "(ohne GeVo)": Exit Sub
    p = InStr(s, " ")
    If p = 3 Then
        erstes = Left$(s, 2)
        If erstes Like "[A-Z][A-Z]" Then s = Mid$(s, 4)
    End If
    Do While Len(s) > 0 And (Left$(s, 1) = "." Or Left$(s, 1) = " ")
        s = Mid$(s, 2)
    Loop
    typ = s
    For i = 1 To Len(s)
        If Mid$(s, i, 1) Like "#" Then zahl = zahl & Mid$(s, i, 1) Else Exit For
    Next i
    If Len(zahl) > 0 Then nr = CLng(zahl)
End Sub

Private Function AlterKlasse(v As Variant) As Long
    Dim t As Double
    If IsNumeric(v) Then t = CDbl(v) Else t = 0
    If t <= 7 Then
        AlterKlasse = 0
    ElseIf t <= 30 Then
        AlterKlasse = 1
    ElseIf t <= 90 Then
        AlterKlasse = 2
    Else
        AlterKlasse = 3
    End If
End Function

Private Function SpartenZuordnung() As Object
    Dim d As Object, ws As Worksheet, r As Long, daten As Variant
    Set d = CreateObject("Scripting.Dictionary")
    Set ws = ThisWorkbook.Worksheets("Konfiguration")
    daten = ws.Range("A11:B40").Value2
    For r = 1 To UBound(daten, 1)
        If Len(Trim$(CStr(Nz(daten(r, 1))))) > 0 Then
            If Not d.Exists(Trim$(CStr(daten(r, 1)))) Then d.Add Trim$(CStr(daten(r, 1))), Trim$(CStr(Nz(daten(r, 2))))
        End If
    Next r
    Set SpartenZuordnung = d
End Function

' ---------------------------------------------------------------- Ordner
Private Function RohdatenOrdner() As String
    RohdatenOrdner = OrdnerAufloesen(CStr(ThisWorkbook.Worksheets("Konfiguration").Range("B3").Value), "Rohdaten")
End Function

Private Function OrdnerAufloesen(eintrag As String, standard As String) As String
    ' Relativer Eintrag (Konfiguration) -> Ordner neben der Master-Datei; absoluter Pfad bleibt. Ergebnis endet mit Trenner.
    Dim p As String
    p = Trim$(eintrag)
    If Len(p) = 0 Then p = standard
    If InStr(p, ":") = 0 And Left$(p, 2) <> "\\" Then p = BasisOrdner() & Application.PathSeparator & p
    If Right$(p, 1) <> Application.PathSeparator Then p = p & Application.PathSeparator
    OrdnerAufloesen = p
End Function

Public Function BasisOrdner() As String
    ' Lokaler Ordner der Master-Datei. Liegt die Datei in OneDrive/SharePoint, liefert ThisWorkbook.Path eine
    ' https-Adresse, mit der Dir() nicht arbeiten kann (Laufzeitfehler 52). Dann: Konfiguration!B7 (wenn gueltig),
    ' sonst die Adresse auf den synchronisierten Ordner abbilden (OneDrive-Umgebungsvariablen), sonst nachfragen.
    Dim p As String, k As String, wurzeln As Variant, teile() As String, i As Long, j As Long, m As Long, kand As String
    k = Trim$(CStr(ThisWorkbook.Worksheets("Konfiguration").Range("B7").Value))
    If Len(k) > 0 Then
        If Right$(k, 1) = Application.PathSeparator Then k = Left$(k, Len(k) - 1)
        If DateiVorhanden(k & Application.PathSeparator & ThisWorkbook.Name) Then
            BasisOrdner = k
            Exit Function
        End If
    End If
    p = ThisWorkbook.Path
    If LCase$(Left$(p, 4)) <> "http" Then
        BasisOrdner = p
        Exit Function
    End If
    p = UrlDekodieren(p)
    teile = Split(Replace(p, "\", "/"), "/")
    wurzeln = Array(Environ$("OneDriveCommercial"), Environ$("OneDriveConsumer"), Environ$("OneDrive"))
    For i = 0 To UBound(wurzeln)
        If Len(wurzeln(i)) > 0 Then
            For j = 3 To UBound(teile)
                kand = wurzeln(i)
                For m = j To UBound(teile)
                    kand = kand & Application.PathSeparator & teile(m)
                Next m
                If DateiVorhanden(kand & Application.PathSeparator & ThisWorkbook.Name) Then
                    BasisOrdner = kand
                    Exit Function
                End If
            Next j
        End If
    Next i
    With Application.FileDialog(4)          ' msoFileDialogFolderPicker
        .Title = "Ordner der Master-Datei wählen (OneDrive/SharePoint-Adresse konnte nicht zugeordnet werden)"
        .AllowMultiSelect = False
        If .Show = -1 Then
            BasisOrdner = .SelectedItems(1)
            ThisWorkbook.Worksheets("Konfiguration").Range("B7").Value = BasisOrdner
        Else
            Err.Raise vbObjectError + 5, , "Der lokale Ordner der Master-Datei ist nicht bekannt. Bitte in Konfiguration!B7 eintragen."
        End If
    End With
End Function

Private Function UrlDekodieren(u As String) As String
    ' %XX-Folgen (UTF-8) in Text zurueckwandeln, z. B. %C3%BC -> ü
    Dim i As Long, bytes() As Byte, n As Long, s As String, stream As Object
    On Error GoTo Roh
    ReDim bytes(0 To Len(u) * 3)
    n = 0
    i = 1
    Do While i <= Len(u)
        If Mid$(u, i, 1) = "%" And i + 2 <= Len(u) Then
            bytes(n) = CByte("&H" & Mid$(u, i + 1, 2))
            n = n + 1
            i = i + 3
        Else
            s = Mid$(u, i, 1)
            If AscW(s) < 128 Then
                bytes(n) = AscW(s): n = n + 1
            Else
                ' Zeichen ausserhalb ASCII unveraendert als UTF-8 uebernehmen
                Dim t As Object
                Set t = CreateObject("ADODB.Stream")
                t.Type = 2: t.Charset = "utf-8": t.Open: t.WriteText s: t.Position = 0: t.Type = 1
                Dim b() As Byte, q As Long
                b = t.Read
                t.Close
                For q = 3 To UBound(b)          ' ohne BOM
                    bytes(n) = b(q): n = n + 1
                Next q
            End If
            i = i + 1
        End If
    Loop
    If n = 0 Then UrlDekodieren = "": Exit Function
    ReDim Preserve bytes(0 To n - 1)
    Set stream = CreateObject("ADODB.Stream")
    stream.Type = 1: stream.Open: stream.Write bytes: stream.Position = 0
    stream.Type = 2: stream.Charset = "utf-8"
    UrlDekodieren = stream.ReadText
    stream.Close
    Exit Function
Roh:
    UrlDekodieren = Replace(u, "%20", " ")
End Function

Private Function OrdnerVorhanden(pfad As String) As Boolean
    On Error Resume Next
    OrdnerVorhanden = (Len(Dir(pfad, vbDirectory)) > 0)
    On Error GoTo 0
End Function

Private Function DateiVorhanden(pfad As String) As Boolean
    On Error Resume Next
    DateiVorhanden = (Len(Dir(pfad)) > 0)
    On Error GoTo 0
End Function

' ---------------------------------------------------------------- Snapshot (Schluessel des letzten Stands je Quelle)
Private Function SnapshotBlatt(quelle As String) As Worksheet
    Set SnapshotBlatt = ThisWorkbook.Worksheets("Snapshot_" & quelle)
End Function

Private Function SnapshotLesen(quelle As String) As Object
    Dim ws As Worksheet, letzte As Long, daten As Variant, r As Long, d As Object
    Set ws = SnapshotBlatt(quelle)
    letzte = ws.Cells(ws.Rows.Count, 1).End(xlUp).Row
    If letzte < 2 Then Set SnapshotLesen = Nothing: Exit Function
    Set d = CreateObject("Scripting.Dictionary")
    daten = ws.Range(ws.Cells(2, 1), ws.Cells(letzte, 5)).Value2
    For r = 1 To UBound(daten, 1)
        If Not d.Exists(CStr(daten(r, 1))) Then d.Add CStr(daten(r, 1)), Array(CStr(daten(r, 2)), CStr(daten(r, 3)), CStr(daten(r, 4)), CStr(daten(r, 5)))
    Next r
    Set SnapshotLesen = d
End Function

Private Sub SnapshotSchreiben(quelle As String, stichtag As Date, neu As Object)
    Dim ws As Worksheet, aus() As Variant, k As Variant, i As Long, w As Variant
    Set ws = SnapshotBlatt(quelle)
    ws.Range(ws.Cells(2, 1), ws.Cells(ws.Rows.Count, 5)).ClearContents
    ws.Range("H2").Value = stichtag
    ws.Range("H2").NumberFormat = "dd.mm.yyyy"
    ws.Range("H3").Value = neu.Count
    If neu.Count = 0 Then Exit Sub
    ReDim aus(1 To neu.Count, 1 To 5)
    For Each k In neu.Keys
        i = i + 1
        w = neu(k)
        aus(i, 1) = CStr(k): aus(i, 2) = w(0): aus(i, 3) = w(1): aus(i, 4) = w(2): aus(i, 5) = w(3)
    Next k
    ws.Range(ws.Cells(2, 1), ws.Cells(neu.Count + 1, 5)).Value = aus
End Sub

Private Function LetzterStand(quelle As String) As Date
    Dim v As Variant
    v = SnapshotBlatt(quelle).Range("H2").Value
    If IsDate(v) Then LetzterStand = CDate(v) Else LetzterStand = 0
End Function

' ---------------------------------------------------------------- Verlauf, Filterliste, Protokoll
Private Sub VerlaufErgaenzen(stichtag As Date, pos1 As Long, pos2 As Long)
    ' Zeile je Stichtag anlegen (Formeln der Vorzeile kopieren) und die Blockgrenzen der Fakten-Zeilen dieses Stichtags
    ' in AL/AM als Werte fuehren (Position im Bereich Fakten!X2:X300000): erste = kleinste, letzte = groesste Position
    Dim ws As Worksheet, letzte As Long, r As Long, zeile As Long
    Set ws = ThisWorkbook.Worksheets("Verlauf")
    letzte = ws.Cells(ws.Rows.Count, 1).End(xlUp).Row
    zeile = 0
    For r = 6 To letzte
        If ws.Cells(r, 1).Value = stichtag Then zeile = r: Exit For
    Next r
    If zeile = 0 Then
        If letzte < 6 Then letzte = 6
        If IsEmpty(ws.Cells(6, 1).Value) Then
            zeile = 6
        Else
            If letzte + 1 > VERLAUF_MAX Then Err.Raise vbObjectError + 3, , "Das Blatt Verlauf ist voll (mehr als " & VERLAUF_MAX & " Stichtage)."
            ws.Rows(letzte).Copy ws.Rows(letzte + 1)
            Application.CutCopyMode = False
            zeile = letzte + 1
        End If
        ws.Cells(zeile, 1).Value = stichtag
        ws.Cells(zeile, 38).Value = pos1
        ws.Cells(zeile, 39).Value = pos2
    Else
        If Val(ws.Cells(zeile, 38).Value) = 0 Or pos1 < Val(ws.Cells(zeile, 38).Value) Then ws.Cells(zeile, 38).Value = pos1
        If pos2 > Val(ws.Cells(zeile, 39).Value) Then ws.Cells(zeile, 39).Value = pos2
    End If
End Sub

Private Sub PostkoerbeRegistrieren(neue As Object)
    ' Unbekannte Themenpostkoerbe kommen mit Kennzeichen WAHR in die Filterliste (Filter!B, ohne Chip)
    Dim ws As Worksheet, r As Long, k As Variant, vorhanden As Object, frei As Long, liste As Variant
    Set ws = ThisWorkbook.Worksheets("Filter")
    Set vorhanden = CreateObject("Scripting.Dictionary")
    liste = ws.Range(ws.Cells(PK_VON, 2), ws.Cells(PK_BIS, 2)).Value2
    frei = 0
    For r = 1 To UBound(liste, 1)
        If Len(Trim$(CStr(Nz(liste(r, 1))))) > 0 Then
            If Not vorhanden.Exists(CStr(liste(r, 1))) Then vorhanden.Add CStr(liste(r, 1)), True
        ElseIf frei = 0 Then
            frei = PK_VON + r - 1
        End If
    Next r
    For Each k In neue.Keys
        If Not vorhanden.Exists(CStr(k)) Then
            If frei = 0 Or frei > PK_BIS Then Err.Raise vbObjectError + 4, , "Die Filterliste der Themenpostkörbe ist voll (Filter!B" & PK_VON & ":B" & PK_BIS & "); Postkorb '" & k & "' kann nicht aufgenommen werden."
            ws.Cells(frei, 2).Value = CStr(k)
            ws.Cells(frei, 3).Value = True
            vorhanden.Add CStr(k), True
            frei = frei + 1
        End If
    Next k
End Sub

Private Function ProtokollLesen() As Object
    ' Alle protokollierten Staende (Quelle|Stichtag) – geladene und uebersprungene – als Dictionary
    Dim ws As Worksheet, letzte As Long, daten As Variant, r As Long, d As Object, hinweis As String
    Set d = CreateObject("Scripting.Dictionary")
    Set ws = ThisWorkbook.Worksheets("Ladeprotokoll")
    letzte = ws.Cells(ws.Rows.Count, 1).End(xlUp).Row
    If letzte >= 5 Then
        daten = ws.Range(ws.Cells(5, 1), ws.Cells(letzte, 10)).Value2
        For r = 1 To UBound(daten, 1)
            If IsNumeric(daten(r, 5)) And Len(CStr(Nz(daten(r, 4)))) > 0 Then
                hinweis = CStr(Nz(daten(r, 10)))
                If Len(hinweis) = 0 Or Left$(hinweis, 6) = "erster" Or Left$(hinweis, 12) = "übersprungen" Then
                    If Not d.Exists(CStr(daten(r, 4)) & TRENNER & CLng(daten(r, 5))) Then d.Add CStr(daten(r, 4)) & TRENNER & CLng(daten(r, 5)), True
                End If
            End If
        Next r
    End If
    Set ProtokollLesen = d
End Function

Private Sub Protokoll(st As Stand, zeilen As Long, rueckstand As Long, eingang As Long, abgang As Long, hinweis As String)
    Dim ws As Worksheet, r As Long
    Set ws = ThisWorkbook.Worksheets("Ladeprotokoll")
    r = ws.Cells(ws.Rows.Count, 1).End(xlUp).Row + 1
    If r < 5 Then r = 5
    ws.Range(ws.Cells(r, 1), ws.Cells(r, 10)).Value = Array(Now, st.Datei, st.Blatt, st.Quelle, st.Stichtag, zeilen, rueckstand, eingang, abgang, hinweis)
    ws.Cells(r, 1).NumberFormat = "dd.mm.yyyy hh:mm"
    ws.Cells(r, 5).NumberFormat = "dd.mm.yyyy"
End Sub

' ============================================================================
' Anwesenheitsliste (MAK je Mitarbeiter und Kalenderwoche) importieren
' Erwartet im Ordner "Anwesenheit" (Konfiguration!B4) die neueste Excel-Datei mit einer Kopfzeile "Mitarbeiter",
' den Spalten "Makler BÜ Gesundheit" / "Makler BÜ Komposit" (Sparte) und Wochenspalten "NN KW" / "NN. KW".
' Ergebnis: Stammdaten im Blatt "Mitarbeiter" (Kapazitaet = groesster Wochenwert), Abweichungen im Blatt "Planung"
' (Urlaub = "U", sonstiger Text = "F", abweichende Zahl = Zahl, Kapazitaet oder leer = Zelle leer).
' Faellt die KW-Nummer gegenueber der Vorspalte, beginnt ein neues Jahr (Liste ueber den Jahreswechsel).
' ============================================================================
Public Sub AnwesenheitLaden(Optional stumm As Boolean = False)
    importMeldung = ""
    Dim ordner As String, datei As String, neueste As String, neuesteZeit As Date, pfad As String
    Dim wbQ As Workbook, ws As Worksheet, daten As Variant
    Dim r As Long, c As Long, kopf As Long, cMa As Long, cEinheit As Long, cGes As Long, cKom As Long
    Dim kwSpalten() As Long, kwNummern() As Long, kwJahre() As Long, nKw As Long, t As String, jahr As Long
    Dim wsM As Worksheet, wsP As Worksheet, wsW As Worksheet, ma As String, sparte As String, w As Variant
    Dim zeile As Long, kap As Double, spalte As Variant, anzahl As Long
    Dim kwSpalteZiel() As Long, cMin As Long, cMax As Long, zeilenWerte As Variant, zi As Long
    Dim eigenerLademodus As Boolean

    If lademodusAktiv Then Exit Sub
    On Error Resume Next
    ordner = OrdnerAufloesen(CStr(ThisWorkbook.Worksheets("Konfiguration").Range("B4").Value), "Anwesenheit")
    If Err.Number <> 0 Then
        modFortschritt.HinweisZeigen "Fehler", Err.Description, True
        Exit Sub
    End If
    On Error GoTo 0
    jahr = CLng(Val(ThisWorkbook.Worksheets("Konfiguration").Range("B5").Value))
    If jahr = 0 Then jahr = Year(Date)

    If Not OrdnerVorhanden(ordner) Then
        importMeldung = "Anwesenheit nicht importiert: Ordner nicht gefunden (" & ordner & ")"
        If Not stumm Then modFortschritt.HinweisZeigen "Fehler", "Der Ordner für die Anwesenheitsliste wurde nicht gefunden:" & vbCrLf & ordner, True
        Exit Sub
    End If
    datei = Dir(ordner & "*.xls*")
    Do While Len(datei) > 0
        If Left$(datei, 2) <> "~$" And IstExcelDatei(datei) Then
            If FileDateTime(ordner & datei) > neuesteZeit Then
                neuesteZeit = FileDateTime(ordner & datei)
                neueste = datei
            End If
        End If
        datei = Dir()
    Loop
    If Len(neueste) = 0 Then
        importMeldung = "Anwesenheit nicht importiert: keine Excel-Datei in " & ordner
        If Not stumm Then modFortschritt.HinweisZeigen "Hinweis", "Im Ordner " & ordner & " liegt keine Excel-Datei.", False
        Exit Sub
    End If
    pfad = ordner & neueste

    On Error GoTo Fehler
    LogSchreiben "---- AnwesenheitLaden " & neueste
    LadeModusEin "Anwesenheitsliste wird importiert"
    eigenerLademodus = True
    modFortschritt.FortschrittSetzen 0.1, "Lese " & neueste
    Set wbQ = QuelleOeffnen(pfad)
    Set ws = wbQ.Worksheets(1)
    daten = ws.UsedRange.Value2
    wbQ.Close SaveChanges:=False
    Set wbQ = Nothing
    If Not IsArray(daten) Then Err.Raise vbObjectError + 2, , "Die Datei enthält keine Tabelle."
    modFortschritt.FortschrittSetzen 0.3, "Kopfzeile und Wochenspalten erkennen"

    For r = 1 To UBound(daten, 1)
        For c = 1 To UBound(daten, 2)
            If InStr(1, CStr(Nz(daten(r, c))), "Mitarbeiter", vbTextCompare) > 0 Then kopf = r: cMa = c
        Next c
        If kopf > 0 Then Exit For
    Next r
    If kopf = 0 Then Err.Raise vbObjectError + 2, , "Keine Kopfzeile mit 'Mitarbeiter' gefunden."
    nKw = 0
    For c = 1 To UBound(daten, 2)
        t = Replace(Replace(CStr(Nz(daten(kopf, c))), vbLf, " "), ".", "")
        t = Trim$(t)
        If InStr(1, t, "Gesundheit", vbTextCompare) > 0 Then cGes = c
        If InStr(1, t, "Komposit", vbTextCompare) > 0 Then cKom = c
        If InStr(1, t, "Einheit", vbTextCompare) > 0 Then cEinheit = c
        If Len(t) > 2 Then                                   ' And wertet nicht verkuerzt aus: Left$(t, -2) waere Fehler 5
            If UCase$(Right$(t, 2)) = "KW" Then
                If IsNumeric(Trim$(Left$(t, Len(t) - 2))) Then
                    ReDim Preserve kwSpalten(0 To nKw): ReDim Preserve kwNummern(0 To nKw): ReDim Preserve kwJahre(0 To nKw)
                    kwSpalten(nKw) = c: kwNummern(nKw) = CLng(Trim$(Left$(t, Len(t) - 2)))
                    If nKw > 0 Then
                        If kwNummern(nKw) < kwNummern(nKw - 1) Then jahr = jahr + 1     ' Jahreswechsel in der Liste
                    End If
                    kwJahre(nKw) = jahr
                    nKw = nKw + 1
                End If
            End If
        End If
    Next c
    If nKw = 0 Then Err.Raise vbObjectError + 3, , "Keine Wochenspalten ('NN KW') gefunden."
    If UBound(daten, 1) <= kopf Then Err.Raise vbObjectError + 4, , "Keine Mitarbeiterzeilen unter der Kopfzeile."

    Set wsM = ThisWorkbook.Worksheets("Mitarbeiter")
    Set wsP = ThisWorkbook.Worksheets("Planung")
    Set wsW = ThisWorkbook.Worksheets("Wirksam")
    ' Zielspalte je KW einmal bestimmen (statt Match je Mitarbeiter und Woche)
    ReDim kwSpalteZiel(0 To nKw - 1)
    cMin = 0: cMax = 0
    For c = 0 To nKw - 1
        spalte = Application.Match(kwJahre(c) * 100 + kwNummern(c), wsW.Rows(6), 0)
        If IsError(spalte) Then
            kwSpalteZiel(c) = 0
        Else
            kwSpalteZiel(c) = CLng(spalte)
            If cMin = 0 Or kwSpalteZiel(c) < cMin Then cMin = kwSpalteZiel(c)
            If kwSpalteZiel(c) > cMax Then cMax = kwSpalteZiel(c)
        End If
    Next c
    If cMin = 0 Then Err.Raise vbObjectError + 5, , "Keine der Wochenspalten passt zum Jahr " & kwJahre(0) & " (Konfiguration!B5) im Planungshorizont."

    For r = kopf + 1 To UBound(daten, 1)
        ma = Trim$(CStr(Nz(daten(r, cMa))))
        modFortschritt.FortschrittSetzen 0.3 + 0.6 * (r - kopf) / (UBound(daten, 1) - kopf), "Übernehme " & ma
        If Len(ma) > 0 And UCase$(ma) <> "MAK" Then
            sparte = "Komposit"
            If cGes > 0 Then
                ' IsNumeric(Empty) ist True, CDbl("") aber Fehler 13 – deshalb Leerzelle zuerst ausschliessen
                If Not IsEmpty(daten(r, cGes)) Then
                    If IsNumeric(daten(r, cGes)) Then
                        If CDbl(daten(r, cGes)) > 0 Then sparte = "Gesundheit"
                    End If
                End If
            End If
            kap = 0
            For c = 0 To nKw - 1
                w = daten(r, kwSpalten(c))
                If IsNumeric(w) And Not IsEmpty(w) Then
                    If CDbl(w) > kap Then kap = CDbl(w)
                End If
            Next c
            zeile = MitarbeiterZeile(wsM, ma)
            If zeile = 0 Then Err.Raise vbObjectError + 6, , "Kein Platz mehr im Blatt Mitarbeiter (maximal " & MA_ZEILEN & " Zeilen)."
            wsM.Cells(zeile, 1).Value = ma
            If cEinheit > 0 Then wsM.Cells(zeile, 2).Value = Trim$(CStr(Nz(daten(r, cEinheit))))
            wsM.Cells(zeile, 3).Value = sparte
            wsM.Cells(zeile, 4).Value = kap
            If IsEmpty(wsM.Cells(zeile, 7).Value) Then wsM.Cells(zeile, 7).Value = True
            anzahl = anzahl + 1
            ' Planungszeile als ein Block: vorhandene Werte lesen, Abweichungen eintragen, einmal schreiben
            zeilenWerte = wsP.Range(wsP.Cells(zeile + PL_VERSATZ, cMin), wsP.Cells(zeile + PL_VERSATZ, cMax + 1)).Value2   ' +1: immer 2D
            For c = 0 To nKw - 1
                If kwSpalteZiel(c) > 0 Then
                    zi = kwSpalteZiel(c) - cMin + 1
                    w = daten(r, kwSpalten(c))
                    If IsEmpty(w) Or Len(Trim$(CStr(Nz(w)))) = 0 Then
                        zeilenWerte(1, zi) = Empty
                    ElseIf IsNumeric(w) Then
                        If Abs(CDbl(w) - kap) < 0.0001 Then zeilenWerte(1, zi) = Empty Else zeilenWerte(1, zi) = CDbl(w)
                    ElseIf InStr(1, CStr(w), "urlaub", vbTextCompare) > 0 Then
                        zeilenWerte(1, zi) = "U"
                    Else
                        zeilenWerte(1, zi) = "F"
                    End If
                End If
            Next c
            wsP.Range(wsP.Cells(zeile + PL_VERSATZ, cMin), wsP.Cells(zeile + PL_VERSATZ, cMax + 1)).Value2 = zeilenWerte
        End If
    Next r
    wsM.Range("K5").Value = neueste
    wsM.Range("K6").Value = Now
    wsM.Range("K6").NumberFormat = "dd.mm.yyyy hh:mm"
    modFortschritt.FortschrittSetzen 0.95, "MAK und Produktivität werden neu berechnet"
    LogSchreiben "  " & anzahl & " Mitarbeitende, Neuberechnung"
    Application.Calculation = xlCalculationAutomatic
    Application.Calculate
    LogSchreiben "  Diagramme anpassen"
    modCockpit.DiagrammeAnpassen True
    LogSchreiben "  Fertig"
    modFortschritt.FortschrittSetzen 1, "Fertig"
    LadeModusAus
    importMeldung = "MAK-Liste importiert: " & neueste & ", " & anzahl & " Mitarbeitende, KW " & kwNummern(0) & "/" & kwJahre(0) & " bis KW " & kwNummern(nKw - 1) & "/" & kwJahre(nKw - 1)
    If Not stumm Then modFortschritt.HinweisZeigen "Hinweis", importMeldung & "." & vbCrLf & vbCrLf & "Abwesenheiten und neue Mitarbeitende pflegst du ab jetzt direkt in den Blättern 'Planung' und 'Mitarbeiter'.", False
    Exit Sub

Fehler:
    Dim fehlertext As String
    fehlertext = "Fehler " & Err.Number & ": " & Err.Description
    On Error Resume Next
    If Not wbQ Is Nothing Then wbQ.Close SaveChanges:=False
    If eigenerLademodus Then LadeModusAus
    modFortschritt.HinweisZeigen "Fehler", "Fehler beim Import der Anwesenheitsliste: " & fehlertext, True
End Sub

Private Function MitarbeiterZeile(wsM As Worksheet, ma As String) As Long
    ' Zeile des Mitarbeiters im Blatt Mitarbeiter (Name in Spalte A ab Zeile MA_START), sonst erste freie Zeile; 0 = kein Platz
    Dim r As Long
    For r = MA_START To MA_START + MA_ZEILEN - 1
        If StrComp(Trim$(CStr(wsM.Cells(r, 1).Value)), ma, vbTextCompare) = 0 Then MitarbeiterZeile = r: Exit Function
    Next r
    For r = MA_START To MA_START + MA_ZEILEN - 1
        If Len(Trim$(CStr(wsM.Cells(r, 1).Value))) = 0 Then MitarbeiterZeile = r: Exit Function
    Next r
    MitarbeiterZeile = 0
End Function
