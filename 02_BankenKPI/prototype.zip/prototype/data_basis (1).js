/* ============================================================
   NÜRNBERGER KPI-Board — Datenbasis je Kennzahl
   ------------------------------------------------------------
   Alle Werte sind Beispielwerte und werden durch Werte aus den
   Quellsystemen ersetzt.

   Je Kennzahl:
   - series:          gemessene Ist-Werte je Quartal ab 2025-Q1
                      (null = Periode ohne Messung)
   - documentedPath:  hinterlegte Planwerte einzelner Quartale; nur
                      beim Konzernergebnis (saisonale Phasierung)
   - splits:          Aufteilung nach Gesellschaft, Kanal, Segment …
   - dataQuality:     Vollständigkeit, Stand, Quellsystem, Pflege

   Der Plan wird nicht hier gepflegt, sondern aus den Eckwerten in
   data.js gerechnet (path_derive.js).
   ============================================================ */

/* ---------- Zeitraster: Quartalswerte 2025-Q1 bis 2027-Q4 ---------- */
const PERIODS = [
  "2025-Q1", "2025-Q2", "2025-Q3", "2025-Q4",
  "2026-Q1", "2026-Q2", "2026-Q3", "2026-Q4",
  "2027-Q1", "2027-Q2", "2027-Q3", "2027-Q4"
];

/* Planungshorizont bis 2031 (länger als das Erfassungsraster). */
const PATH_PERIODS = [
  "2025-Q1", "2025-Q2", "2025-Q3", "2025-Q4",
  "2026-Q1", "2026-Q2", "2026-Q3", "2026-Q4",
  "2027-Q1", "2027-Q2", "2027-Q3", "2027-Q4",
  "2028-Q1", "2028-Q2", "2028-Q3", "2028-Q4",
  "2029-Q1", "2029-Q2", "2029-Q3", "2029-Q4",
  "2030-Q1", "2030-Q2", "2030-Q3", "2030-Q4",
  "2031-Q1", "2031-Q2", "2031-Q3", "2031-Q4"
];

/* Serie aus Ist-Werten ab 2025-Q1; null = keine Messung in dieser
   Periode (z. B. halbjährliche KPIs nur Q2/Q4). */
function makeSeries(values) {
  return values.map((v, i) => ({
    period: PERIODS[i],
    value: v,
    isActual: true
  }));
}

/* ============================================================
   Frage 1 — Gewinnen wir wirtschaftlich?
   ============================================================ */

const KPI_DATA = {

  /* Konzernergebnis HGB (Mio. EUR)
     Einzupflegen: Quartals-Ist, kumuliert (Q4 = Jahresergebnis). */
  konzernergebnis: {
    series: makeSeries(
      [
        8.2, 14.5, 18.1, 46.8, 11.0, 15.5
      ]
    ),
    /* Planannahme zur Verteilung über das Jahr (Q1 niedrig, Q4 =
       Jahresergebnis). Eine gerade Linie zwischen Jahresendwerten
       ergäbe für 2026-Q1 rund 49 statt 12. */
    documentedPath: {
      "2026-Q1": 12.0, "2026-Q2": 16.0, "2026-Q3": 20.0, "2026-Q4": 55.0,
      "2027-Q1": 14.0, "2027-Q2": 18.5, "2027-Q3": 23.0, "2027-Q4": 62.0
    },
    splits: {
      /* Split nach Gesellschaft */
      gesellschaft: [
        { name: "Leben", value2025: 22.4 },
        { name: "Kranken", value2025: 9.1 },
        { name: "Schaden/Unfall", value2025: 12.8 },
        { name: "Sonstige", value2025: 2.5 }
      ]
    },
    dataQuality: { completeness: 100, lastUpdated: "2026-07-15", sourceSystem: "SAP FC / Konzernrechnungswesen", steward: "Controlling" }
  },

  /* Kostenquote (%)
     Einzupflegen: Quartals-Ist. Plan aus 13,5 (2025) → 14,3 (2028)
     → 12,3 (2031). */
  kostenquote: {
    series: makeSeries(
      [
        13.2, 13.4, 13.5, 13.5, 13.6, 13.7
      ]
    ),
    splits: {
      kostenblock: [
        { name: "Personal", value2025: 7.8 },
        { name: "IT", value2025: 2.9 },
        { name: "Sach / Gebäude", value2025: 1.6 },
        { name: "Sonstige", value2025: 1.2 }
      ]
    },
    dataQuality: { completeness: 100, lastUpdated: "2026-07-15", sourceSystem: "Kostenrechnung", steward: "Controlling" }
  },

  /* Solvenzquote (%)
     Einzupflegen: Quartals-Ist aus dem Risikomodell. */
  solvenzquote: {
    series: makeSeries(
      [
        261, 275, 289, 302, 296, 288
      ]
    ),
    /* Kein Plan: Untergrenze ≥ 200 % (computeGuardrailStatus). */
    guardrail: { min: 200, warn: 175 },
    splits: {
      /* Split nach Gesellschaft */
      gesellschaft: [
        { name: "Leben", value2025: 291 },
        { name: "Kranken", value2025: 318 },
        { name: "Schaden/Unfall", value2025: 312 }
      ]
    },
    dataQuality: { completeness: 100, lastUpdated: "2026-07-15", sourceSystem: "Risikomodell (Solvency II)", steward: "Risikomanagement" }
  },

  /* ============================================================
     Frage 2 — Wirken die vier Hebel?
     ============================================================ */

  /* eNPS (Punkte)
     Einzupflegen: Halbjahreswerte (Puls-Check, Q2/Q4).
     Split nach Berichtsebene. */
  enps: {
    series: makeSeries(
      [
        null, -41, null, -39, null, -38
      ]
    ),

    splits: {
      berichtsebene: [
        { name: "Vorstand / Directa", value: -12 },
        { name: "Bereichsleitung", value: -28 },
        { name: "Fachbereich", value: -41 },
        { name: "GA / Außendienst", value: -47 }
      ]
    },
    dataQuality: { completeness: 78, lastUpdated: "2026-07-31", sourceSystem: "Puls-Check-Befragung", steward: "HR / CHRO" }
  },

  /* Kosten je Vertrag (EUR)
     Einzupflegen: Ab 2027 (Methodik bis 2028); bis dahin null.
     Split nach Geschäftsfeld für Vergleichbarkeit. */
  stueckkosten: {
    series: makeSeries(
      []
    ),

    splits: {
      geschaftsfeld: [
        { name: "Leben", value: 142 },
        { name: "Kranken", value: 98 },
        { name: "Schaden/Unfall", value: 104 }
      ]
    },
    dataQuality: { completeness: 0, lastUpdated: null, sourceSystem: "Kostenrechnung + Bestandssysteme (Methodik in Entwicklung)", steward: "Controlling + COO" }
  },

  /* Vertragsdichte je Kunde (Verträge/Kunde)
     Einzupflegen: Quartals-Ist; Split nach Kanal (GA-Ziel 2,1)
     und Segment (Privat/Gewerbe) für Fokus-Analyse. */
  vertragsdichte: {
    series: makeSeries(
      [
        1.68, 1.69, 1.70, 1.70, 1.71, 1.70
      ]
    ),
    splits: {
      kanal: [
        { name: "Generalagenten", value: 1.95, ziel2028: 2.1 },
        { name: "Autohaus", value: 1.62 },
        { name: "Makler / MGA", value: 1.55 }
      ],
      segment: [
        { name: "Privat", value: 1.70 },
        { name: "Gewerbe", value: 2.85 }
      ]
    },
    dataQuality: { completeness: 100, lastUpdated: "2026-07-15", sourceSystem: "Bestandssysteme + CRM", steward: "Bestandsmanagement" }
  },

  /* Ertragsbarwert S/U (Mio. EUR)
     Einzupflegen: Ab 2026-Q4 (Auswertung läuft); Split nach
     Kanal für Vertriebssteuerung. */
  ertragsbarwert: {
    series: makeSeries(
      []
    ),

    splits: {
      kanal: [
        { name: "Generalagenten", value: 148 },
        { name: "Autohaus", value: 76 },
        { name: "Makler / MGA", value: 188 }
      ]
    },
    dataQuality: { completeness: 0, lastUpdated: null, sourceSystem: "Aktuariat / Controlling (Modell)", steward: "Aktuariat" }
  },

  /* ============================================================
     Frage 3 — Tun wir die richtigen Dinge?
     ============================================================ */

  /* NÜRNBERGER Präventions-Score (Index 0-100)
     Einzupflegen: Ab 2027 (Methodik bis 2028). Komponenten
     einzeln erfassen (Krankentage, Weiterbildung, CAR). */
  praeventions_score: {
    series: makeSeries(
      []
    ),

    splits: {
      komponente: [
        { name: "Krankentage je MA (invertiert)", value: 38 },
        { name: "Weiterbildungstage je MA", value: 45 },
        { name: "Change Adoption Rate", value: 44 }
      ]
    },
    dataQuality: { completeness: 0, lastUpdated: null, sourceSystem: "HR-Systeme + Puls-Check (Index in Entwicklung)", steward: "HR / CHRO" }
  },

  /* Change Adoption Rate (%)
     Einzupflegen: Quartals-Ist aus Tool-Nutzung + Befragung. */
  change_adoption: {
    series: makeSeries(
      [
        null, 12, null, 15, null, 18
      ]
    ),

    splits: {
      tool: [
        { name: "KI-Assistent", value: 28 },
        { name: "Neue Bestandssysteme", value: 19 },
        { name: "Prozess-Plattform", value: 24 }
      ]
    },
    dataQuality: { completeness: 85, lastUpdated: "2026-07-31", sourceSystem: "Tool-Nutzungsdaten + Befragung", steward: "HR / CDO" }
  },

  /* NÜRNBERGER Leadership-Score (Punkte)
     Einzupflegen: Halbjahreswerte aus Befragung. */
  leadership_score: {
    series: makeSeries(
      [
        null, 79, null, 79, null, 80
      ]
    ),

    splits: {
      dimension: [
        { name: "Steuerung", value: 81 },
        { name: "Zielkultur: Mut", value: 78 },
        { name: "Zielkultur: Outcome-Orientierung", value: 76 },
        { name: "Zielkultur: Vertrauen", value: 80 },
        { name: "Zielkultur: Klarheit", value: 82 }
      ]
    },
    dataQuality: { completeness: 92, lastUpdated: "2026-07-31", sourceSystem: "Leadership-Befragung", steward: "HR / CHRO" }
  },

  /* Frauenquote in Führungspositionen (%)
     Einzupflegen: Halbjahreswerte aus HR-System. */
  frauenquote: {
    series: makeSeries(
      [
        null, 26, null, 26, null, 29
      ]
    ),

    splits: {
      berichtsebene: [
        { name: "BE 1 (Vorstand/Directa)", value: 33 },
        { name: "BE 2 (Bereichsleitung)", value: 24 },
        { name: "BE 3 (Fachbereich)", value: 28 }
      ]
    },
    dataQuality: { completeness: 100, lastUpdated: "2026-07-31", sourceSystem: "HR-System (SAP HCM)", steward: "HR" }
  },

  /* Automatisierungsgrad (%)
     Einzupflegen: Ab 2027 (aus Planung 2026); Split nach
     Prozess für Engpass-Analyse. */
  automatisierungsgrad: {
    series: makeSeries(
      []
    ),

    splits: {
      prozess: [
        { name: "Antragsbearbeitung", value: 41 },
        { name: "Schadenregulierung", value: 28 },
        { name: "Bestandsänderung", value: 36 },
        { name: "Kundenservice", value: 31 }
      ]
    },
    dataQuality: { completeness: 0, lastUpdated: null, sourceSystem: "Workflow-Systeme (Auswertung ausstehend)", steward: "COO / IT" }
  },

  /* Dunkelverarbeitungsquote (%)
     Einzupflegen: Ab 2027; gleiche Prozess-Splits. */
  dunkelverarbeitung: {
    series: makeSeries(
      []
    ),

    splits: {
      prozess: [
        { name: "Antragsbearbeitung", value: 52 },
        { name: "Schadenregulierung", value: 31 },
        { name: "Bestandsänderung", value: 44 },
        { name: "Kundenservice", value: 37 }
      ]
    },
    dataQuality: { completeness: 0, lastUpdated: null, sourceSystem: "Workflow-Systeme (Auswertung ausstehend)", steward: "COO / IT" }
  },

  /* Ende-zu-Ende-Durchlaufzeit (Tage)
     Einzupflegen: Ab 2027 (Nullmessung ≤ 2027); Split nach
     Kernprozess für Engpass-Analyse. */
  durchlaufzeit: {
    series: makeSeries(
      []
    ),

    splits: {
      kernprozess: [
        { name: "Antrag bis Police (Neugeschäft)", value: 14.2 },
        { name: "Schadenmeldung bis Regulierung", value: 9.8 },
        { name: "Bestandsänderung", value: 6.4 },
        { name: "Kundenanfrage bis Antwort", value: 3.1 }
      ]
    },
    dataQuality: { completeness: 0, lastUpdated: null, sourceSystem: "Prozess-Monitoring (Nullmessung ausstehend)", steward: "COO" }
  },

  /* Kundenzufriedenheit CSAT (Note, 1 = sehr gut)
     Einzupflegen: Halbjahreswerte (KUBUS); Split nach
     Geschäftsfeld und Kanal. */
  csat: {
    series: makeSeries(
      [
        null, 2.05, null, 2.05, null, 2.05
      ]
    ),

    splits: {
      geschaftsfeld: [
        { name: "Kranken", value: 2.02 },
        { name: "Leben", value: 2.08 },
        { name: "Schaden/Unfall", value: 2.06 }
      ],
      kanal: [
        { name: "Generalagenten", value: 1.94 },
        { name: "Autohaus", value: 2.11 },
        { name: "Makler", value: 2.09 }
      ]
    },
    dataQuality: { completeness: 95, lastUpdated: "2026-07-31", sourceSystem: "KUBUS-Kundenbefragung", steward: "Marktforschung" }
  },

  /* Nutzung von Präventionsservices (Services/Kunde)
     Einzupflegen: Ab 2027 (Methodik bis 2028); Split nach
     Service für Adoptions-Analyse. */
  praeventionsnutzung: {
    series: makeSeries(
      []
    ),

    splits: {
      service: [
        { name: "PRAEVIA (bKV)", value: 0.12 },
        { name: "mentalis (BU)", value: 0.08 },
        { name: "Hochwasser-Pass", value: 0.06 },
        { name: "Unfallhelfer", value: 0.05 }
      ]
    },
    dataQuality: { completeness: 0, lastUpdated: null, sourceSystem: "Service-Plattformen (Methodik in Entwicklung)", steward: "Leitung Prävention" }
  },

  /* Reduktion S/L-Aufwendungen durch Prävention (% Effekt)
     Einzupflegen: Ab 2027 (Pilot-/Kontrollgruppen); Split nach
     Sparte für Wirkungsanalyse. */
  schaden_leistung_praevention: {
    series: makeSeries(
      []
    ),

    splits: {
      sparte: [
        { name: "Kranken (bKV-PRAEVIA)", value: -2.6 },
        { name: "Leben (BU-mentalis)", value: -1.9 },
        { name: "S/U (Hochwasser-Pass)", value: -3.4 }
      ]
    },
    dataQuality: { completeness: 0, lastUpdated: null, sourceSystem: "Schaden-/Leistungsdaten + Präventionsnutzung (Attributionsmodell)", steward: "Aktuariat + Prävention" }
  },

  /* Stornoquote (%)
     Einzupflegen: Quartals-Ist; Split nach Kanal und Segment. */
  stornoquote: {
    series: makeSeries(
      [
        10.6, 10.7, 10.8, 10.9, 10.8, 10.7
      ]
    ),

    splits: {
      kanal: [
        { name: "Generalagenten", value: 8.9 },
        { name: "Autohaus", value: 11.4 },
        { name: "Makler / MGA", value: 12.1 }
      ],
      segment: [
        { name: "Privat", value: 10.9 },
        { name: "Gewerbe", value: 9.2 }
      ]
    },
    dataQuality: { completeness: 100, lastUpdated: "2026-07-15", sourceSystem: "Bestandssysteme", steward: "Bestandsmanagement" }
  },

  /* Zielgruppenanteil (% Volumen)
     Einzupflegen: Ab 2027 (Zielgruppendefinition Ende 2026);
     Split nach Segment. */
  zielgruppenanteil: {
    series: makeSeries(
      []
    ),

    splits: {
      segment: [
        { name: "Privat (präventionsaffin)", value: 36 },
        { name: "Gewerbe KMU", value: 41 },
        { name: "Gewerbe-Individual", value: 48 }
      ]
    },
    dataQuality: { completeness: 0, lastUpdated: null, sourceSystem: "Bestandssysteme + CRM (Definition ausstehend)", steward: "Geschäftsfeld + Vertrieb" }
  },

  /* Vermittler-Score (Index)
     Einzupflegen: Ab 2027 (Piloten bis 2028); Komponenten
     einzeln erfassen. */
  vermittler_score: {
    series: makeSeries(
      []
    ),

    splits: {
      komponente: [
        { name: "Schaden-/Leistungsquote", value: 61 },
        { name: "Provision", value: 55 },
        { name: "Neugeschäft", value: 62 },
        { name: "Stornoquote", value: 58 },
        { name: "E-Antragsquote", value: 49 },
        { name: "Präventionsquote", value: 42 },
        { name: "Nutzungsrate digitale Services", value: 53 }
      ]
    },
    dataQuality: { completeness: 0, lastUpdated: null, sourceSystem: "Vertriebs- und Bestandsdaten (Pilotphase)", steward: "Vertrieb" }
  },

  /* Vermittlerzufriedenheit AO (Punkte, 100er Skala)
     Einzupflegen: Jahreswerte (AO-Studie); Split nach Region. */
  vermittlerzufriedenheit_ao: {
    series: makeSeries(
      [
        null, null, null, 55
      ]
    ),

    splits: {
      region: [
        { name: "Nord", value: 57 },
        { name: "Mitte", value: 54 },
        { name: "Süd", value: 55 }
      ]
    },
    dataQuality: { completeness: 100, lastUpdated: "2026-01-31", sourceSystem: "AO-Studie (50 Vertriebspartner)", steward: "Vertrieb" }
  },

  /* Vermittlerzufriedenheit Makler (Punkte, 100er Skala)
     Einzupflegen: Jahreswerte (AssCompact); Split nach
     Maklergröße. */
  vermittlerzufriedenheit_makler: {
    series: makeSeries(
      [
        null, null, null, 87
      ]
    ),

    splits: {
      maklergroesse: [
        { name: "Großmakler (> 50 MA)", value: 89 },
        { name: "Mittelstand (10-50 MA)", value: 87 },
        { name: "Klein (< 10 MA)", value: 85 }
      ]
    },
    dataQuality: { completeness: 100, lastUpdated: "2026-01-31", sourceSystem: "AssCompact Maklerservice (~300 Makler)", steward: "Vertrieb" }
  },

  /* E-Antragsquote (%)
     Einzupflegen: Quartals-Ist; Split nach Kanal. */
  e_antragsquote: {
    series: makeSeries(
      [
        31, 33, 35, 37, 39, 41
      ]
    ),

    splits: {
      kanal: [
        { name: "Generalagenten", value: 44 },
        { name: "Autohaus", value: 52 },
        { name: "Makler / MGA", value: 28 }
      ]
    },
    dataQuality: { completeness: 100, lastUpdated: "2026-07-15", sourceSystem: "Vertriebssysteme", steward: "Vertrieb" }
  },

  /* ============================================================
     Vorschläge
     ============================================================ */

  wachstum_vs_markt: {
    series: makeSeries(
      [
        null, null, null, -3.9, null, -3.2
      ]
    ),

    splits: {
      geschaftsfeld: [
        { name: "Kranken", value: 4.2 },
        { name: "Leben", value: -6.1 },
        { name: "Schaden/Unfall", value: -2.8 }
      ]
    },
    dataQuality: { completeness: 60, lastUpdated: "2026-07-15", sourceSystem: "GDV-Statistik + Konzernrechnungswesen", steward: "Controlling" }
  },

  nettoverzinsung: {
    series: makeSeries(
      [
        2.9, 2.9, 3.0, 3.0, 3.1, 3.1
      ]
    ),

    splits: {
      anlageklasse: [
        { name: "Festverzinslich", value: 2.6 },
        { name: "Aktien", value: 6.8 },
        { name: "Immobilien", value: 3.9 },
        { name: "Alternative", value: 5.2 }
      ]
    },
    dataQuality: { completeness: 100, lastUpdated: "2026-07-15", sourceSystem: "Kapitalanlage-Controlling / NAM", steward: "NAM" }
  },

  kfz_anteil: {
    series: makeSeries(
      [
        31, 30.5, 30, 30, 29.5, 29
      ]
    ),
    splits: {
      /* Split nach Neugeschäft und Bestand */
      bestand_neu: [
        { name: "Bestand", value: 30 },
        { name: "Neugeschäft", value: 24 }
      ]
    },
    dataQuality: { completeness: 100, lastUpdated: "2026-07-15", sourceSystem: "Bestandssysteme", steward: "Geschäftsfeld S/U" }
  }
};

