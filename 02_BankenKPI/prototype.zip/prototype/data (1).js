/* ============================================================
   NÜRNBERGER KPI-Board — Kennzahlen und Stammdaten
   ------------------------------------------------------------
   Drei Fragen an dieselbe Kette:
   1  Gewinnen wir wirtschaftlich?  (finance)
   2  Wirken die vier Hebel?        (central, je Hebel)
   3  Tun wir die richtigen Dinge?  (drivers, je Hebel)
   Quelle der Basis- und Zielwerte: Geschäftsstrategie, Entwurf
   Update 2026. Ziele, die dort nicht stehen, sind TBD oder als
   Annahme gekennzeichnet. Ist-Werte und Verläufe sind Beispielwerte
   (prov: illustrativ). Vorschläge außerhalb der Strategie tragen
   vorschlag: true.
   ============================================================ */

const DATA = {
  meta: {
    asOf: "20.09.2026",
    title: "NÜRNBERGER KPI-Board",
    subtitle: "Strategie-Steuerung 2026-2031 · Drei Fragen, eine Kette",
    ertragsziel: {
      hgb: { current: 46.8, currentLabel: "2025", target: 100, targetLabel: ">100 Mio. EUR (2031)", baseline: -77.0, baselineLabel: "2024" },
      ifrs: { target: "XXX Mio. EUR", note: "wird nach Planung Ende 2026 nachgereicht" },
      note: "Konzernergebnis 2025: 46,8 Mio. EUR (Vorjahr -77,0 Mio.; +124 Mio. Verbesserung). IFRS-Ziel nach Planung Ende 2026."
    }
  },

  /* ---------- Frage 1: Gewinnen wir wirtschaftlich? ---------- */
  finance: [
    {
      id: "konzernergebnis", name: "Konzernergebnis (HGB)", lever: "finanzen", row: 1,
      unit: "Mio. EUR", direction: "up", status: "amber",
      baseline: { value: 46.8, label: "2025" }, current: { value: 46.8, label: "2025" },
      target2028: { value: 90, text: "90 Mio. EUR (Annahme)", documented: false },
      target2031: { value: 100, text: ">100 Mio. EUR", documented: true },
      history: [-77.0, 46.8],
      /* Kumulierte Messung: der Quartalswert ist der Jahreswert bis zu
         diesem Quartal (Q4 = Jahresergebnis). Gemessen wird der jüngste
         Wert gegen den Planwert derselben Periode. annualTarget greift
         nur, wenn es keinen Plan gibt. */
      ytd: {
        mode: "kumuliert",
        annualTarget: null,     /* Jahresziel kommt aus dem Plan */
        annualTargetLabel: null,
        weights: null,          /* null = linear: 0.25 je Quartal */
        weightsNote: "Rückfall-Verteilung, falls kein Zielpfad vorliegt: linear (¼ je Quartal). Bei echter Saisonalität Gewichte je Quartal hinterlegen — Summe = 1."
      },
      explain: "Das Ergebnis des NÜRNBERGER Konzerns nach HGB. Es bündelt die Wirkung aller vier Hebel und ist die oberste Zielgröße der Strategie.",
      measurement: { type: "Rechnungswesen", detail: "Konzernrechnungswesen, halbjährlich Ist" },
      formula: "Konzernergebnis nach HGB (Abgrenzung mit Controlling festlegen)",
      source: "Konzernrechnungswesen / Controlling", owner: "CFRO (Responsible) · Gesamtgremium (Accountable)", cadence: "Quartal",
      thresholds: "Grün: ≥ Zielpfad · Gelb: bis -5 % · Rot: > -5 % Abweichung",
      notes: "IFRS-Ziel (XXX Mio. EUR) wird nach Planung Ende 2026 ergänzt. 2024: -77,0 Mio. EUR; 2025: +124 Mio. Verbesserung (u. a. back2black).",
      prov: { ziel2028: "annahme", ziel2031: "dokumentiert", ist: "illustrativ", basis: "dokumentiert", verlauf: "illustrativ" }
    },
    {
      id: "kostenquote", name: "Kostenquote", lever: "finanzen", row: 1,
      unit: "%", direction: "down", status: "green",
      baseline: { value: 13.5, label: "2025" }, current: { value: 13.5, label: "2025" },
      target2028: { value: 14.3, text: "14,3 %", documented: true },
      target2031: { value: 12.3, text: "12,3 %", documented: true },
      history: [13.5],
      pathNote: "Planmäßig ansteigend bis 2028 (Investitionsphase Move:N, Systemerneuerung), danach fallend auf 12,3 %.",
      explain: "Verhältnis der Kosten zu den gebuchten Bruttobeiträgen. Etablierte Interimskennzahl für Kosten je Vertrag (bis 2028 entwickelt).",
      measurement: { type: "Rechnungswesen", detail: "Konzernrechnungswesen / Controlling, quartalsweise" },
      formula: "(Verwaltungs- + Abschlusskosten) ÷ gebuchte Bruttobeiträge",
      source: "Konzernrechnungswesen", owner: "CFRO", cadence: "Quartal",
      thresholds: "Grün: ≤ Zielpfad (14,3 % bis 2028, dann fallend) · Gelb: bis +5 % · Rot: > +5 % über Pfad",
      notes: "Dokumentierter Pfad: 13,5 % (2025) → 14,3 % (2028) → 12,3 % (2031). Der Anstieg bis 2028 ist eingeplant (Investitionsphase).",
      prov: { ziel2028: "dokumentiert", ziel2031: "dokumentiert", ist: "illustrativ", basis: "dokumentiert", verlauf: "illustrativ" }
    },
    {
      id: "solvenzquote", name: "Solvenzquote", lever: "finanzen", row: 1,
      unit: "%", direction: "up", status: "green", guardrail: true,
      baseline: { value: 302, label: "2025" }, current: { value: 302, label: "2025" },
      target2028: { value: null, text: "Guardrail ≥ 200 %", documented: true },
      target2031: { value: null, text: "Guardrail ≥ 200 %", documented: true },
      history: [247, 302],
      explain: "Die Kapitalausstattung der NÜRNBERGER relativ zum Solvenzbedarf. Voraussetzung des Ertragsziels (dauerhaft starke Solvenzquoten).",
      measurement: { type: "Rechnungswesen", detail: "Risikomodell / Aktuariat, quartalsweise" },
      formula: "Eigenmittel ÷ Solvenzbedarf (Solvency II)",
      source: "Risikomodell / Aktuariat", owner: "CFRO (Risikostrategie)", cadence: "Quartal",
      thresholds: "Guardrail: Grün ≥ 200 % · Gelb 175-200 % · Rot < 175 %",
      notes: "302 % (2025), Fitch A+. Höher ist besser gilt hier nicht unbegrenzt — überschüssiges Kapital hat Opportunitätskosten.",
      prov: { ziel2028: "dokumentiert", ziel2031: "dokumentiert", ist: "illustrativ", basis: "dokumentiert", verlauf: "illustrativ" }
    }
  ],

  /* ---------- Frage 2: Hebel und zentrale Wirkungskennzahlen ---------- */
  levers: [
    { id: "mitarbeitende", name: "Mitarbeitende", claim: "Wir stärken Kompetenz, Gesundheit und Eigenverantwortung.", centralKpi: "enps" },
    { id: "prozesse", name: "Prozesse", claim: "Wir reduzieren unnötige Komplexität und automatisieren konsequent.", centralKpi: "stueckkosten" },
    { id: "kunden", name: "Kunden", claim: "Wir vertiefen Beziehungen und richten unser Angebot auf die richtigen Kunden und ihre Bedürfnisse.", centralKpi: "vertragsdichte" },
    { id: "vermittler", name: "Vermittler", claim: "Wir helfen Vermittlern, produktiver zu werden, und steuern nach Ertrag.", centralKpi: "ertragsbarwert" }
  ],

  central: [
    {
      id: "enps", name: "eNPS", lever: "mitarbeitende", row: 2, maturity: "etabliert",
      unit: "Punkte", direction: "up", status: "red",
      baseline: { value: -39, label: "2026", period: "2026-Q1" }, current: { value: -39, label: "2026" },
      target2028: { value: 0, text: "> 0 Punkte", documented: true },
      target2031: { value: 10, text: "> 10 Punkte", documented: true },
      history: [-39],
      explain: "Ob Mitarbeitende die NÜRNBERGER als Arbeitgeber weiterempfehlen; ein positiver Wert heißt: mehr Empfehlungen als Abratungen.",
      measurement: { type: "Befragung", detail: "Puls-Check (Mitarbeiterbefragung), halbjährlich" },
      formula: "% Promotoren − % Detraktoren (0-10-Skala, Puls-Check)",
      source: "Puls-Check (Mitarbeiterbefragung)", owner: "CEO (Leadership & Kultur)", cadence: "Halbjährlich",
      thresholds: "Grün: ≥ Zielpfad (−39 → >0 → >10) · Gelb: bis 5 % unter Pfad · Rot: mehr als 5 % unter Pfad",
      notes: "Baseline −39 (2026) — der Hebel startet tief. Zustimmung Die NÜRNBERGER liegt mir am Herzen konstant 93-95 % seit 2023.",
      prov: { ziel2028: "dokumentiert", ziel2031: "dokumentiert", ist: "illustrativ", basis: "dokumentiert", verlauf: "illustrativ" }
    },
    {
      id: "stueckkosten", name: "Kosten je Vertrag", lever: "prozesse", row: 2, maturity: "zu-entwickeln",
      unit: "EUR je Vertrag", direction: "down", status: "tbd",
      baseline: { value: null, label: "—" }, current: { value: null, label: "in Entwicklung" },
      target2028: { value: null, text: "TBD", documented: false },
      target2031: { value: null, text: "TBD", documented: false },
      history: [], interim: "kostenquote",
      explain: "Die fixen Personal- und Sachkosten je Vertrag. Zentrale Wirkungskennzahl des Prozesse-Hebels; bis 2028 entwickelt.",
      measurement: { type: "Rechnungswesen", detail: "Kostenrechnung + Bestandssysteme, quartalsweise" },
      formula: "(Fixe Personal- + Sachkosten) ÷ Ø Vertragsbestand",
      source: "Kostenrechnung + Bestandssysteme", owner: "CFRO", cadence: "Quartal",
      thresholds: "TBD — nach Methodik-Freigabe",
      notes: "Interim: Kostenquote (Zeile 1, dokumentierter Pfad 13,5 → 14,3 → 12,3 %). Methodik bis 2028.",
      methodology: {
        definition: "Fixe Personal- und Sachkosten je Vertrag. Zentrale Wirkungskennzahl des Hebels Prozesse.",
        approach: [
          "Abgrenzung fixe vs. variable Kosten; Einmaleffekte separat ausweisen.",
          "Nenner-Definition: Vertragsbestand vs. Risikoäquivalente.",
          "Segmentierung nach Geschäftsfeld und Kanal.",
          "Zielwert je Vertrag nach Planung Ende 2026 ableiten."
        ],
        open: ["Nenner-Definition", "Einmaleffekte", "Zielwert"]
      },
      prov: { ziel2028: "ausstehend", ziel2031: "ausstehend", ist: "ausstehend", basis: "ausstehend", verlauf: "ausstehend" }
    },
    {
      id: "vertragsdichte", name: "Vertragsdichte je Kunde", lever: "kunden", row: 2, maturity: "etabliert",
      unit: "Verträge je Kunde", direction: "up", status: "amber",
      baseline: { value: 1.7, label: "2026", period: "2026-Q1" }, current: { value: 1.7, label: "2026" },
      target2028: { value: 1.85, text: "1,85 (GA: 2,1)", documented: true },
      target2031: { value: 2.0, text: ">2,0 (GA: >2,4)", documented: true },
      history: [1.7],
      explain: "Die durchschnittliche Anzahl der Verträge je Privatkunde. Zentrale Wirkungskennzahl des Kunden-Hebels.",
      measurement: { type: "Systemdaten", detail: "Bestandssysteme + CRM, monatlich" },
      formula: "Σ Verträge ÷ Σ Kunden (Stichtag)",
      source: "Bestandssysteme + CRM", owner: "Geschäftsfeld (Bestand) + Vertrieb (Neugeschäft)", cadence: "Monatlich",
      thresholds: "Grün: ≥ Zielpfad · Gelb: bis -5 % · Rot: > -5 %",
      notes: "73 % der Privatkunden sind Einvertragskunden. GA-Ziel: 2,1 (2028) bzw. >2,4 (2031).",
      prov: { ziel2028: "dokumentiert", ziel2031: "dokumentiert", ist: "illustrativ", basis: "dokumentiert", verlauf: "illustrativ" }
    },
    {
      id: "ertragsbarwert", name: "Ertragsbarwert (S/U)", lever: "vermittler", row: 2, maturity: "auszuwerten",
      unit: "Mio. EUR", direction: "up", status: "tbd",
      baseline: { value: null, label: "—" }, current: { value: null, label: "auszuwerten" },
      target2028: { value: null, text: "TBD", documented: false },
      target2031: { value: null, text: "TBD", documented: false },
      history: [],
      explain: "Der erwartete versicherungstechnische Ertrag in Schaden/Unfall. Zentrale Wirkungskennzahl des Vermittler-Hebels.",
      measurement: { type: "Modell", detail: "Aktuariat / Controlling, quartalsweise" },
      formula: "Erwarteter versicherungstechnischer Ertrag in Schaden/Unfall (Methodik mit Aktuariat abzustimmen)",
      source: "Aktuariat / Controlling", owner: "Vertrieb (Responsible) · Gesamtgremium (Accountable)", cadence: "Quartal",
      thresholds: "TBD — nach Methodik-Freigabe",
      notes: "Bezug: erwarteter versicherungstechnischer Ertrag in Schaden/Unfall. Offen: Ausweitung auf Leben/Kranken?",
      methodology: {
        definition: "Erwarteter versicherungstechnischer Ertrag in Schaden/Unfall (S/U).",
        approach: [
          "Methodik mit Aktuariat/Controlling abstimmen; Roll-Forward-Logik.",
          "Konsistenz HGB/IFRS sicherstellen.",
          "Zielwert nach Methodik-Freigabe ableiten.",
          "Klärung: S/U-only oder Ausweitung auf Leben/Kranken?"
        ],
        open: ["Scoping S/U vs. L/KV", "Diskontierungssatz", "Zielwert"]
      },
      prov: { ziel2028: "ausstehend", ziel2031: "ausstehend", ist: "ausstehend", basis: "ausstehend", verlauf: "ausstehend" }
    }
  ],

  /* ---------- Frage 3: Treiber je Hebel ---------- */
  drivers: [
    { id: "praeventions_score", name: "NÜRNBERGER Präventions-Score", lever: "mitarbeitende", maturity: "zu-entwickeln",
      unit: "Index", direction: "up", status: "tbd",
      baseline: { value: null, label: "—" }, current: { value: null, label: "in Entwicklung" },
      target2028: { value: null, text: "TBD", documented: false }, target2031: { value: null, text: "TBD", documented: false },
      history: [], components: ["Krankentage je MA", "Weiterbildungstage je MA", "Change Adoption Rate"],
      explain: "Index aus Gesundheit, Weiterentwicklung und Veränderungsfähigkeit. Wird bis 2028 entwickelt.",
      source: "Puls-Check, HR-Systeme", owner: "CEO (Leadership & Kultur)", cadence: "Halbjährlich",
      prov: { ziel2028: "ausstehend", ziel2031: "ausstehend", ist: "ausstehend", basis: "ausstehend", verlauf: "ausstehend" } },
    { id: "change_adoption", name: "Change Adoption Rate", lever: "mitarbeitende", maturity: "zu-entwickeln",
      unit: "%", direction: "up", status: "amber",
      baseline: { value: 15, label: "2026", period: "2026-Q1" }, current: { value: 15, label: "2026" },
      target2028: { value: 70, text: ">70 %", documented: true }, target2031: { value: 80, text: ">80 %", documented: true },
      history: [15],
      explain: "Wie Mitarbeitende Arbeitsweisen adaptieren und den Wandel aktiv mittragen (z. B. aktive Nutzung von KI-Tools).",
      source: "Tool-Nutzungsdaten + Befragung", owner: "CEO (Leadership & Kultur)", cadence: "Quartal",
      prov: { ziel2028: "dokumentiert", ziel2031: "dokumentiert", ist: "illustrativ", basis: "dokumentiert", verlauf: "illustrativ" } },
    { id: "leadership_score", name: "NÜRNBERGER Leadership-Score", lever: "mitarbeitende", maturity: "etabliert",
      unit: "Punkte", direction: "up", status: "amber",
      baseline: { value: 79, label: "2026", period: "2026-Q1" }, current: { value: 79, label: "2026" },
      target2028: { value: 81, text: "81 Punkte", documented: true }, target2031: { value: 85, text: "85 Punkte", documented: true },
      history: [79],
      explain: "Wie wirksam Führungskräfte die Transformation begleiten: Dimensionen Steuerung und Zielkultur (Mut, Outcome-Orientierung, Vertrauen, Klarheit).",
      source: "Mitarbeiterbefragung", owner: "CEO", cadence: "Halbjährlich",
      prov: { ziel2028: "dokumentiert", ziel2031: "dokumentiert", ist: "illustrativ", basis: "dokumentiert", verlauf: "illustrativ" } },
    { id: "frauenquote", name: "Frauenquote in Führungspositionen", lever: "mitarbeitende", maturity: "etabliert",
      unit: "%", direction: "up", status: "amber",
      baseline: { value: 26, label: "2026 (BE 1+2)", period: "2026-Q1" }, current: { value: 26, label: "2026 (BE 1+2)" },
      target2028: { value: 30, text: "30-50 %", documented: true }, target2031: { value: 40, text: "40-50 %", documented: true },
      history: [26],
      explain: "Anteil von Frauen in allen Führungsebenen, Fokus Berichtsebenen 1 und 2.",
      source: "HR-System", owner: "CEO", cadence: "Halbjährlich",
      prov: { ziel2028: "dokumentiert", ziel2031: "dokumentiert", ist: "illustrativ", basis: "dokumentiert", verlauf: "illustrativ" } },

    { id: "automatisierungsgrad", name: "Automatisierungsgrad", lever: "prozesse", maturity: "auszuwerten",
      unit: "%", direction: "up", status: "tbd",
      baseline: { value: null, label: "aus Planung 2026" }, current: { value: null, label: "auszuwerten" },
      target2028: { value: null, text: "TBD", documented: false }, target2031: { value: null, text: "TBD", documented: false },
      history: [],
      explain: "Anteil der Vorgänge in Geschäfts- und Unterstützungsprozessen, die durch Daten, Automatisierung oder KI unterstützt werden.",
      source: "Workflow-Systeme", owner: "COO / IT", cadence: "Monatlich",
      prov: { ziel2028: "ausstehend", ziel2031: "ausstehend", ist: "ausstehend", basis: "ausstehend", verlauf: "ausstehend" } },
    { id: "dunkelverarbeitung", name: "Dunkelverarbeitungsquote", lever: "prozesse", maturity: "auszuwerten",
      unit: "%", direction: "up", status: "tbd",
      baseline: { value: null, label: "—" }, current: { value: null, label: "auszuwerten" },
      target2028: { value: null, text: "TBD", documented: false }, target2031: { value: null, text: "TBD", documented: false },
      history: [],
      explain: "Anteil der Vorgänge, die vollständig ohne manuelle Bearbeitung abgeschlossen werden.",
      source: "Workflow-Systeme", owner: "COO / IT", cadence: "Monatlich",
      prov: { ziel2028: "ausstehend", ziel2031: "ausstehend", ist: "ausstehend", basis: "ausstehend", verlauf: "ausstehend" } },
    { id: "durchlaufzeit", name: "Ende-zu-Ende-Durchlaufzeit", lever: "prozesse", maturity: "auszuwerten",
      unit: "Tage", direction: "down", status: "tbd",
      baseline: { value: null, label: "Nullmessung ≤ 2027" }, current: { value: null, label: "auszuwerten" },
      target2028: { value: null, text: "TBD", documented: false }, target2031: { value: null, text: "TBD", documented: false },
      history: [],
      explain: "Dauer ausgewählter Kernprozesse von Anfang bis Ende (z. B. Antrag bis Police). Nullmessung spätestens 2027.",
      source: "Prozess-Monitoring", owner: "COO", cadence: "Monatlich",
      prov: { ziel2028: "ausstehend", ziel2031: "ausstehend", ist: "ausstehend", basis: "ausstehend", verlauf: "ausstehend" } },

    { id: "csat", name: "Kundenzufriedenheit (CSAT)", lever: "kunden", maturity: "etabliert",
      unit: "Note (1 = sehr gut)", direction: "down", status: "amber",
      baseline: { value: 2.05, label: "Mitte 2026 (Markt 1,98)", period: "2026-Q2" }, current: { value: 2.05, label: "2026" },
      target2028: { value: 2.01, text: "mindestens 2,01", documented: true }, target2031: { value: null, text: "Besser als Marktdurchschnitt", documented: true },
      history: [2.05],
      explain: "Zufriedenheit der Privatkunden auf Schulnoten-Skala (niedriger ist besser). KUBUS-Befragung.",
      source: "KUBUS-Kundenbefragung", owner: "Operations (Responsible)", cadence: "Halbjährlich",
      prov: { ziel2028: "dokumentiert", ziel2031: "dokumentiert", ist: "illustrativ", basis: "dokumentiert", verlauf: "illustrativ" } },
    { id: "praeventionsnutzung", name: "Nutzung von Präventionsservices", lever: "kunden", maturity: "zu-entwickeln",
      unit: "Services je Kunde", direction: "up", status: "tbd",
      baseline: { value: null, label: "—" }, current: { value: null, label: "in Entwicklung" },
      target2028: { value: null, text: "TBD", documented: false }, target2031: { value: null, text: "TBD", documented: false },
      history: [],
      explain: "Wie intensiv Kunden die angebotenen Präventionsbausteine (PRAEVIA, mentalis, Hochwasser-Pass) nutzen.",
      source: "Service-Plattformen", owner: "Leitung Prävention", cadence: "Quartal",
      prov: { ziel2028: "ausstehend", ziel2031: "ausstehend", ist: "ausstehend", basis: "ausstehend", verlauf: "ausstehend" } },
    { id: "schaden_leistung_praevention", name: "Reduktion S/L-Aufwendungen durch Prävention", lever: "kunden", maturity: "zu-entwickeln",
      unit: "% Effekt", direction: "down", status: "tbd",
      baseline: { value: null, label: "—" }, current: { value: null, label: "in Entwicklung" },
      target2028: { value: null, text: "TBD", documented: false }, target2031: { value: null, text: "TBD", documented: false },
      history: [],
      explain: "Ob Prävention Schaden- und Leistungsaufwendungen reduziert. Wird bis 2028 entwickelt; Attribution über Pilot-/Kontrollgruppen.",
      source: "Schaden-/Leistungsdaten + Präventionsnutzung", owner: "Aktuariat + Leitung Prävention", cadence: "Halbjährlich",
      prov: { ziel2028: "ausstehend", ziel2031: "ausstehend", ist: "ausstehend", basis: "ausstehend", verlauf: "ausstehend" } },
    { id: "stornoquote", name: "Stornoquote", lever: "kunden", maturity: "auszuwerten",
      unit: "%", direction: "down", status: "tbd",
      baseline: { value: null, label: "—" }, current: { value: null, label: "auszuwerten" },
      target2028: { value: null, text: "TBD", documented: false }, target2031: { value: null, text: "deutlich verringert (qualitativ)", documented: true },
      history: [],
      explain: "Anteil stornierter Verträge. Misst Bestandssicherung; Komponente des Vermittler-Scores.",
      source: "Bestandssysteme", owner: "Geschäftsfeld (Bestand)", cadence: "Monatlich",
      prov: { ziel2028: "ausstehend", ziel2031: "dokumentiert", ist: "illustrativ", basis: "ausstehend", verlauf: "illustrativ" } },
    { id: "zielgruppenanteil", name: "Zielgruppenanteil", lever: "kunden", maturity: "zu-entwickeln", vorschlag: true,
      unit: "% Volumen", direction: "up", status: "tbd",
      baseline: { value: null, label: "—" }, current: { value: null, label: "in Entwicklung" },
      target2028: { value: null, text: "TBD", documented: false }, target2031: { value: null, text: "TBD", documented: false },
      history: [],
      explain: "Anteil des Bestands- und Neugeschäftsvolumens in den definierten Zielkundengruppen und -segmenten. Ergänzende Kennzahl: von der Strategielogik verlangt, aber nicht als KPI benannt.",
      source: "Bestandssysteme + CRM", owner: "Geschäftsfeld + Vertrieb", cadence: "Quartal",
      prov: { ziel2028: "ausstehend", ziel2031: "ausstehend", ist: "ausstehend", basis: "ausstehend", verlauf: "ausstehend" } },

    { id: "vermittler_score", name: "Vermittler-Score", lever: "vermittler", maturity: "zu-entwickeln",
      unit: "Index", direction: "up", status: "tbd",
      baseline: { value: null, label: "—" }, current: { value: null, label: "in Entwicklung" },
      target2028: { value: null, text: "TBD", documented: false }, target2031: { value: null, text: "TBD", documented: false },
      history: [],
      components: ["Schaden-/Leistungsquote", "Provision", "Neugeschäft", "Stornoquote", "E-Antragsquote", "Präventionsquote", "Nutzungsrate digitale Services"],
      explain: "Ertragsorientierte Steuerungsgröße für Vermittler; bündelt Ertrags- und Kooperationskomponenten. Bis 2028 entwickelt (Pilotpartner).",
      source: "Vertriebs- und Bestandsdaten", owner: "Vertrieb", cadence: "Quartal",
      prov: { ziel2028: "ausstehend", ziel2031: "ausstehend", ist: "ausstehend", basis: "ausstehend", verlauf: "ausstehend" } },
    { id: "vermittlerzufriedenheit_ao", name: "Vermittlerzufriedenheit AO", lever: "vermittler", maturity: "auszuwerten",
      unit: "Punkte (100er Skala)", direction: "up", status: "tbd",
      baseline: { value: 55, label: "2025" }, current: { value: 55, label: "2025" },
      target2028: { value: null, text: "≥ Marktmedian (Wert in Ausarbeitung)", documented: true }, target2031: { value: null, text: "in Ausarbeitung", documented: true },
      history: [55],
      explain: "Zufriedenheit der Ausschließlichkeitsorganisation (AO-Studie, 50 Vertriebspartner). 100er Skala.",
      source: "AO-Studie", owner: "Vertrieb", cadence: "Jährlich",
      prov: { ziel2028: "dokumentiert", ziel2031: "dokumentiert", ist: "illustrativ", basis: "dokumentiert", verlauf: "illustrativ" } },
    { id: "vermittlerzufriedenheit_makler", name: "Vermittlerzufriedenheit Makler", lever: "vermittler", maturity: "auszuwerten",
      unit: "Punkte (100er Skala)", direction: "up", status: "tbd",
      baseline: { value: 87, label: "2025" }, current: { value: 87, label: "2025" },
      target2028: { value: null, text: "obere 25 % des Markts (Wert in Ausarbeitung)", documented: true }, target2031: { value: null, text: "in Ausarbeitung", documented: true },
      history: [87],
      explain: "Zufriedenheit der Makler (AssCompact Maklerservice Private Vorsorge/Biometrie, rund 300 Makler). 100er Skala.",
      source: "AssCompact Maklerservice", owner: "Vertrieb", cadence: "Jährlich",
      prov: { ziel2028: "dokumentiert", ziel2031: "dokumentiert", ist: "illustrativ", basis: "dokumentiert", verlauf: "illustrativ" } },
    { id: "e_antragsquote", name: "E-Antragsquote", lever: "vermittler", maturity: "auszuwerten",
      unit: "%", direction: "up", status: "tbd",
      baseline: { value: null, label: "—" }, current: { value: null, label: "auszuwerten" },
      target2028: { value: null, text: "TBD", documented: false }, target2031: { value: null, text: "TBD", documented: false },
      history: [],
      explain: "Anteil digital eingehender Anträge. Kooperationskomponente des Vermittler-Scores.",
      source: "Vertriebssysteme", owner: "Vertrieb", cadence: "Monatlich",
      prov: { ziel2028: "ausstehend", ziel2031: "ausstehend", ist: "illustrativ", basis: "ausstehend", verlauf: "illustrativ" } }
  ],

  /* ---------- Zielbausteine ---------- */
  buildingBlocks: [
    { id: "wachstum", name: "Ertragreiches Wachstum", kpis: ["konzernergebnis", "vertragsdichte", "ertragsbarwert"], status: "amber" },
    { id: "kosten", name: "Marktadäquate Kostenbelastung", kpis: ["kostenquote", "stueckkosten", "automatisierungsgrad", "dunkelverarbeitung"], status: "green" },
    { id: "zufriedenheit", name: "Kunden- und Vermittlerzufriedenheit", kpis: ["csat", "vermittlerzufriedenheit_ao", "vermittlerzufriedenheit_makler"], status: "amber" },
    { id: "leadership", name: "Leadership-Qualitäten", kpis: ["leadership_score"], status: "amber" },
    { id: "frauen", name: "Frauen in Führungspositionen", kpis: ["frauenquote"], status: "amber" }
  ],

  /* ---------- Portfolio-Prioritäten und „Was machen wir nicht mehr?" ---------- */
  portfolio: {
    intro: "Die schärfste Steuerungsaussage der Strategie: wo investieren wir (Hoch), wo nur verwalten (Gering) — und was hören wir auf zu tun.",
    privat: [
      { field: "Kranken", product: "Voll", rank: 14, prio: "Gering" },
      { field: "Kranken", product: "Zusatz", rank: 7, prio: "Mittel" },
      { field: "Leben", product: "EKS", rank: 2, prio: "Hoch" },
      { field: "Leben", product: "pAV", rank: 13, prio: "Gering" },
      { field: "Schaden/Unfall", product: "Haftpflicht", rank: 16, prio: "Gering", bestand: "#1 (Hoch)" },
      { field: "Schaden/Unfall", product: "Kfz", rank: 12, prio: "Mittel" },
      { field: "Schaden/Unfall", product: "Rechtsschutz", rank: 5, prio: "Hoch" },
      { field: "Schaden/Unfall", product: "Sach", rank: 15, prio: "Gering" },
      { field: "Schaden/Unfall", product: "Unfall", rank: 6, prio: "Hoch" }
    ],
    gewerbe: [
      { field: "Kranken", product: "bKV", rank: 3, prio: "Hoch" },
      { field: "Leben", product: "bAV", rank: 4, prio: "Hoch" },
      { field: "Leben", product: "bEKS", rank: 17, prio: "Gering" },
      { field: "Schaden/Unfall", product: "Haftpflicht", rank: 10, prio: "Mittel" },
      { field: "Schaden/Unfall", product: "Kfz-Flotte", rank: 11, prio: "Mittel" },
      { field: "Schaden/Unfall", product: "Rechtsschutz", rank: 9, prio: "Mittel" },
      { field: "Schaden/Unfall", product: "Sach", rank: 8, prio: "Mittel" },
      { field: "Schaden/Unfall", product: "Unfall", rank: 18, prio: "Gering", bestand: "#1 (Hoch)" }
    ],
    wendepunkte: [
      { name: "Kfz-Anteil am S/U-Bestand", ist: "~30 % der verdienten Beiträge", ziel: "<20 % (2031)", note: "Defokussierung; bleibt Zugangs-/Cross-Selling-Kanal" },
      { name: "bAV-Marktposition", ist: "3,1 % Marktanteil (2024)", ziel: "Top 5 (2031)", note: "Rückgang von 3,4 % (2020)" },
      { name: "Kfz-Flotte Marktanteile", ist: "0,9 % / 0,8 %", ziel: "1,3 % / 1,2 % (2031)", note: "Höherwertige Fahrzeuge / Kernsegment 25-100" },
      { name: "bKV-Neugeschäft", ist: "~+50 % p. a. (2020-24)", ziel: "mit/über Markt (~+30 % p. a.)", note: "Nr. 4 im Maklergeschäft 2025" },
      { name: "EKS-Marktposition", ist: "Nr. 1 Makler-NG, Nr. 2 gesamt", ziel: "Nr. 1 kanalübergreifend (2028)", note: "Drittgrößter BU-Bestand (~1 Mio. Verträge)" }
    ],
    stopDoing: {
      mitarbeitende: [
        "Entscheidungen nicht primär aus interner Sicht oder entlang von Bereichsgrenzen treffen.",
        "Nicht mehr alles gleichzeitig machen, sondern klare Prioritäten setzen.",
        "Nicht mehr auf Veränderungen warten, sondern sie aktiv mitgestalten."
      ],
      prozesse: [
        "Sonderprozesse oder Technologieinvestitionen nur mit nachweisbar positivem Beitrag.",
        "Keine Parallelwelten oder Insellösungen neben den Standardsystemen.",
        "Keine Prozessoptimierung aus Sicht einzelner Bereiche."
      ],
      kunden: [
        "De-Fokussierung des Kraftfahrtgeschäfts; Ausstieg aus dem Motorgeschäft in Italien und Österreich.",
        "Rückzug aus Sparten ohne nachhaltige Wettbewerbsvorteile (Cyber, D&O, Kredit).",
        "Keine jährlichen Neuprodukteinführungen in der Kranken; Schließung nicht ertragreicher Tarife.",
        "Keine neuen Produktentwicklungen in der pAV; kein eigenes AVRG-Produkt."
      ],
      vermittler: [
        "Kein Verzielen auf reines Produktionsvolumen.",
        "Keine Gießkannen-Betreuung.",
        "Keine wesentlichen Vertriebsentscheidungen ohne belastbare Datengrundlage."
      ]
    }
  },

  /* ---------- Governance ---------- */
  governance: {
    cadences: [
      { name: "Performance-Dialog", takt: "Monatlich", audience: "Vorstand + Hebel-Owner",
        purpose: "KPI-Review, Abweichungsanalyse, Maßnahmenentscheidung",
        content: ["Zeile 2 + auffällige Zeile-3-Treiber", "RAG-Abweichungen und Ursachen", "Maßnahmen-Tracking aus Vormonat", "Entscheidungen und Verantwortlichkeiten"] },
      { name: "Strategie-Review", takt: "Quartalsweise", audience: "Vorstand + Bereichsleitungen",
        purpose: "Zielpfade, Portfolio, Ertragsziel",
        content: ["Zeile 1: Ertragsziel, Solvenz, Kostenpfad", "Zielpfade 2026-2028-2031", "Portfolio-Priorisierung", "Risiken und Gegenmaßnahmen"] },
      { name: "Zielsetzung & KPI-Review", takt: "Jährlich", audience: "Vorstand + Controlling",
        purpose: "Kalibrierung der Ziele, Weiterentwicklung des KPI-Sets",
        content: ["Zielwerte für Folgejahr", "KPI-Lebenszyklus", "Methodik-Reviews (Scores, Attribution)", "Benchmark-Aktualisierung"] }
    ],
    roles: [
      { role: "KPI-Owner", desc: "Verantwortet Zielerreichung, Datenqualität und Maßnahmen je KPI (Abbildung 8)." },
      { role: "Data Steward", desc: "Sichert Datenherkunft, Definitionen und Aktualität je Datenquelle." },
      { role: "KPI-Office (PMO)", desc: "Betreibt das Board, bereitet Dialoge vor, verfolgt Maßnahmen." },
      { role: "Controlling / Aktuariat", desc: "Methodik für Scores, Ertragsbarwert und Attributionsmodelle." }
    ],
    escalation: [
      { status: "green", text: "Standardbericht, keine Eskalation." },
      { status: "amber", text: "Maßnahmenplan im monatlichen Performance-Dialog; Wiedervorlage Folgemonat." },
      { status: "red", text: "Eskalation in den Vorstand; Gegenmaßnahmen binnen 30 Tagen; Sonderbericht." },
      { status: "tbd", text: "Entwicklungsauftrag: Methodik und Zielwert bis zum definierten Termin vorlegen." }
    ],
    lifecycle: ["Vorschlag", "Methodik", "Pilotierung", "Freigabe", "Betrieb", "Review", "Ablösung"],
    dataQuality: [
      "Jede KPI hat eine dokumentierte Datenquelle und einen Data Steward.",
      "Nullmessungen (z. B. Durchlaufzeit) sind vor Zielsetzung verpflichtend.",
      "Die Beispielwerte des Prototyps werden durch Werte aus den Quellsystemen ersetzt."
    ]
  },

  /* ---------- Vorschläge außerhalb der Strategie ---------- */
  suggestions: [
    {
      id: "wachstum_vs_markt", name: "Beitragswachstum vs. Markt", lever: "finanzen", row: 1, vorschlag: true, maturity: "auszuwerten",
      unit: "pp vs. Markt", direction: "up", status: "tbd",
      baseline: { value: -3.9, label: "2025 (Beiträge -3,9 %)" }, current: { value: null, label: "GDV-Vergleich ausstehend" },
      target2028: { value: null, text: "TBD", documented: false }, target2031: { value: null, text: "≥ Marktniveau", documented: true },
      history: [],
      explain: "Beitragswachstum relativ zum Markt (GDV). Ziel 2031: mindestens auf Marktniveau wachsen.",
      source: "GDV-Statistik + Konzernrechnungswesen", owner: "Geschäftsfeld + Vertrieb", cadence: "Jährlich",
      prov: { ziel2028: "ausstehend", ziel2031: "dokumentiert", ist: "illustrativ", basis: "dokumentiert", verlauf: "illustrativ" }
    },
    {
      id: "nettoverzinsung", name: "Nettoverzinsung Kapitalanlagen", lever: "finanzen", row: 1, vorschlag: true, maturity: "auszuwerten",
      unit: "%", direction: "up", status: "tbd",
      baseline: { value: null, label: "—" }, current: { value: null, label: "ausstehend" },
      target2028: { value: null, text: "marktüblich", documented: true }, target2031: { value: null, text: "marktüblich", documented: true },
      history: [],
      explain: "Ertrag der Kapitalanlagen nach Kosten. Kapitel 6: mindestens marktübliche Performance; Kapitalanlagen rund 50 % der Bilanzsumme (35,8 Mrd. EUR).",
      source: "Kapitalanlage / NAM", owner: "CFRO / NAM", cadence: "Quartal",
      prov: { ziel2028: "dokumentiert", ziel2031: "dokumentiert", ist: "illustrativ", basis: "ausstehend", verlauf: "illustrativ" }
    },
    {
      id: "kfz_anteil", name: "Kfz-Anteil am S/U-Bestand", lever: "finanzen", row: 1, vorschlag: true,
      unit: "%", direction: "down", status: "amber",
      baseline: { value: 30, label: "2025 (~30 % verdiente Beiträge)" }, current: { value: 30, label: "2025" },
      target2028: { value: null, text: "TBD", documented: false }, target2031: { value: 20, text: "<20 %", documented: true },
      history: [30],
      explain: "Anteil des Kfz-Bestands am Schaden-/Unfallportfolio. Dokumentierter Portfoliowendepunkt der Defokussierung.",
      source: "Bestandssysteme", owner: "Geschäftsfeld S/U", cadence: "Quartal",
      prov: { ziel2028: "ausstehend", ziel2031: "dokumentiert", ist: "illustrativ", basis: "dokumentiert", verlauf: "illustrativ" }
    }
  ],

  /* ---------- Reifegrad-Fahrplan ---------- */
  maturityRoadmap: [
    { when: "Ende 2026", what: "IFRS-Ziel nachgereicht · Automatisierungsgrad aus Planung 2026 · Zielgruppendefinition" },
    { when: "≤ 2027", what: "Nullmessung E2E-Durchlaufzeit" },
    { when: "bis 2028", what: "Kosten je Vertrag · Präventions-Score · Vermittler-Score (Piloten) · Präventionsnutzung · Wirkungsnachweis Prävention · Anzahl Verträge (Erhebung läuft)" },
    { when: "laufend", what: "Ertragsbarwert-Auswertung · Zielwerte Vermittlerzufriedenheit (in Ausarbeitung)" }
  ],

  /* ---------- Offene Punkte ---------- */
  openItems: [
    { topic: "Ertragsbrücke 46,8 → >100", who: "Controlling", what: "Zerlegung inkl. Kapitalanlageergebnis und RfB-Zuführung; das Ertragsziel ist bisher nicht zerlegt" },
    { topic: "Ertragsbarwert-Scoping", who: "Controlling / Aktuariat", what: "S/U-only bestätigen oder Ausweitung auf Leben/Kranken?" },
    { topic: "Präventions-Attribution", who: "Aktuariat + Prävention", what: "Pilot-/Kontrollgruppen-Design festlegen; Kohorten ab 2026 starten" },
    { topic: "Wachstums-KPI", who: "Controlling", what: "GDV-Abgrenzung, Brutto vs. netto, Einmalerträge" },
    { topic: "Zeitkonstanten", who: "Hebel-Owner", what: "Je Treiber-Wirkung-Paar eine Wirkungsverzögerung definieren (Grundlage der Diagnose-Matrix)" }
  ],

  /* ---------- Abweichungen und Maßnahmen ----------
     Soll: jede gelbe oder rote Kennzahl hat einen Eintrag mit Ursache,
     Maßnahme, Owner und Frist. Einträge sind Beispiele. */
  actionRule: "Jede gelbe oder rote Kennzahl braucht genau einen Eintrag: Ursache, Maßnahme, Owner, Frist. Ohne Eintrag ist eine Abweichung nicht steuerbar — nur berichtet.",
  actions: [
    { kpi: "enps", ursache: "Baseline −39 (2026): Veränderungsmüdigkeit nach Fit für die Zukunft und back2black; Prioritäten nicht immer konsequent umgesetzt.", massnahme: "Kultur-Programm: Führungskräfte an Team-Ergebnissen messen, Townhalls, sichtbare Quick Wins.", owner: "CEO", frist: "Q1 2027", status: "offen" },
    { kpi: "vertragsdichte", ursache: "73 % Einvertragskunden; fragmentierte Kundendaten, keine ganzheitliche Kundensicht.", massnahme: "CRM/Kundendatenplattform priorisieren; Next-Best-Offer in GA-Piloten testen.", owner: "Geschäftsfeld + Vertrieb", frist: "Q2 2027", status: "offen" },
    { kpi: "csat", ursache: "2,05 vs. Marktniveau 1,98: Servicelevels noch nicht flächendeckend verbindlich.", massnahme: "E2E-Verantwortung und Servicelevels für die zehn wichtigsten Kernprozesse festlegen.", owner: "Operations", frist: "Q3 2027", status: "offen" },
    { kpi: "kfz_anteil", ursache: "Kfz rund 30 % der verdienten Beiträge S/U; Defokussierung läuft, Ziel unter 20 % bis 2031.", massnahme: "Risikoselektion und Pricing weiter verschärfen; kein Neugeschäft unter Zielmarge.", owner: "Geschäftsfeld S/U", frist: "laufend", status: "in Arbeit" }
  ]
};

/* ---------- Plausibilitätsgrenzen ----------
   Werte außerhalb werden im Datenblatt nicht gespeichert. Ohne Eintrag
   gilt nur die Sprung-Warnung (ui_logic.js). */
const PLAUSIBLE = {
  kostenquote: { min: 0, max: 100 }, change_adoption: { min: 0, max: 100 },
  frauenquote: { min: 0, max: 100 }, automatisierungsgrad: { min: 0, max: 100 },
  dunkelverarbeitung: { min: 0, max: 100 }, stornoquote: { min: 0, max: 100 },
  zielgruppenanteil: { min: 0, max: 100 }, e_antragsquote: { min: 0, max: 100 },
  kfz_anteil: { min: 0, max: 100 },
  solvenzquote: { min: 0, max: 1000 },
  nettoverzinsung: { min: -20, max: 20 },
  enps: { min: -100, max: 100 },
  leadership_score: { min: 0, max: 100 },
  vermittlerzufriedenheit_ao: { min: 0, max: 100 },
  vermittlerzufriedenheit_makler: { min: 0, max: 100 },
  csat: { min: 1, max: 6 },
  wachstum_vs_markt: { min: -50, max: 50 },
  schaden_leistung_praevention: { min: -100, max: 100 },
  vertragsdichte: { min: 1, max: 10 },
  durchlaufzeit: { min: 0 }, stueckkosten: { min: 0 }, praeventionsnutzung: { min: 0 }
};
[...DATA.finance, ...DATA.central, ...DATA.drivers, ...DATA.suggestions].forEach(k => {
  if (PLAUSIBLE[k.id]) k.plausible = PLAUSIBLE[k.id];
});
