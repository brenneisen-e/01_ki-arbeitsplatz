/* ============================================================
   NÜRNBERGER KPI-Board — Fragen an eine Kennzahl
   ------------------------------------------------------------
   Beantwortet feste Fragen zu einer Kennzahl aus den Angaben des
   Boards. Was nicht hinterlegt ist, wird als fehlend benannt.

   Reine Funktionen ohne DOM: app.js (chatFacts) übergibt einen
   Faktenblock und erhält den Antworttext. Läuft im Browser und
   in Node (Tests).
   ============================================================ */
(function (root) {
  'use strict';

  const fmt = (v, digits) => (typeof v === 'number'
    ? v.toLocaleString('de-DE', { maximumFractionDigits: digits == null ? 2 : digits })
    : String(v == null ? '—' : v));

  const has = v => v !== null && v !== undefined && v !== '';
  const num = v => typeof v === 'number' && !Number.isNaN(v);

  /* Wert mit Einheit, höchstens zwei Nachkommastellen wie im Board. */
  function val(v, unit, digits) {
    return num(v) ? `${fmt(v, digits)}${unit ? ' ' + unit : ''}` : null;
  }

  /* Feste Fragen. `needs` nennt die Ja/Nein-Merkmale im Faktenblock,
     die vorliegen müssen; `keys` ordnet Freitext zu (erste Übereinstimmung
     gewinnt). Nur der Zielpfad ist immer beantwortbar, weil auch
     „es gibt noch keinen Plan" eine Antwort ist. */
  const QUESTIONS = [
    { id: 'status', label: 'Warum dieser Status?', needs: ['status.perf'], keys: /warum|status|ampel|auf kurs|beobachten|handlungsbedarf|\brot\b|\bgelb\b|\bgrün\b/i },
    { id: 'ist', label: 'Wo stehen wir?', needs: ['ist.has'], keys: /wo stehen|aktuell(er)? (wert|stand)|ist.?wert|\bstand\b|wie hoch/i },
    { id: 'ziel', label: 'Wie ist der Zielpfad?', needs: [], keys: /ziel|pfad|plan|vorgabe|2028|2031|wohin/i },
    { id: 'verlauf', label: 'Wie war der Verlauf?', needs: ['series.has'], keys: /verlauf|trend|entwicklung|historie|quartal|bisher/i },
    { id: 'messung', label: 'Wie wird gemessen?', needs: ['messung.has'], keys: /formel|gerechnet|berechnet|messung|gemessen|ermittelt|wie wird/i },
    { id: 'verantwortlich', label: 'Wer verantwortet sie?', needs: ['verantwortung.has'], keys: /wer (ist|verantwort|pflegt|macht)|owner|verantwort|zuständig|takt|quelle|liefert/i },
    { id: 'belastbarkeit', label: 'Wie belastbar ist die Zahl?', needs: ['belastbarkeit.has'], keys: /belastbar|herkunft|dokumentiert|illustrativ|beispiel|erfunden|gesichert|quellensystem/i },
    { id: 'massnahme', label: 'Was machen wir dagegen?', needs: ['action.has'], keys: /massnahme|dagegen|ursache|was tun|eingeleitet/i },
    { id: 'abweichung_wo', label: 'Wie verteilt sich der Wert?', needs: ['splits.has'], keys: /wo (genau|liegt)|verteil|split|aufteilung|segment|welcher|welches|welche gesellschaft/i },
    { id: 'reifegrad', label: 'Wie weit ist die Kennzahl?', needs: ['maturity.has'], keys: /reifegrad|etabliert|auszuwerten|zu entwickeln|entwickelt|messbar/i },
    { id: 'bedeutung', label: 'Was misst diese Kennzahl?', needs: ['explain.has'], keys: /was misst|bedeutung|wofür|erklär|worum geht/i },
    { id: 'offen', label: 'Was ist noch offen?', needs: ['offen.has'], keys: /offen|tbd|ausstehend|noch nicht|fehlt|klärung/i }
  ];

  function factAt(facts, path) {
    return String(path).split('.').reduce((o, k) => (o == null ? undefined : o[k]), facts);
  }

  function answerable(facts, q) {
    return (q.needs || []).every(p => factAt(facts, p) === true);
  }

  function questions(facts) {
    return QUESTIONS.map(q => Object.assign({}, q, { answered: answerable(facts, q) }));
  }

  function suggestedQuestions(facts) {
    return questions(facts).filter(q => q.answered);
  }

  function missingQuestions(facts) {
    return questions(facts).filter(q => !q.answered);
  }

  function matchQuestion(facts, text) {
    const s = String(text == null ? '' : text).toLowerCase().replace(/ß/g, 'ss');
    if (!s.trim()) return null;
    for (const q of QUESTIONS) {
      if (q.keys.test(s)) return q.id;
    }
    return null;
  }

  /* Herkunftsstufen, gruppiert in der Reihenfolge der Antwort. */
  const LEVEL_GROUPS = [
    ['dokumentiert', 'Aus der Geschäftsstrategie'],
    ['annahme', 'Annahme, nicht aus der Strategie'],
    ['illustrativ', 'Beispielwerte'],
    ['interpoliert', 'Rechnerisch abgeleitet'],
    ['ausstehend', 'Noch offen']
  ];

  function provLines(prov) {
    return LEVEL_GROUPS
      .map(([level, title]) => {
        const labels = (prov || []).filter(p => p.level === level).map(p => p.label);
        return labels.length ? `${title}: ${labels.join(', ')}.` : null;
      })
      .filter(Boolean);
  }

  function anchorChain(anchors, u) {
    return anchors.map(a => `${val(a.value, u)} (${a.label})`).join(' → ');
  }

  function answer(facts, id) {
    const f = facts || {};
    const u = f.unit || '';

    switch (id) {
      case 'status': {
        const s = f.status || {};
        if (!s.perf) break;
        const lines = [`Status: **${s.label}**.`];
        if (s.guardrail) {
          if (has(f.ist && f.ist.value)) lines.push(`Aktueller Wert: ${val(f.ist.value, u)} (${f.ist.label || 'ohne Zeitangabe'}).`);
          lines.push('Geprüft wird gegen eine Untergrenze, nicht gegen einen Zielpfad.');
        } else if (s.ytd) {
          lines.push(`Bis ${s.ytd.period} sind ${val(s.ytd.actual, u)} erreicht. Laut Plan sollten es bis dahin ${val(s.ytd.target, u)} sein.`);
          lines.push(`Abweichung: ${s.verdict}.`);
          if (num(f.ist && f.ist.value)) lines.push(`Hochgerechnet auf das Gesamtjahr ergibt das ${val(f.ist.value, u, 1)}.`);
        } else {
          if (has(f.ist && f.ist.value)) lines.push(`Aktueller Wert: ${val(f.ist.value, u)} (${f.ist.label || 'ohne Zeitangabe'}).`);
          if (num(s.expected)) lines.push(`Laut Plan wären zu diesem Zeitpunkt ${val(s.expected, u)} zu erwarten.`);
          lines.push(`Verglichen wird mit dem Planwert für diesen Zeitpunkt, nicht mit dem Endziel. Abweichung: ${s.verdict}.`);
        }
        if (s.thresholds) lines.push(`Bewertung: ${s.thresholds}.`);
        return { ok: true, text: lines.join('\n') };
      }

      case 'ist': {
        const i = f.ist || {};
        const lines = [`Aktueller Wert: **${val(i.value, u)}**${i.label ? ` (${i.label})` : ''}.`];
        if (i.ytdText) lines.push(i.ytdText);
        if (i.periods) lines.push(`Bisher ${i.periods === 1 ? 'liegt 1 Messung' : `liegen ${i.periods} Messungen`} vor.`);
        if (i.entered) lines.push('Der Wert wurde im Board erfasst und ersetzt den hinterlegten Wert.');
        return { ok: true, text: lines.join('\n') };
      }

      case 'ziel': {
        const p = f.plan || {};
        const anchors = p.anchors || [];
        const lines = [];
        if (p.has) {
          lines.push(`Der Plan verbindet diese Eckwerte: ${anchorChain(anchors, u)}.`);
          lines.push('Dazwischen wird der Plan Quartal für Quartal gleichmäßig fortgeschrieben.');
          if (p.documented) lines.push(`Für ${p.documented} Quartale ist die Verteilung über das Jahr als Planannahme hinterlegt.`);
        } else {
          if (anchors.length === 1) lines.push(`Bisher gibt es nur den Ausgangswert ${anchorChain(anchors, u)}.`);
          lines.push('Für diese Kennzahl gibt es noch keinen Plan. Ein Plan braucht mindestens zwei Eckwerte: einen Ausgangswert und ein Ziel.');
          const t = [['Ziel 2028', p.target2028], ['Ziel 2031', p.target2031]]
            .filter(([, v]) => has(v) && v !== 'TBD');
          if (t.length) lines.push(`Laut Strategie: ${t.map(([k, v]) => `${k} ${v}`).join(', ')}.`);
        }
        if (p.note) lines.push(p.note);
        return { ok: true, text: lines.join('\n') };
      }

      case 'verlauf': {
        const s = f.series || {};
        if (s.cumulativeText) return { ok: true, text: s.cumulativeText };
        const lines = [`Es liegen ${s.count} Messungen vor, von ${s.from} bis ${s.to}.`];
        if (num(s.first) && num(s.last)) {
          lines.push(`Erster Wert: ${val(s.first, u)}. Letzter Wert: ${val(s.last, u)}. Veränderung: ${s.change}.`);
        }
        if (s.planLine) lines.push('Im Diagramm steht der Plan als gestrichelte Linie daneben.');
        if (s.gap) lines.push(s.gap);
        return { ok: true, text: lines.join('\n') };
      }

      case 'messung': {
        const m = f.messung || {};
        const lines = [];
        if (m.formula) lines.push(`Formel: ${m.formula}.`);
        if (m.type || m.detail) lines.push(`Erhebung: ${[m.type, m.detail].filter(Boolean).join(', ')}.`);
        if (m.thresholds) lines.push(`Bewertung: ${m.thresholds}.`);
        if (m.note) lines.push(m.note);
        return { ok: true, text: lines.join('\n') };
      }

      case 'verantwortlich': {
        const v = f.verantwortung || {};
        const lines = [];
        if (v.owner) lines.push(`Verantwortlich: ${v.owner}.`);
        if (v.cadence) lines.push(`Neue Werte: ${v.cadence}.`);
        if (v.source) lines.push(`Datenquelle: ${v.source}.`);
        if (v.steward) lines.push(`Pflege der Daten: ${v.steward}.`);
        return { ok: true, text: lines.join('\n') };
      }

      case 'belastbarkeit': {
        const b = f.belastbarkeit || {};
        const lines = provLines(b.prov);
        if (has(b.quality)) lines.push(`Erfasst: ${b.have} von ${b.expected} erwarteten Werten (${val(b.quality, '%', 0)}).`);
        if (b.lastUpdated) lines.push(`Zuletzt gepflegt: ${b.lastUpdated}${b.sourceSystem ? ` (${b.sourceSystem})` : ''}.`);
        if (!lines.length) break;
        return { ok: true, text: lines.join('\n') };
      }

      case 'massnahme': {
        const a = f.action || {};
        const lines = [];
        if (a.ursache) lines.push(`Warum es hakt: ${a.ursache}`);
        if (a.massnahme) lines.push(`Geplant ist: ${a.massnahme}`);
        lines.push(`Verantwortlich: ${a.owner || '—'}, Termin: ${a.frist || '—'}, Stand: ${a.status || 'offen'}.`);
        return { ok: true, text: lines.join('\n') };
      }

      case 'abweichung_wo': {
        const sp = f.splits || {};
        const lines = (sp.groups || []).map(g =>
          `Nach ${g.label}${g.stand ? ` (Stand ${g.stand})` : ''}: ${g.entries.map(e => `${e.name} ${val(e.value, u)}`).join(', ')}.`);
        return { ok: true, text: lines.join('\n') };
      }

      case 'reifegrad': {
        const r = f.maturity || {};
        const lines = [`Stand der Kennzahl: **${r.label}**. ${r.explain || ''}`.trim()];
        if (r.roadmap) lines.push(`Zeitplan: ${r.roadmap}.`);
        if (r.components && r.components.length) lines.push(`Bestandteile: ${r.components.join(', ')}.`);
        return { ok: true, text: lines.join('\n') };
      }

      case 'bedeutung': {
        const lines = [(f.explain && f.explain.text) || ''];
        if (f.messung && f.messung.formula) lines.push(`Formel: ${f.messung.formula}.`);
        return { ok: true, text: lines.filter(Boolean).join('\n') };
      }

      case 'offen': {
        const o = f.offen || {};
        const lines = [];
        if (o.methodik && o.methodik.length) lines.push(`Noch zu klären: ${o.methodik.join(', ')}.`);
        if (o.ausstehend && o.ausstehend.length) lines.push(`Noch nicht festgelegt: ${o.ausstehend.join(', ')}.`);
        if (!lines.length) break;
        return { ok: true, text: lines.join('\n') };
      }

      default:
        break;
    }
    return { ok: false, text: '' };
  }

  /* Antwort auf eine vorgeschlagene Frage (id) oder freien Text.
     Nicht beantwortbare Fragen nennen die fehlende Angabe; nicht
     zuordenbarer Text nennt, was sich beantworten lässt. */
  function answerText(facts, textOrId) {
    const direct = QUESTIONS.some(q => q.id === textOrId);
    const id = direct ? textOrId : matchQuestion(facts, textOrId);
    if (!id) {
      const open = suggestedQuestions(facts).map(q => q.label);
      return {
        ok: false,
        matched: null,
        text: open.length
          ? `Zu dieser Frage gibt es im Board keine Angaben. Beantworten lässt sich: ${open.join(' · ')}`
          : 'Zu dieser Frage gibt es im Board keine Angaben.'
      };
    }
    const q = QUESTIONS.find(x => x.id === id);
    const miss = {
      ok: false, matched: id,
      text: `Für diese Kennzahl fehlen die Angaben, um „${q.label}" zu beantworten.`
    };
    if (!answerable(facts, q)) return miss;
    const res = answer(facts, id);
    if (!res.ok) return miss;
    return Object.assign({ matched: id }, res);
  }

  /* Die Angaben zu einer Kennzahl als Text, z. B. für eine E-Mail. */
  function contextBlock(facts) {
    const f = facts || {};
    const u = f.unit || '';
    const L = [];
    L.push(`Kennzahl: ${f.name || f.id}`);
    L.push('');
    L.push(`- Einheit: ${u || '—'}`);
    if (f.lever) L.push(`- Einordnung: ${f.lever}${f.rowLabel ? ` · ${f.rowLabel}` : ''}`);
    if (f.status && f.status.perf) L.push(`- Status: ${f.status.label}${f.status.deviation ? ` (${f.status.deviation})` : ''}`);
    else if (f.maturity && f.maturity.label) L.push(`- Status: ${f.maturity.label}`);
    if (has(f.ist && f.ist.value)) L.push(`- Ist: ${val(f.ist.value, u)}${f.ist.label ? ` (${f.ist.label})` : ''}`);
    if (num(f.status && f.status.expected)) L.push(`- Planwert für diesen Zeitpunkt: ${val(f.status.expected, u)}`);
    if (f.plan) {
      if (f.plan.target2028) L.push(`- Ziel 2028: ${f.plan.target2028}`);
      if (f.plan.target2031) L.push(`- Ziel 2031: ${f.plan.target2031}`);
    }
    if (f.explain && f.explain.has && f.explain.text) L.push(`- Definition: ${f.explain.text}`);
    if (f.messung) {
      if (f.messung.formula) L.push(`- Formel: ${f.messung.formula}`);
      if (f.messung.detail || f.messung.type) L.push(`- Erhebung: ${[f.messung.type, f.messung.detail].filter(Boolean).join(', ')}`);
      if (f.messung.thresholds) L.push(`- Bewertung: ${f.messung.thresholds}`);
    }
    if (f.verantwortung) {
      if (f.verantwortung.owner) L.push(`- Verantwortlich: ${f.verantwortung.owner}`);
      if (f.verantwortung.cadence) L.push(`- Neue Werte: ${f.verantwortung.cadence}`);
      if (f.verantwortung.source) L.push(`- Datenquelle: ${f.verantwortung.source}`);
    }
    if (f.belastbarkeit) provLines(f.belastbarkeit.prov).forEach(l => L.push(`- ${l.replace(/\.$/, '')}`));
    if (f.series && f.series.has) L.push(`- Verlauf: ${f.series.count} Messungen, ${f.series.from} bis ${f.series.to}`);
    if (f.splits && f.splits.groups) {
      f.splits.groups.forEach(g => L.push(`- Aufteilung nach ${g.label}${g.stand ? ` (Stand ${g.stand})` : ''}: ${g.entries.map(e => `${e.name} ${val(e.value, u)}`).join(', ')}`));
    }
    if (f.action && f.action.has) {
      L.push(`- Ursache: ${f.action.ursache}`);
      L.push(`- Maßnahme: ${f.action.massnahme} (verantwortlich ${f.action.owner}, Termin ${f.action.frist}, Stand ${f.action.status || 'offen'})`);
    }
    if (f.offen) {
      if (f.offen.methodik && f.offen.methodik.length) L.push(`- Noch zu klären: ${f.offen.methodik.join(', ')}`);
      if (f.offen.ausstehend && f.offen.ausstehend.length) L.push(`- Noch nicht festgelegt: ${f.offen.ausstehend.join(', ')}`);
    }
    L.push('');
    L.push('Quelle: NÜRNBERGER KPI-Board (Prototyp mit Beispieldaten).');
    return L.join('\n');
  }

  root.KpiChat = {
    QUESTIONS,
    questions, suggestedQuestions, missingQuestions,
    matchQuestion, answer, answerText, contextBlock
  };
})(typeof window !== 'undefined' ? window : globalThis);
