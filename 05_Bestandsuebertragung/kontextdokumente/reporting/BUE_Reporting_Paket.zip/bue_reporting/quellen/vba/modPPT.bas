Option Explicit
' ============================================================================
' modPPT – Kacheln des Blatts "PPT" als Formen auf eine Folie der ERGO-Vorlage kopieren
' Ablauf: Diagramme aktualisieren, PowerPoint starten, Vorlage (Vorlage\ERGO_Vorlage.pptx neben der Master-Datei)
' als unbenannte Kopie oeffnen (sonst leere Praesentation), Folie mit Layout "Nur Überschrift" (oder "Only Title")
' anlegen, Titel und Untertitel aus PPT!BA1:BA2 (Untertitel in die Kopfzeile ueber dem Titel, falls das Layout eine
' hat), alle Formen des Blatts kopieren, als Gruppe einfuegen und unter dem Titel
' ausrichten, Schrift der Textfelder auf Arial, Gruppe wieder aufloesen, Kopie im Ordner "Praesentationen" sichern.
' ============================================================================

Private Const RAND_SEITE As Single = 41        ' Seitenrand der ERGO-Vorlage (Punkte)
Private Const INHALT_OBEN As Single = 108      ' Oberkante der Inhaltsflaeche unter dem Titel
Private Const RAND_UNTEN As Single = 22

Public Sub NachPowerPoint()
    If modLaden.LadenLaeuft() Then Exit Sub
    Dim app As Object, prs As Object, sld As Object, lay As Object, grp As Object, shp As Object
    Dim ws As Worksheet, vorlage As String, namen As Variant, i As Long, n As Long, basis As String, ziel As String
    Dim schritt As String
    Dim links As Single, oben As Single, breite As Single, hoehe As Single, faktor As Single

    Set ws = ThisWorkbook.Worksheets("PPT")
    schritt = "Vorbereitung"
    On Error Resume Next
    modCockpit.Aktualisieren
    On Error GoTo 0
    On Error GoTo Fehler
    basis = modLaden.BasisOrdner()                 ' bei OneDrive der lokale Ordner; Fehlermeldung kommt aus BasisOrdner
    If Len(basis) = 0 Or LCase$(Left$(basis, 4)) = "http" Then Err.Raise vbObjectError + 5, , "Der lokale Ordner der Master-Datei ist nicht bekannt (Konfiguration!B7)."

    On Error Resume Next
    Set app = GetObject(, "PowerPoint.Application")
    If app Is Nothing Then Set app = CreateObject("PowerPoint.Application")
    On Error GoTo 0
    If app Is Nothing Then
        modFortschritt.HinweisZeigen "Fehler", "PowerPoint konnte nicht gestartet werden.", True
        Exit Sub
    End If
    app.Visible = True

    On Error GoTo Fehler
    schritt = "Vorlage öffnen"
    vorlage = basis & Application.PathSeparator & "Vorlage" & Application.PathSeparator & "ERGO_Vorlage.pptx"
    If Len(Dir(vorlage)) > 0 Then
        Set prs = app.Presentations.Open(vorlage, False, True, True)     ' ReadOnly=False, Untitled=True (Kopie), WithWindow=True
    Else
        Set prs = app.Presentations.Add
    End If
    Set lay = Nothing
    For i = 1 To prs.SlideMaster.CustomLayouts.Count
        If LCase$(prs.SlideMaster.CustomLayouts(i).Name) = "only title" Then Set lay = prs.SlideMaster.CustomLayouts(i)
    Next i
    If lay Is Nothing Then
        For i = 1 To prs.SlideMaster.CustomLayouts.Count
            If InStr(1, LCase$(prs.SlideMaster.CustomLayouts(i).Name), "title only") > 0 Or InStr(1, LCase$(prs.SlideMaster.CustomLayouts(i).Name), "berschrift") > 0 Then Set lay = prs.SlideMaster.CustomLayouts(i)
        Next i
    End If
    If lay Is Nothing Then Set lay = prs.SlideMaster.CustomLayouts(1)
    schritt = "Folie anlegen"
    Set sld = prs.Slides.AddSlide(prs.Slides.Count + 1, lay)
    schritt = "Titel setzen"

    ' Titel und Untertitel in die Platzhalter (Datum, Fusszeile, Foliennummer der Vorlage bleiben unberuehrt)
    For Each shp In sld.Shapes
        If shp.Type = 14 Then                                         ' msoPlaceholder
            Select Case shp.PlaceholderFormat.Type
                Case 1, 3                                             ' ppPlaceholderTitle / ppPlaceholderCenterTitle
                    shp.TextFrame.TextRange.Text = CStr(ws.Range("BA1").Value)
                Case 2, 4                                             ' ppPlaceholderBody / ppPlaceholderSubtitle
                    shp.TextFrame.TextRange.Text = CStr(ws.Range("BA2").Value)
            End Select
        End If
    Next shp

    ' Formen des Blatts PPT kopieren und als Gruppe einfuegen
    schritt = "Formen kopieren"
    n = ws.Shapes.Count
    If n = 0 Then Err.Raise vbObjectError + 7, , "Im Blatt PPT liegen keine Formen."
    ReDim namen(1 To n)
    For i = 1 To n
        namen(i) = ws.Shapes(i).Name
    Next i
    On Error Resume Next
    ws.Shapes.Range(namen).Copy
    If Err.Number <> 0 Then                                           ' Ersatzweg: Blatt aktivieren, alle Formen markieren, kopieren
        Err.Clear
        Application.ScreenUpdating = False
        ws.Visible = xlSheetVisible
        ws.Activate
        ws.Shapes.SelectAll
        Selection.Copy
        ThisWorkbook.Worksheets("Cockpit").Activate
        Application.ScreenUpdating = True
    End If
    On Error GoTo Fehler
    DoEvents
    schritt = "In die Folie einfügen"
    On Error Resume Next
    Set grp = sld.Shapes.Paste                                        ' Formen bleiben bearbeitbar
    If grp Is Nothing Then Set grp = sld.Shapes.PasteSpecial(0)       ' ppPasteDefault
    On Error GoTo Fehler
    If grp Is Nothing Then Err.Raise vbObjectError + 8, , "PowerPoint hat die kopierten Formen nicht angenommen."
    DoEvents
    Application.CutCopyMode = False
    schritt = "Gruppieren und ausrichten"
    If grp.Count > 1 Then Set grp = grp.Group
    ' Unter dem Titel zentrieren; bei Bedarf auf die Inhaltsflaeche skalieren
    breite = prs.PageSetup.SlideWidth - 2 * RAND_SEITE
    hoehe = prs.PageSetup.SlideHeight - INHALT_OBEN - RAND_UNTEN
    faktor = 1
    If grp.Width > breite Then faktor = breite / grp.Width
    If grp.Height * faktor > hoehe Then faktor = hoehe / grp.Height
    If faktor < 1 Then
        grp.LockAspectRatio = False
        grp.Height = grp.Height * faktor
        grp.Width = grp.Width * faktor
    End If
    grp.Left = (prs.PageSetup.SlideWidth - grp.Width) / 2
    grp.Top = INHALT_OBEN
    schritt = "Diagramme bereinigen"
    On Error Resume Next
    For Each shp In grp.GroupItems
        If shp.HasChart Then
            EtikettenLeererPunkte shp.Chart                            ' #NV-Etiketten leerer Slots entfernen (PowerPoint zeigt sie sonst)
            shp.Chart.ChartData.BreakLink                             ' keine Verknuepfung zur Master-Datei in der Folie
        End If
    Next shp
    grp.Ungroup
    On Error GoTo Fehler
    ' Der Vertraulich-Vermerk kommt aus dem ERGO-Folienmaster, nichts zusaetzlich einfuegen

    ' Kopie sichern (PowerPoint bleibt mit der Praesentation offen)
    schritt = "Kopie sichern"
    ziel = basis & Application.PathSeparator & "Praesentationen"
    If Len(Dir(ziel, vbDirectory)) = 0 Then MkDir ziel
    ziel = ziel & Application.PathSeparator & "BUE_Reporting_" & Format(Date, "yyyymmdd") & "_" & Format(Time, "hhnn") & ".pptx"
    prs.SaveCopyAs ziel
    app.Activate
    modFortschritt.HinweisZeigen "Hinweis", "Folie erzeugt und gesichert:" & vbCrLf & ziel, False
    Exit Sub

Fehler:
    Dim fehlertext As String
    fehlertext = "Fehler " & Err.Number & ": " & Err.Description
    modFortschritt.HinweisZeigen "Fehler", "PowerPoint-Export fehlgeschlagen bei Schritt '" & schritt & "': " & fehlertext, True
End Sub

' Etiketten von Punkten ohne Wert (#NV) abschalten: Excel blendet sie aus, PowerPoint schreibt "#NV"
Private Sub EtikettenLeererPunkte(ch As Object)
    Dim s As Object, v As Variant, i As Long
    On Error Resume Next
    For Each s In ch.SeriesCollection
        If s.HasDataLabels Then
            v = s.Values
            For i = LBound(v) To UBound(v)
                If IsError(v(i)) Or IsEmpty(v(i)) Then s.Points(i).HasDataLabel = False
            Next i
        End If
    Next s
    On Error GoTo 0
End Sub

Public Function PPTModulVersion() As String
    PPTModulVersion = "3"
End Function
