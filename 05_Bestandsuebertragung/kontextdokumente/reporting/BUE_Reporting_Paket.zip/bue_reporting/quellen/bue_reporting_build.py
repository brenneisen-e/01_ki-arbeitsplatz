# -*- coding: utf-8 -*-
"""Baut die Master-Datei BUE_Reporting_Master.xlsm (Cockpit, Verlauf, KW, Fakten, Filter, Anwesenheit,
Konfiguration, Ladeprotokoll, Snapshots) samt VBA-Projekt und befuellt sie mit den vorhandenen Rohdaten.

Aufruf (aus diesem Ordner):  python3 bue_reporting_build.py
Voraussetzung: Rohdaten in ../Rohdaten (je Datei ein oder mehrere Blaetter mit Rueckstandsabzug),
Anwesenheitsliste in ../Anwesenheit. Beide Ordner legt vorbereiten() aus den Upload-Dateien an, wenn sie fehlen.
"""
import datetime as dt
import os
import re
import math
import shutil
import sys
import zipfile

import xlsxwriter
from xlsxwriter.utility import xl_rowcol_to_cell, xl_col_to_name

HIER = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HIER)
import verarbeitung as v  # noqa: E402
import ovba  # noqa: E402

BASIS = os.path.dirname(HIER)
ROH = os.path.join(BASIS, 'Rohdaten')
ANW = os.path.join(BASIS, 'Anwesenheit')
OUT = os.path.join(BASIS, 'BUE_Reporting_Master.xlsm')            # leere Master-Datei (Daten kommen per Makro)
OUT_DEMO = os.path.join(BASIS, 'BUE_Reporting_Demo_befuellt.xlsm')  # dieselbe Datei, mit den Rohdaten aus dem Ordner vorbefuellt
GEVO_STANDARD = ['39 Telefonnotiz', '40 sonstige Korrespondenz', '67 Anfrage z. Vertragsumf.', '108 Bestandsübertragung', '131 Ablaufkündigung',
                 '401 Maklervertrag', '413 Kopien von Unterlagen', '469 Bestandsübertragung', '472 sonstiger Schriftwechsel', '703 Rechte Dritter',
                 '803 Eigentümer/Halter/Nutzung', '2015 Maklervollmacht', '6065 Anfrage Betreuung']   # Chips der leeren Master-Datei
UPLOADS = '/root/.claude/uploads/f661452e-e109-5f2a-a280-eeeab59cad16'
JAHR_ANWESENHEIT = 2026

# ------------------------------------------------------------------ Gestaltung
FONT = 'Aptos'
ROT, ROTD, ROTL = '#BF1528', '#8E0F1E', '#FBE9EB'
TEAL, TEALD, TEAL2, TEALL, TEALT = '#0F94A7', '#0B6F7D', '#47BCC5', '#CCEBED', '#EEF6F7'
INDIGO = '#3B4F8A'
SW, GRAUD, GRAU, GRAUM, GRAUL, GRAUXL, WEISS = '#1A1A1A', '#4A4A4A', '#6B6B6B', '#9AA3AD', '#D0D5DA', '#F3F4F6', '#FFFFFF'
GRUEN = '#1E7F4F'
GRUENH, GELBH, GELBD = '#DDF3E4', '#FBEFC7', '#8A5A00'     # Badges: weniger (hellgruen), mehr (hellgelb), Schrift gelb
FARBE_SPARTE = {'KV': ROT, 'Komposit': TEAL, 'Leben': INDIGO, 'Sonstige': GRAUM}
FARBE_ALTER = ['#CCEBED', '#7FCBD4', '#0F94A7', '#0B6F7D']
FARBE_SPARTE_HELL = {'KV': '#E8919B', 'Komposit': '#7FCBD4', 'Leben': '#9AA6CC', 'Sonstige': '#C9CED4'}   # Abgaenge: hellerer Ton derselben Sparte

MAX_FAKTEN = 300000
PK_VON, PK_BIS = 5, 44          # Filter!B5:B44: Themenpostkoerbe (40 Plaetze)
POSTKOERBE_AKTIV = ['KO 23724', 'MV 23724', 'GR 23724']     # bekannte Themenpostkoerbe der Sachbearbeitung (HSB4K KO, MV, GR)
MAX_VERLAUF = 1000


# ------------------------------------------------------------------ Rohdaten vorbereiten
def vorbereiten():
    """Zerlegt die Sammeldatei in Tagesdateien je Quelle (so wie sie kuenftig einzeln kommen) und legt die Anwesenheit ab."""
    import openpyxl
    os.makedirs(ROH, exist_ok=True)
    os.makedirs(ANW, exist_ok=True)
    quelle = os.path.join(UPLOADS, '6ed28fbb-20260924_R_ckst_nde_HSB4K_OPAG_Verbund.xlsx')
    if os.path.exists(quelle) and not [f for f in os.listdir(ROH) if f.endswith('.xlsx')]:
        wb = openpyxl.load_workbook(quelle, read_only=True, data_only=True)
        for ws in wb.worksheets:
            zeilen = [list(r) for r in ws.iter_rows(values_only=True)]
            erg = v.blatt_lesen(zeilen)
            if not erg:
                continue
            stichtag, q, _ = erg
            neu = openpyxl.Workbook()
            wsn = neu.active
            wsn.title = q
            for z in zeilen:
                wsn.append(z)
            name = '%s_Rueckstand_%s_HSB4K.xlsx' % (stichtag.strftime('%Y%m%d'), q)
            neu.save(os.path.join(ROH, name))
            print('Rohdatei angelegt:', name)
        wb.close()
    anw = os.path.join(UPLOADS, '703923bc-HSB_4_K_incl._RD_Kollegen_Anwensenheit_bis_Oktober_2026.xlsx')
    ziel = os.path.join(ANW, 'HSB4K_Anwesenheit_bis_Oktober_2026.xlsx')
    if os.path.exists(anw) and not os.path.exists(ziel):
        shutil.copy(anw, ziel)
        print('Anwesenheitsliste abgelegt:', os.path.basename(ziel))


# ------------------------------------------------------------------ Vorbefuellung
def vorbefuellen():
    staende = []
    for f in sorted(os.listdir(ROH)):
        if f.lower().endswith(('.xlsx', '.xlsm')) and not f.startswith('~$'):
            staende += v.blaetter_aus_datei(os.path.join(ROH, f))
    staende.sort(key=lambda s: (s[2], s[3]))
    snap = {'OPAG': None, 'Verbund': None}
    snap_datum = {'OPAG': None, 'Verbund': None}
    fakten, protokoll, stichtage = [], [], []
    for pfad, blatt, stichtag, quelle, saetze in staende:
        f, neu, k = v.verarbeiten(stichtag, quelle, saetze, snap[quelle])
        erster = snap[quelle] is None
        snap[quelle], snap_datum[quelle] = neu, stichtag
        fakten += f
        if stichtag not in stichtage:
            stichtage.append(stichtag)
        protokoll.append((dt.datetime.now(), os.path.basename(pfad), blatt, quelle, stichtag, k['zeilen'], k['rueckstand'],
                          0 if erster else k['eingang'], 0 if erster else k['abgang'],
                          'erster Stand dieser Quelle – Eingänge und Abgänge ab dem nächsten Stichtag' if erster else ''))
    stichtage.sort()
    anwesenheit = []
    for f in sorted(os.listdir(ANW)):
        if f.lower().endswith('.xlsx') and not f.startswith('~$'):
            anwesenheit = v.anwesenheit_lesen(os.path.join(ANW, f), JAHR_ANWESENHEIT)
            anw_datei = f
    return fakten, snap, snap_datum, protokoll, stichtage, anwesenheit, (anw_datei if anwesenheit else '')


# ------------------------------------------------------------------ Hilfen
class Stil:
    def __init__(self, wb):
        self.wb = wb
        b = {'font_name': FONT, 'font_size': 10, 'font_color': SW, 'valign': 'vcenter'}
        f = lambda **k: wb.add_format({**b, **k})  # noqa: E731
        self.basis = f()
        self.titel = f(font_size=20, bold=True, font_color=SW)
        self.titel_rot = f(font_size=20, bold=True, font_color=ROT)
        self.untertitel = f(font_size=9, font_color=GRAU)
        self.abschnitt = f(font_size=11, bold=True, font_color=SW)
        self.abschnitt_klein = f(font_size=8, bold=True, font_color=GRAU)
        self.hinweis = f(font_size=8, font_color=GRAU, italic=True, text_wrap=True, valign='top')
        self.kopf = f(bold=True, font_color=WEISS, bg_color=GRAUD, border=0, text_wrap=True, valign='vcenter')
        self.kopf_rot = f(bold=True, font_color=WEISS, bg_color=ROT, text_wrap=True)
        self.kopf_hell = f(bold=True, font_color=GRAUD, bg_color=GRAUXL, bottom=1, bottom_color=GRAUL, text_wrap=True)
        self.zelle = f(font_size=9)
        self.zelle_zahl = f(font_size=9, num_format='#,##0')
        self.zelle_dez = f(font_size=9, num_format='#,##0.0')
        self.zelle_dat = f(font_size=9, num_format='dd.mm.yyyy')
        self.zelle_datzeit = f(font_size=9, num_format='dd.mm.yyyy hh:mm')
        self.zelle_bool = f(font_size=9, align='center')
        self.eingabe = f(font_size=10, font_color='#0000FF', bg_color='#FFF9DB', border=1, border_color=GRAUL)
        self.kpi_label = f(font_size=8, bold=True, font_color=GRAU, bg_color=GRAUXL, valign='bottom', indent=1)
        self.kpi_wert = f(font_size=24, bold=True, font_color=SW, bg_color=GRAUXL, num_format='#,##0', valign='vcenter', align='left', indent=1)
        self.kpi_wert_dez = f(font_size=24, bold=True, font_color=SW, bg_color=GRAUXL, num_format='#,##0.0', valign='vcenter', align='left', indent=1)
        self.kpi_sub = f(font_size=8, font_color=GRAU, bg_color=GRAUXL, valign='top', num_format='+#,##0;-#,##0;±0')
        self.kpi_sub_text = f(font_size=8, font_color=GRAU, bg_color=GRAUXL, valign='vcenter', indent=1)
        self.kpi_fill = f(bg_color=GRAUXL)
        self.chart_titel = f(font_size=11, bold=True, font_color=SW)
        self.chart_sub = f(font_size=8, font_color=GRAU)
        self.filter_kopf = f(font_size=8, bold=True, font_color=GRAU, top=1, top_color=GRAUL)
        self.datum_gross = f(font_size=11, bold=True, font_color=SW, num_format='dd.mm.yyyy', align='right')
        self.rechts_grau = f(font_size=9, font_color=GRAU, align='right')
        self.dropdown = f(font_size=9, bold=True, font_color=TEALD, bg_color=TEALT, border=1, border_color=TEALL)


SEGMENT_LABEL = lambda fmt='#,##0;#,##0;': {'value': True, 'position': 'center', 'num_format': fmt, 'font': {'name': FONT, 'size': 8, 'color': WEISS, 'bold': True}}  # noqa: E731


def thinkcell(ch):
    """Gestapelte Diagramme wie in think-cell: Werte in den Segmenten, Summe ueber dem Stapel, keine Wertachse, keine Gitterlinien."""
    ch.set_y_axis({'visible': False, 'major_gridlines': {'visible': False}})


def chart_stil(ch, y_format='#,##0', legende='top', hoehe=270, breite=560, x_date=False, x_font=8):
    ch.set_chartarea({'border': {'none': True}, 'fill': {'color': WEISS}})
    ch.set_plotarea({'border': {'none': True}, 'fill': {'none': True}})
    ch.set_title({'none': True})
    if legende:
        ch.set_legend({'position': legende, 'font': {'name': FONT, 'size': 8, 'color': GRAUD}})
    else:
        ch.set_legend({'none': True})
    x = {'num_font': {'name': FONT, 'size': x_font, 'color': GRAU}, 'line': {'color': GRAUL, 'width': 0.75},
         'major_gridlines': {'visible': False}, 'major_tick_mark': 'none', 'minor_tick_mark': 'none'}
    if x_date:
        x.update({'date_axis': True, 'num_format': 'dd.mm.'})
    ch.set_x_axis(x)
    ch.set_y_axis({'num_font': {'name': FONT, 'size': 8, 'color': GRAU}, 'num_format': y_format, 'line': {'none': True},
                   'major_gridlines': {'visible': True, 'line': {'color': GRAUXL, 'width': 0.75}}, 'major_tick_mark': 'none'})
    ch.set_size({'width': breite, 'height': hoehe})
    ch.show_blanks_as('gap')


# ------------------------------------------------------------------ Bau
def bauen(vba_bin, leer=False):
    vorbereiten()
    fakten, snap, snap_datum, protokoll, stichtage, anwesenheit, anw_datei = vorbefuellen()
    if leer:                                   # leere Master-Datei: keine Fakten, kein Verlauf, keine Snapshots, keine Anwesenheit
        fakten, protokoll, stichtage, anwesenheit, anw_datei = [], [], [], [], ''
        snap = {'OPAG': None, 'Verbund': None}
    GEOMETRIE.clear()
    print('Fakten:', len(fakten), 'Stichtage:', stichtage, 'Anwesenheit:', len(anwesenheit))

    # Listen fuer die Filter aus den Daten
    import collections
    pk_z = collections.Counter()
    typ_z = collections.Counter()
    for z in fakten:
        if z[1] == 'Verbund':
            pk_z[z[4]] += z[8]
            typ_z[z[6]] += z[8]
    postkoerbe = [p for p, _ in pk_z.most_common()]
    for p in ['KO 23724', 'MV 23724', 'BE 23724', 'WR 23724', 'BÜ 23724', '72 23724', 'GR 23724', '00 23724', v.OHNE_POSTKORB]:
        if p not in postkoerbe:
            postkoerbe.append(p)
    postkoerbe = postkoerbe[:PK_BIS - PK_VON + 1]
    gevo_typen = sorted([t for t, _ in typ_z.most_common(13)], key=lambda t: (v.gevo_typ(t)[1], t)) or list(GEVO_STANDARD)

    wb = xlsxwriter.Workbook(OUT, {'use_future_functions': True})
    wb.formats[0].set_font_name(FONT)
    wb.formats[0].set_font_size(10)
    wb.set_vba_name('ThisWorkbook')
    wb.add_vba_project(vba_bin)
    st = Stil(wb)

    ws_c = wb.add_worksheet('Cockpit')
    ws_ppt = wb.add_worksheet('PPT')
    ws_an = wb.add_worksheet('Anleitung')
    ws_p = wb.add_worksheet('Planung')
    ws_m = wb.add_worksheet('Mitarbeiter')
    ws_v = wb.add_worksheet('Verlauf')
    ws_k = wb.add_worksheet('KW')
    ws_f = wb.add_worksheet('Fakten')
    ws_fi = wb.add_worksheet('Filter')
    ws_ko = wb.add_worksheet('Konfiguration')
    ws_l = wb.add_worksheet('Ladeprotokoll')
    ws_d = wb.add_worksheet('Diagrammdaten')
    ws_w = wb.add_worksheet('Wirksam')
    ws_so = wb.add_worksheet('Snapshot_OPAG')
    ws_sv = wb.add_worksheet('Snapshot_Verbund')
    for w in (ws_c, ws_ppt, ws_an, ws_p, ws_m, ws_v, ws_k, ws_f, ws_fi, ws_ko, ws_l, ws_d, ws_w, ws_so, ws_sv):
        w.hide_gridlines(2)
        w.set_default_row(15)
    ws_so.hide()
    ws_sv.hide()
    ws_w.hide()
    CHART_ZAEHLER[0] = 0

    # ---------------------------------------------------------- Namen fuer die Faktenspalten
    def name(n, ref):
        wb.define_name(n, ref)
    spalten_f = {'F_Stichtag': 'A', 'F_Quelle': 'B', 'F_Sparte': 'C', 'F_Postkorb': 'E', 'F_GevoTyp': 'G', 'F_GevoNr': 'H',
                 'F_Rueckstand': 'I', 'F_Eingang': 'J', 'F_Abgang': 'K', 'F_A0': 'L', 'F_A1': 'M', 'F_A2': 'N', 'F_A3': 'O', 'F_Aktiv': 'P'}
    for n, c in spalten_f.items():
        name(n, '=Fakten!$%s$2:$%s$%d' % (c, c, MAX_FAKTEN))
    # Filterlisten als Namen (Themenpostkoerbe Filter!B5:B44, GeVo-Typen Filter!G5:G17)
    name('PK_Liste', '=Filter!$B$%d:$B$%d' % (PK_VON, PK_BIS))
    name('PK_Aktiv', '=Filter!$C$%d:$C$%d' % (PK_VON, PK_BIS))
    name('GV_Liste', '=Filter!$G$5:$G$17')
    name('GV_Aktiv', '=Filter!$H$5:$H$17')
    name('SP_Liste', '=Filter!$S$5:$S$8')
    name('SP_Aktiv', '=Filter!$T$5:$T$8')

    def block(nm, erste, letzte):
        # Teilbereich eines F_*-Namens (nur die Fakten-Zeilen eines Stichtags): INDEX:INDEX ist nicht fluechtig
        return 'INDEX(%s,%s):INDEX(%s,%s)' % (nm, erste, nm, letzte)

    # ---------------------------------------------------------- Konfiguration
    ws_ko.set_column('A:A', 30)
    ws_ko.set_column('B:B', 42)
    ws_ko.set_column('C:C', 3)
    ws_ko.set_column('D:D', 26)
    ws_ko.set_column('E:E', 3)
    ws_ko.set_column('F:F', 40)
    ws_ko.write('A1', 'Konfiguration', st.titel)
    ws_ko.write('A2', 'Gelbe Zellen mit blauer Schrift sind Eingabezellen. Alles andere wird vom Bericht gepflegt.', st.untertitel)
    ws_ko.write('A3', 'Rohdaten-Ordner (relativ zur Master-Datei oder absolut)', st.zelle)
    ws_ko.write('B3', 'Rohdaten', st.eingabe)
    ws_ko.write('A4', 'Ordner der Anwesenheitsliste', st.zelle)
    ws_ko.write('B4', 'Anwesenheit', st.eingabe)
    ws_ko.write('A5', 'Jahr der Anwesenheitsliste', st.zelle)
    ws_ko.write('B5', JAHR_ANWESENHEIT, st.eingabe)
    ws_ko.write('A6', 'Produktivität wird je Vorgang (Verbund) und je Arbeitsgut (OPAG) ausgewiesen; beide Sichten stehen im Blatt KW und im Cockpit.', st.hinweis)
    ws_ko.write('A7', 'Lokaler Ordner der Master-Datei (nur nötig, wenn die Datei in OneDrive/SharePoint liegt und die automatische Zuordnung scheitert; sonst leer)', st.zelle)
    ws_ko.write('B7', '', st.eingabe)
    ws_ko.write('A8', 'Hover-Effekt der Chips im Cockpit (JA/NEIN; NEIN, falls Excel beim Überfahren der Chips instabil wird – Klick funktioniert weiter)', st.zelle)
    ws_ko.write('B8', 'JA', st.eingabe)
    ws_ko.data_validation('B8', {'validate': 'list', 'source': ['JA', 'NEIN']})
    ws_ko.write('A9', 'Meldungen als Karte im Blatt (JA/NEIN; NEIN = klassisches Windows-Fenster, falls Excel beim Anzeigen der Karte instabil wird)', st.zelle)
    ws_ko.write('B9', 'JA', st.eingabe)
    ws_ko.data_validation('B9', {'validate': 'list', 'source': ['JA', 'NEIN']})
    ws_ko.write('A10', 'Verwaltungssystemschlüssel', st.kopf)
    ws_ko.write('B10', 'Sparte (Komposit, Leben, KV)', st.kopf)
    r = 10
    for vss, sp in v.SPARTE_STANDARD.items():
        ws_ko.write(r, 0, vss, st.zelle)
        ws_ko.write(r, 1, sp, st.eingabe)
        r += 1
    ws_ko.write(r + 1, 0, 'Unbekannte Schlüssel laufen unter „Sonstige“. Zeilen 11–40 werden beim Laden gelesen.', st.hinweis)
    ws_ko.write('D10', 'BÜ-Schlüssel (GeVo-Nummer)', st.kopf)
    for i, nr in enumerate([108, 469, 2015, 6065]):
        ws_ko.write(10 + i, 3, nr, st.eingabe)
    ws_ko.write('D16', 'Grundlage: Fachkonzept BÜ-Reporting, bestätigt: Komposit/Leben 469 und 108, KV 2015 und 6065. Zeilen 11–20 werden gelesen.', st.hinweis)
    ws_ko.write('F10', 'Vorauswahl „Aktive Bearbeitung“ (Themenpostkörbe)', st.kopf)
    for i, p in enumerate(POSTKOERBE_AKTIV):
        ws_ko.write(10 + i, 5, p, st.eingabe)
    ws_ko.write('F16', 'Postkörbe, in denen die Sachbearbeitung selbst arbeitet (HSB4K KO, MV, GR). 72 (72-Stunden-BOT) und BÜ (Prüf-Bot) zählen nicht dazu; BE, WR, 00 und „ohne Postkorb“ sind fachlich zu klären. Zeilen 11–30 werden gelesen.', st.hinweis)
    ws_ko.write('A26', 'Altersklassen des Rückstands (Tage seit Eingang)', st.abschnitt)
    for i, t in enumerate(['0–7 Tage', '8–30 Tage', '31–90 Tage', 'über 90 Tage']):
        ws_ko.write(26 + i, 0, t, st.zelle)
    ws_ko.write('A31', 'Eingänge = Schlüssel, die im neuen Stand erstmals vorkommen. Abgänge = Schlüssel des Vortagsstands, die im neuen Stand fehlen '
                       '(abgearbeitet oder an die Sparte weitergeleitet, auch Übergabe an den 72-Stunden-BOT). Schlüssel Verbund: Verwaltungssystemschlüssel, '
                       'Ordnungsbegriff, VORG_VERBU_LNR; OPAG zusätzlich OPS_AUFTR_ID und OPS_ARBGUT_LNR.', st.hinweis)
    ws_ko.set_row(30, 48)
    name('SparteZuordnung', '=Konfiguration!$A$11:$B$40')
    name('BUESchluessel', '=Konfiguration!$D$11:$D$20')
    name('PresetAktiv', '=Konfiguration!$F$11:$F$30')

    # ---------------------------------------------------------- Fakten
    kopf_f = ['Stichtag', 'Quelle', 'Sparte', 'VSS', 'Themenpostkorb', 'GEVO_SL', 'GeVo-Typ', 'GeVo-Nr', 'Rückstand', 'Eingang', 'Abgang',
              'Alter 0–7', 'Alter 8–30', 'Alter 31–90', 'Alter >90', 'Aktiv']
    for c, t in enumerate(kopf_f):
        ws_f.write(0, c, t, st.kopf)
    ws_f.set_row(0, 30)
    ws_f.set_column('A:A', 11, st.zelle_dat)
    ws_f.set_column('B:D', 9, st.zelle)
    ws_f.set_column('E:E', 15, st.zelle)
    ws_f.set_column('F:G', 30, st.zelle)
    ws_f.set_column('H:O', 9, st.zelle_zahl)
    ws_f.set_column('P:P', 9, st.zelle_zahl)
    ws_f.freeze_panes(1, 0)

    def fakten_formeln(r):
        # eine Formel je Zeile: 1 = Zeile zaehlt (Postkorb im Filter und GeVo-Typ im Filter); unbekannte Postkoerbe zaehlen
        z = r + 1
        ws_f.write_formula(r, 15, '=IF(AND(IFERROR(INDEX(SP_Aktiv,MATCH(C%d,SP_Liste,0)),TRUE),IFERROR(INDEX(PK_Aktiv,MATCH(E%d,PK_Liste,0)),TRUE),'
                                  'IF(Filter!$L$5="Alle GeVo",TRUE,IF(Filter!$L$5="Nur BÜ-Schlüssel",ISNUMBER(MATCH(H%d,BUESchluessel,0)),'
                                  'IFERROR(INDEX(GV_Aktiv,MATCH(G%d,GV_Liste,0)),Filter!$H$18)))),1,0)' % (z, z, z, z), st.zelle_zahl)
    for i, z in enumerate(fakten):
        r = i + 1
        ws_f.write_datetime(r, 0, dt.datetime(z[0].year, z[0].month, z[0].day), st.zelle_dat)
        for c in range(1, 8):
            ws_f.write(r, c, z[c], st.zelle if c < 7 else st.zelle_zahl)
        for c in range(8, 15):
            ws_f.write_number(r, c, z[c], st.zelle_zahl)
        fakten_formeln(r)
    if not fakten:
        fakten_formeln(1)
    ws_f.autofilter(0, 0, max(1, len(fakten)), 15)

    # ---------------------------------------------------------- Filter
    ws_fi.set_column('A:A', 2)
    ws_fi.set_column('B:B', 20)
    ws_fi.set_column('C:C', 8)
    ws_fi.set_column('D:E', 13)
    ws_fi.set_column('F:F', 2)
    ws_fi.set_column('G:G', 30)
    ws_fi.set_column('H:I', 9)
    ws_fi.set_column('J:J', 13)
    ws_fi.set_column('K:K', 2)
    ws_fi.set_column('L:L', 18)
    ws_fi.set_column('M:M', 2)
    ws_fi.set_column('N:Q', 14)
    ws_fi.set_column('R:R', 2)
    ws_fi.set_column('S:S', 12)
    ws_fi.set_column('T:T', 8)
    ws_fi.write('B1', 'Filter und Hilfsgrößen', st.titel)
    ws_fi.write('B2', 'Die Chips im Cockpit schreiben WAHR/FALSCH in die Spalten C (Themenpostkörbe), H (GeVo-Typen) und T (Sparten). Die Spalten lassen sich auch direkt bearbeiten.', st.untertitel)
    ws_fi.write('S4', 'Sparte', st.kopf)
    ws_fi.write('T4', 'Aktiv', st.kopf)
    for i, sp in enumerate(['Komposit', 'Leben', 'KV', 'Sonstige']):
        ws_fi.write(4 + i, 18, sp, st.zelle)
        ws_fi.write_boolean(4 + i, 19, True, st.zelle_bool)
    for c, t in enumerate(['Themenpostkorb', 'Aktiv', 'Rückstand Verbund', 'Rückstand OPAG']):
        ws_fi.write(3, 1 + c, t, st.kopf)
    bl = lambda nm: block(nm, '$O$22', '$O$23')     # Fakten-Zeilen des letzten Stichtags  # noqa: E731
    for i in range(PK_BIS - PK_VON + 1):
        r = PK_VON - 1 + i
        if i < len(postkoerbe):
            ws_fi.write(r, 1, postkoerbe[i], st.zelle)
            ws_fi.write_boolean(r, 2, postkoerbe[i] in POSTKOERBE_AKTIV, st.zelle_bool)
        ws_fi.write_formula(r, 3, '=IF(B%d="","",SUMIFS(%s,%s,$N$5,%s,"Verbund",%s,B%d))' % (r + 1, bl('F_Rueckstand'), bl('F_Stichtag'), bl('F_Quelle'), bl('F_Postkorb'), r + 1), st.zelle_zahl)
        ws_fi.write_formula(r, 4, '=IF(B%d="","",SUMIFS(%s,%s,$N$5,%s,"OPAG",%s,B%d))' % (r + 1, bl('F_Rueckstand'), bl('F_Stichtag'), bl('F_Quelle'), bl('F_Postkorb'), r + 1), st.zelle_zahl)
    for c, t in enumerate(['GeVo-Typ', 'Kästchen', 'wirksam', 'Rückstand Verbund']):
        ws_fi.write(3, 6 + c, t, st.kopf)
    for i in range(13):
        r = 4 + i
        if i < len(gevo_typen):
            ws_fi.write(r, 6, gevo_typen[i], st.zelle)
        ws_fi.write_boolean(r, 7, True, st.zelle_bool)
        ws_fi.write_formula(r, 8, '=IF($L$5="Alle GeVo",TRUE,IF($L$5="Nur BÜ-Schlüssel",ISNUMBER(MATCH(IFERROR(VALUE(LEFT(G%d,FIND(" ",G%d&" ")-1)),-1),BUESchluessel,0)),H%d))' % (r + 1, r + 1, r + 1), st.zelle_bool)
        ws_fi.write_formula(r, 9, '=IF(G%d="","",SUMIFS(%s,%s,$N$5,%s,"Verbund",%s,G%d))' % (r + 1, bl('F_Rueckstand'), bl('F_Stichtag'), bl('F_Quelle'), bl('F_GevoTyp'), r + 1), st.zelle_zahl)
    ws_fi.write('G18', 'Alle übrigen GeVo-Typen', st.zelle)
    ws_fi.write_boolean('H18', True, st.zelle_bool)
    ws_fi.write_formula('I18', '=IF($L$5="Alle GeVo",TRUE,IF($L$5="Nur BÜ-Schlüssel",FALSE,H18))', st.zelle_bool)
    ws_fi.write_formula('J18', '=SUMIFS(%s,%s,$N$5,%s,"Verbund")-SUM(J5:J17)' % (bl('F_Rueckstand'), bl('F_Stichtag'), bl('F_Quelle')), st.zelle_zahl)
    ws_fi.write('L4', 'GeVo-Modus', st.kopf)
    ws_fi.write('L5', 'Alle GeVo', st.dropdown)
    ws_fi.data_validation('L5', {'validate': 'list', 'source': ['Alle GeVo', 'Nur BÜ-Schlüssel', 'Manuelle Auswahl']})
    ws_fi.write('L7', 'Alle GeVo: kein GeVo-Filter. Nur BÜ-Schlüssel: GeVo-Nummern aus Konfiguration. Manuelle Auswahl: Kästchen im Cockpit.', st.hinweis)
    ws_fi.set_row(6, 60)
    # Hilfsgroessen
    ws_fi.write('L8', 'Ansicht', st.kopf)
    ws_fi.write('L9', 'Tag', st.dropdown)
    ws_fi.data_validation('L9', {'validate': 'list', 'source': ['Tag', 'Woche']})
    ws_fi.write('L11', 'Tag = letzte 7 Stichtage, Woche = letzte 7 Kalenderwochen (Rückstand zum Wochenende, Bewegungen als Wochensumme).', st.hinweis)
    ws_fi.set_row(10, 48)
    ws_fi.write('Q1', 0, st.zelle_zahl)
    ws_fi.write('R1', 'Chip unter dem Mauszeiger (Cockpit, Hover)', st.zelle)
    ws_fi.write('N4', 'Hilfsgrößen', st.kopf)
    ws_fi.write('O4', 'Wert', st.kopf)
    ws_fi.write('N5', 'Letzter Stichtag', st.zelle)
    ws_fi.write_formula('O5', '=IF(COUNT(Verlauf!$A$6:$A$%d)=0,"",MAX(Verlauf!$A$6:$A$%d))' % (MAX_VERLAUF, MAX_VERLAUF), st.zelle_dat)
    ws_fi.write_formula('N5', '=O5', st.zelle_dat)
    ws_fi.write('N6', 'Vorheriger Stichtag', st.zelle)
    ws_fi.write_formula('O6', '=IF(COUNT(Verlauf!$A$6:$A$%d)<2,"",LARGE(Verlauf!$A$6:$A$%d,2))' % (MAX_VERLAUF, MAX_VERLAUF), st.zelle_dat)
    ws_fi.write('N7', 'Zeile letzter Stichtag', st.zelle)
    ws_fi.write_formula('O7', '=IFERROR(MATCH(O5,Verlauf!$A$6:$A$%d,0),0)' % MAX_VERLAUF, st.zelle_zahl)
    ws_fi.write('N8', 'Zeile vorheriger Stichtag', st.zelle)
    ws_fi.write_formula('O8', '=IFERROR(MATCH(O6,Verlauf!$A$6:$A$%d,0),0)' % MAX_VERLAUF, st.zelle_zahl)
    ws_fi.write('N9', 'Jahr (ISO) letzter Stichtag', st.zelle)
    ws_fi.write_formula('O9', '=IF(O7=0,"",INDEX(Verlauf!$B$6:$B$%d,O7))' % MAX_VERLAUF, st.zelle_zahl)
    ws_fi.write('N10', 'KW letzter Stichtag', st.zelle)
    ws_fi.write_formula('O10', '=IF(O7=0,"",INDEX(Verlauf!$C$6:$C$%d,O7))' % MAX_VERLAUF, st.zelle_zahl)
    ws_fi.write('N11', 'Zeile in KW', st.zelle)
    ws_fi.write_formula('O11', '=IFERROR(MATCH(O9*100+O10,KW!$W$6:$W$400,0),0)', st.zelle_zahl)
    ws_fi.write('N19', 'Δ Rückstand OPAG ggü. Vortag', st.zelle)
    ws_fi.write_formula('O19', '=IF(OR(O7=0,O8=0),"",INDEX(Verlauf!$H$6:$H$%d,O7)-INDEX(Verlauf!$H$6:$H$%d,O8))' % (MAX_VERLAUF, MAX_VERLAUF), st.zelle_zahl)
    ws_fi.write('N20', 'Δ Rückstand Verbund ggü. Vortag', st.zelle)
    ws_fi.write_formula('O20', '=IF(OR(O7=0,O8=0),"",INDEX(Verlauf!$R$6:$R$%d,O7)-INDEX(Verlauf!$R$6:$R$%d,O8))' % (MAX_VERLAUF, MAX_VERLAUF), st.zelle_zahl)
    ws_fi.write('N13', 'Altersstruktur (aktueller Stichtag, Filter aktiv)', st.abschnitt_klein)
    for c, t in enumerate(['0–7 Tage', '8–30 Tage', '31–90 Tage', 'über 90 Tage']):
        ws_fi.write(13, 14 + c, t, st.kopf_hell)
    for i, q in enumerate(['OPAG', 'Verbund']):
        ws_fi.write(14 + i, 13, q, st.zelle)
        for c, nm in enumerate(['F_A0', 'F_A1', 'F_A2', 'F_A3']):
            ws_fi.write_formula(14 + i, 14 + c, '=SUMIFS(%s,%s,$O$5,%s,"%s",%s,1)' % (bl(nm), bl('F_Stichtag'), bl('F_Quelle'), q, bl('F_Aktiv')), st.zelle_zahl)
    # Fakten-Zeilenblock des letzten Stichtags (aus Verlauf!AL:AM), Planungshorizont, Heute-Schluessel (TODAY nur hier)
    ws_fi.write('N22', 'Erste Fakten-Zeile letzter Stichtag', st.zelle)
    ws_fi.write_formula('O22', '=IF(O7=0,1,INDEX(Verlauf!$AL$6:$AL$%d,O7))' % MAX_VERLAUF, st.zelle_zahl)
    ws_fi.write('N23', 'Letzte Fakten-Zeile letzter Stichtag', st.zelle)
    ws_fi.write_formula('O23', '=IF(O7=0,1,INDEX(Verlauf!$AM$6:$AM$%d,O7))' % MAX_VERLAUF, st.zelle_zahl)
    ws_fi.write('N21', 'Warnung Planungshorizont', st.zelle)
    ws_fi.write_formula('O21', '=IF(O9="","",IF(O9*100+O10>MAX(KW!$W$6:$W$400),"Der Planungshorizont der Kalenderwochen ist überschritten – Blatt KW, Planung und Wirksam müssen im Build erweitert werden (kw_liste).",""))', st.zelle)
    ws_fi.write('N24', 'Heute: ISO-Schlüssel Jahr*100+KW', st.zelle)
    ws_fi.write_formula('O24', '=YEAR(TODAY()-WEEKDAY(TODAY(),2)+4)*100+ISOWEEKNUM(TODAY())', st.zelle_zahl)
    ws_fi.write('N25', 'Vergangen: Montag vor', st.zelle)
    ws_fi.write_formula('O25', '=TODAY()-6', st.zelle_dat)

    # ---------------------------------------------------------- Verlauf
    ws_v.set_column('A:A', 12)
    ws_v.set_column('B:C', 7)
    ws_v.set_column('D:AK', 11)
    ws_v.write('A1', 'Verlauf je Stichtag', st.titel)
    ws_v.write('A2', 'Alle Werte nach dem aktiven Filter (Themenpostkörbe, GeVo). Zeilen werden beim Laden ergänzt; Formeln der letzten Zeile werden kopiert.', st.untertitel)
    ws_v.merge_range('D4:M4', 'OPAG (Arbeitsgüter)', st.kopf_rot)
    ws_v.merge_range('N4:W4', 'Verbund (Vorgänge)', st.kopf)
    kopf_v = ['Stichtag', 'Jahr (ISO)', 'KW'] + ['Rückstand Komposit', 'Rückstand Leben', 'Rückstand KV', 'Rückstand Sonstige', 'Rückstand gesamt',
                                                 'Eingänge', 'Abgänge', 'Abgänge Komposit', 'Abgänge Leben', 'Abgänge KV'] * 2
    kopf_v += ['OPAG Eingänge Komposit', 'OPAG Eingänge Leben', 'OPAG Eingänge KV', 'Verbund Eingänge Komposit', 'Verbund Eingänge Leben', 'Verbund Eingänge KV',
               'OPAG Abgänge Komposit (−)', 'OPAG Abgänge Leben (−)', 'OPAG Abgänge KV (−)', 'Verbund Abgänge Komposit (−)', 'Verbund Abgänge Leben (−)', 'Verbund Abgänge KV (−)',
               'OPAG Netto', 'Verbund Netto']
    ws_v.merge_range('X4:AK4', 'Hilfsspalten für die Diagramme „Eingänge und Abgänge nach Sparte“', st.kopf_hell)
    for c, t in enumerate(kopf_v):
        ws_v.write(4, c, t, st.kopf_hell)
    ws_v.write(4, 37, 'erste Fakten-Zeile (Position)', st.kopf_hell)
    ws_v.write(4, 38, 'letzte Fakten-Zeile (Position)', st.kopf_hell)
    ws_v.set_column('AL:AM', 10)
    ws_v.set_row(4, 42)
    ws_v.freeze_panes(5, 1)

    bloecke = {}                                   # Verlauf-Zeile (0-basiert) -> (erste, letzte) Position der Fakten-Zeilen des Stichtags
    for i, d in enumerate(stichtage):
        idx = [k for k, z in enumerate(fakten) if z[0] == d]
        if idx:
            bloecke[5 + i] = (idx[0] + 1, idx[-1] + 1)   # Position 1 = Fakten-Zeile 2

    def verlauf_zeile(r):
        x = r + 1
        ws_v.write_formula(r, 1, '=YEAR(A%d-WEEKDAY(A%d,2)+4)' % (x, x), st.zelle_zahl)
        ws_v.write_formula(r, 2, '=ISOWEEKNUM(A%d)' % x, st.zelle_zahl)
        # AL/AM: erste und letzte Fakten-Zeile (Position im F_*-Bereich) dieses Stichtags – haengen nur von den Fakten ab,
        # rechnen also nach dem Laden, nicht bei Filterklicks. Die SUMIFS lesen dann nur diesen Block (Faktor Stichtage).
        # AL/AM als Werte (VBA VerlaufErgaenzen fuehrt sie beim Laden; keine Array-Formel ueber 300.000 Zeilen)
        pos = bloecke.get(r, (1, 1))
        ws_v.write_number(r, 37, pos[0], st.zelle_zahl)
        ws_v.write_number(r, 38, pos[1], st.zelle_zahl)
        bk = lambda nm: block(nm, '$AL%d' % x, '$AM%d' % x)  # noqa: E731
        for b, q in ((3, 'OPAG'), (13, 'Verbund')):
            for i, sp in enumerate(['Komposit', 'Leben', 'KV', 'Sonstige']):
                ws_v.write_formula(r, b + i, '=SUMIFS(%s,%s,$A%d,%s,"%s",%s,"%s",%s,1)' % (bk('F_Rueckstand'), bk('F_Stichtag'), x, bk('F_Quelle'), q, bk('F_Sparte'), sp, bk('F_Aktiv')), st.zelle_zahl)
            ws_v.write_formula(r, b + 4, '=SUM(%s%d:%s%d)' % (xl_col_to_name(b), x, xl_col_to_name(b + 3), x), st.zelle_zahl)
            ws_v.write_formula(r, b + 5, '=SUMIFS(%s,%s,$A%d,%s,"%s",%s,1)' % (bk('F_Eingang'), bk('F_Stichtag'), x, bk('F_Quelle'), q, bk('F_Aktiv')), st.zelle_zahl)
            ws_v.write_formula(r, b + 6, '=SUMIFS(%s,%s,$A%d,%s,"%s",%s,1)' % (bk('F_Abgang'), bk('F_Stichtag'), x, bk('F_Quelle'), q, bk('F_Aktiv')), st.zelle_zahl)
            for i, sp in enumerate(['Komposit', 'Leben', 'KV']):
                ws_v.write_formula(r, b + 7 + i, '=SUMIFS(%s,%s,$A%d,%s,"%s",%s,"%s",%s,1)' % (bk('F_Abgang'), bk('F_Stichtag'), x, bk('F_Quelle'), q, bk('F_Sparte'), sp, bk('F_Aktiv')), st.zelle_zahl)
        for b, q in ((23, 'OPAG'), (26, 'Verbund')):          # X..Z, AA..AC: Eingaenge je Sparte
            for i, sp in enumerate(['Komposit', 'Leben', 'KV']):
                ws_v.write_formula(r, b + i, '=SUMIFS(%s,%s,$A%d,%s,"%s",%s,"%s",%s,1)' % (bk('F_Eingang'), bk('F_Stichtag'), x, bk('F_Quelle'), q, bk('F_Sparte'), sp, bk('F_Aktiv')), st.zelle_zahl)
        for b, quelle_b in ((29, 10), (32, 20)):              # AD..AF, AG..AI: Abgaenge negativ
            for i in range(3):
                ws_v.write_formula(r, b + i, '=-%s%d' % (xl_col_to_name(quelle_b + i), x), st.zelle_zahl)
        ws_v.write_formula(r, 35, '=I%d-J%d' % (x, x), st.zelle_zahl)       # AJ OPAG Netto
        ws_v.write_formula(r, 36, '=S%d-T%d' % (x, x), st.zelle_zahl)       # AK Verbund Netto
    for i, d in enumerate(stichtage):
        ws_v.write_datetime(5 + i, 0, dt.datetime(d.year, d.month, d.day), st.zelle_dat)
        verlauf_zeile(5 + i)
    if not stichtage:
        verlauf_zeile(5)

    # ---------------------------------------------------------- KW
    ws_k.set_column('A:B', 7)
    ws_k.set_column('C:C', 10)
    ws_k.set_column('D:AN', 11)
    ws_k.write('A1', 'Kalenderwochen: Abgänge, Kapazität (MAK) und Produktivität', st.titel)
    ws_k.write('A2', 'Produktivität = Abgänge je MAK in der Kalenderwoche, je Vorgang (Verbund) und je Arbeitsgut (OPAG). Eine laufende KW enthält nur die bereits geladenen Stichtage.', st.untertitel)
    ws_k.merge_range('D4:G4', 'Abgänge OPAG', st.kopf_rot)
    ws_k.merge_range('H4:K4', 'Abgänge Verbund', st.kopf)
    ws_k.merge_range('L4:N4', 'MAK (Anwesenheit)', st.kopf_rot)
    ws_k.merge_range('O4:Q4', 'Produktivität je Vorgang (Verbund-Abgänge je MAK)', st.kopf)
    ws_k.merge_range('R4:T4', 'Produktivität je Arbeitsgut (OPAG-Abgänge je MAK)', st.kopf_rot)
    kopf_k = ['Jahr', 'KW', 'Bezeichnung', 'Komposit', 'Leben', 'KV', 'Gesamt', 'Komposit', 'Leben', 'KV', 'Gesamt',
              'Gesundheit (KV)', 'Komposit/Leben', 'Gesamt', 'KV', 'Komposit/Leben', 'Gesamt', 'KV', 'Komposit/Leben', 'Gesamt',
              'Stichtage', 'Chart', 'Schlüssel']
    for c, t in enumerate(kopf_k):
        ws_k.write(4, c, t, st.kopf_hell)
    ws_k.set_row(4, 30)
    ws_k.freeze_panes(5, 3)
    kw_liste = [(2026, k) for k in range(30, 54)] + [(j, k) for j in (2027, 2028, 2029, 2030) for k in range(1, 53)]   # Planungshorizont bis 2030
    for i, (j, k) in enumerate(kw_liste):
        r = 5 + i
        x = r + 1
        ws_k.write_number(r, 0, j, st.zelle_zahl)
        ws_k.write_number(r, 1, k, st.zelle_zahl)
        ws_k.write_formula(r, 2, '="KW "&B%d&"/"&RIGHT(A%d,2)' % (x, x), st.zelle)
        vb = 'Verlauf!$%s$6:$%s$%d'
        krit = 'Verlauf!$B$6:$B$%d,$A%d,Verlauf!$C$6:$C$%d,$B%d' % (MAX_VERLAUF, x, MAX_VERLAUF, x)
        for c, col in enumerate(['K', 'L', 'M', 'J']):
            ws_k.write_formula(r, 3 + c, '=SUMIFS(%s,%s)' % (vb % (col, col, MAX_VERLAUF), krit), st.zelle_zahl)
        for c, col in enumerate(['U', 'V', 'W', 'T']):
            ws_k.write_formula(r, 7 + c, '=SUMIFS(%s,%s)' % (vb % (col, col, MAX_VERLAUF), krit), st.zelle_zahl)
        # MAK je KW aus dem Anwesenheitsplan (Blatt Wirksam: Zeile 6 Schluessel, Spalte B Sparte, Matrix ab D7)
        # (Summenzeilen der Planung, Zeile PL_START+MA_ZEILEN+1 Gesundheit / +2 Komposit; KW-Zeile i entspricht Planung-Spalte i)
        wk = 'IFERROR(INDEX(Planung!$%s$%%d:$%s$%%d,MATCH($W%d,Wirksam!$%s$6:$%s$6,0)),0)' % (
            xl_col_to_name(PL_SPALTE0), xl_col_to_name(PL_SPALTE0 + len(kw_liste) - 1), x, xl_col_to_name(PL_SPALTE0), xl_col_to_name(PL_SPALTE0 + len(kw_liste) - 1))
        ws_k.write_formula(r, 11, '=IF(Filter!$T$7=TRUE,' + wk % (PL_START + MA_ZEILEN + 1, PL_START + MA_ZEILEN + 1) + ',0)', st.zelle_dez)
        ws_k.write_formula(r, 12, '=IF(OR(Filter!$T$5=TRUE,Filter!$T$6=TRUE),' + wk % (PL_START + MA_ZEILEN + 2, PL_START + MA_ZEILEN + 2) + ',0)', st.zelle_dez)
        ws_k.write_formula(r, 13, '=L%d+M%d' % (x, x), st.zelle_dez)
        ws_k.write_formula(r, 14, '=IF(AND(L%d>0,U%d>0),J%d/L%d,NA())' % (x, x, x, x), st.zelle_dez)          # Verbund KV je MAK Gesundheit
        ws_k.write_formula(r, 15, '=IF(AND(M%d>0,U%d>0),(H%d+I%d)/M%d,NA())' % (x, x, x, x, x), st.zelle_dez)  # Verbund Komposit+Leben je MAK Komposit
        ws_k.write_formula(r, 16, '=IF(AND(N%d>0,U%d>0),K%d/N%d,NA())' % (x, x, x, x), st.zelle_dez)          # Verbund gesamt
        ws_k.write_formula(r, 17, '=IF(AND(L%d>0,U%d>0),F%d/L%d,NA())' % (x, x, x, x), st.zelle_dez)          # OPAG KV
        ws_k.write_formula(r, 18, '=IF(AND(M%d>0,U%d>0),(D%d+E%d)/M%d,NA())' % (x, x, x, x, x), st.zelle_dez)  # OPAG Komposit+Leben
        ws_k.write_formula(r, 19, '=IF(AND(N%d>0,U%d>0),G%d/N%d,NA())' % (x, x, x, x), st.zelle_dez)          # OPAG gesamt
        ws_k.write_formula(r, 20, '=COUNTIFS(Verlauf!$B$6:$B$%d,$A%d,Verlauf!$C$6:$C$%d,$B%d)' % (MAX_VERLAUF, x, MAX_VERLAUF, x), st.zelle_zahl)
        ws_k.write_formula(r, 21, '=IF(OR(U%d>0,N%d>0),1,0)' % (x, x), st.zelle_zahl)
        ws_k.write_formula(r, 22, '=A%d*100+B%d' % (x, x), st.zelle_zahl)
    letzte_kw = 5 + len(kw_liste)
    ws_k.merge_range('X4:AA4', 'Eingänge OPAG', st.kopf_rot)
    ws_k.merge_range('AB4:AE4', 'Eingänge Verbund', st.kopf)
    ws_k.merge_range('AF4:AI4', 'Rückstand OPAG zum Wochenende', st.kopf_rot)
    ws_k.merge_range('AJ4:AM4', 'Rückstand Verbund zum Wochenende', st.kopf)
    for c, t in enumerate(['Komposit', 'Leben', 'KV', 'Gesamt'] * 4 + ['letzter Stichtag der KW']):
        ws_k.write(4, 23 + c, t, st.kopf_hell)
    for i, (j, k) in enumerate(kw_liste):
        r = 5 + i
        x = r + 1
        krit = 'Verlauf!$B$6:$B$%d,$A%d,Verlauf!$C$6:$C$%d,$B%d' % (MAX_VERLAUF, x, MAX_VERLAUF, x)
        for c, col in enumerate(['X', 'Y', 'Z', 'I', 'AA', 'AB', 'AC', 'S']):
            ws_k.write_formula(r, 23 + c, '=SUMIFS(Verlauf!$%s$6:$%s$%d,%s)' % (col, col, MAX_VERLAUF, krit), st.zelle_zahl)
        ws_k.write_formula(r, 39, '=IF(U%d>0,MAXIFS(Verlauf!$A$6:$A$%d,Verlauf!$B$6:$B$%d,$A%d,Verlauf!$C$6:$C$%d,$B%d),"")' % (x, MAX_VERLAUF, MAX_VERLAUF, x, MAX_VERLAUF, x), st.zelle_dat)
        for c, col in enumerate(['D', 'E', 'F', 'H', 'N', 'O', 'P', 'R']):
            ws_k.write_formula(r, 31 + c, '=IF($AN%d="","",INDEX(Verlauf!$%s$6:$%s$%d,MATCH($AN%d,Verlauf!$A$6:$A$%d,0)))' % (x, col, col, MAX_VERLAUF, x, MAX_VERLAUF), st.zelle_zahl)
    ws_k.set_column('AP:AP', 26)
    ws_k.write('AP4', 'Diagrammbereich', st.kopf)
    ws_k.write('AP5', 'erste Zeile (Stichtage)', st.zelle)
    ws_k.write_formula('AQ5', '=IFERROR(AGGREGATE(15,6,(ROW($U$6:$U$%d)-5)/($U$6:$U$%d>0),1),1)' % (letzte_kw, letzte_kw), st.zelle_zahl)
    ws_k.write('AP6', 'letzte Zeile (Stichtage)', st.zelle)
    ws_k.write_formula('AQ6', '=IFERROR(AGGREGATE(14,6,(ROW($U$6:$U$%d)-5)/($U$6:$U$%d>0),1),1)' % (letzte_kw, letzte_kw), st.zelle_zahl)
    ws_k.write('AP7', 'erste Zeile (MAK oder Stichtage)', st.zelle)
    ws_k.write_formula('AQ7', '=IFERROR(AGGREGATE(15,6,(ROW($V$6:$V$%d)-5)/($V$6:$V$%d=1),1),1)' % (letzte_kw, letzte_kw), st.zelle_zahl)
    ws_k.write('AP8', 'letzte Zeile (MAK oder Stichtage)', st.zelle)
    ws_k.write_formula('AQ8', '=IFERROR(AGGREGATE(14,6,(ROW($V$6:$V$%d)-5)/($V$6:$V$%d=1),1),1)' % (letzte_kw, letzte_kw), st.zelle_zahl)

    # ---------------------------------------------------------- Anwesenheit
    # ---------------------------------------------------------- Anwesenheitstool: Mitarbeiter, Planung, Wirksam
    anwesenheit_blaetter(wb, ws_m, ws_p, ws_w, st, kw_liste, anwesenheit, anw_datei)

    # ---------------------------------------------------------- Ladeprotokoll
    ws_l.set_column('A:A', 16)
    ws_l.set_column('B:B', 40)
    ws_l.set_column('C:C', 16)
    ws_l.set_column('D:I', 11)
    ws_l.set_column('J:J', 70)
    ws_l.write('A1', 'Ladeprotokoll', st.titel)
    ws_l.write('A2', 'Jeder geladene Stand (Quelle und Stichtag) steht hier genau einmal; erneutes Laden überspringt vorhandene Stände.', st.untertitel)
    for c, t in enumerate(['Zeitpunkt', 'Datei', 'Blatt', 'Quelle', 'Stichtag', 'Zeilen', 'Rückstand', 'Eingänge', 'Abgänge', 'Hinweis']):
        ws_l.write(3, c, t, st.kopf)
    for i, p in enumerate(protokoll):
        r = 4 + i
        ws_l.write_datetime(r, 0, p[0], st.zelle_datzeit)
        ws_l.write(r, 1, p[1], st.zelle)
        ws_l.write(r, 2, p[2], st.zelle)
        ws_l.write(r, 3, p[3], st.zelle)
        ws_l.write_datetime(r, 4, dt.datetime(p[4].year, p[4].month, p[4].day), st.zelle_dat)
        for c in range(5, 9):
            ws_l.write_number(r, c, p[c], st.zelle_zahl)
        ws_l.write(r, 9, p[9], st.zelle)

    # ---------------------------------------------------------- Diagrammdaten: immer 7 Perioden (Tag oder Woche), neueste rechts; leere Slots = #NV (werden nicht gezeichnet)
    ws_d.set_column('A:A', 16)
    ws_d.set_column('B:B', 7)
    ws_d.set_column('C:AD', 9)
    ws_d.set_column('AE:AE', 2)
    ws_d.set_column('AF:AF', 18)
    ws_d.write('A1', 'Diagrammdaten: die letzten 7 Perioden nach Ansicht (Filter!L9: Tag = Stichtage, Woche = Kalenderwochen), neueste Periode rechts, '
                     'leere Slots als #NV (werden nicht gezeichnet, die Diagrammbreite bleibt). Block A Rückstand, Block B Eingänge (positiv), Abgänge (negativ), Delta.', st.untertitel)
    ws_d.write('AF1', 'Perioden mit Daten', st.kopf)
    ws_d.write_formula('AF2', '=MIN(7,IF(Filter!$L$9="Woche",COUNTIF(KW!$U$6:$U$%d,">0"),COUNT(Verlauf!$A$6:$A$%d)))' % (letzte_kw, MAX_VERLAUF), st.zelle_zahl)
    G = '$AF$2'
    for c, t in enumerate(['Periode', 'Index', 'OPAG Komposit', 'OPAG Leben', 'OPAG KV', 'OPAG Gesamt', 'Verbund Komposit', 'Verbund Leben', 'Verbund KV', 'Verbund Gesamt',
                           'OPAG Ein Σ', 'OPAG Abg Σ (neg.)', 'OPAG Delta', 'Verbund Ein Σ', 'Verbund Abg Σ (neg.)', 'Verbund Delta',
                           'OPAG Δ weniger', 'OPAG Δ mehr', 'OPAG Δ gleich', 'OPAG Achsenluft', 'OPAG Δ Text',
                           'Verbund Δ weniger', 'Verbund Δ mehr', 'Verbund Δ gleich', 'Verbund Achsenluft', 'Verbund Δ Text']):
        ws_d.write(2, c, t, st.kopf_hell)
    kopf_b = ['Periode · Art', 'Index']
    for q in ('OPAG', 'Verbund'):
        for art in ('Ein', 'Abg', 'Delta'):
            kopf_b += ['%s %s %s' % (q, art, s) for s in ('Ko', 'Le', 'KV')]
        kopf_b += ['%s Ein Σ' % q, '%s Abg Σ' % q, '%s Delta Σ Position oben' % q, '%s Delta Σ Position unten' % q, '%s Delta Σ Text' % q]
    for c, t in enumerate(kopf_b):
        ws_d.write(11, c, t, st.kopf_hell)
    ws_d.set_row(11, 30)
    woche = 'Filter!$L$9="Woche"'
    for j in range(1, 8):                     # Block A: Zeilen 4..10, Slot 7 = neueste Periode
        x = 3 + j
        ws_d.write_formula(x - 1, 1, '=IF(%d<=7-%s,"",IF(%s,AGGREGATE(14,6,(ROW(KW!$U$6:$U$%d)-5)/(KW!$U$6:$U$%d>0),%d),COUNT(Verlauf!$A$6:$A$%d)-7+%d))'
                           % (j, G, woche, letzte_kw, letzte_kw, 8 - j, MAX_VERLAUF, j), st.zelle_zahl)
        ws_d.write_formula(x - 1, 0, '=IF(B%d="","",IF(%s,"KW "&INDEX(KW!$B$6:$B$%d,B%d),RIGHT("0"&DAY(INDEX(Verlauf!$A$6:$A$%d,B%d)),2)&"."&RIGHT("0"&MONTH(INDEX(Verlauf!$A$6:$A$%d,B%d)),2)&"."))'
                           % (x, woche, letzte_kw, x, MAX_VERLAUF, x, MAX_VERLAUF, x), st.zelle)
        for c, (vcol, kcol) in enumerate([('D', 'AF'), ('E', 'AG'), ('F', 'AH'), ('H', 'AI'), ('N', 'AJ'), ('O', 'AK'), ('P', 'AL'), ('R', 'AM')]):
            ws_d.write_formula(x - 1, 2 + c, '=IF($B%d="",NA(),IF(%s,INDEX(KW!$%s$6:$%s$%d,$B%d),INDEX(Verlauf!$%s$6:$%s$%d,$B%d)))'
                               % (x, woche, kcol, kcol, letzte_kw, x, vcol, vcol, MAX_VERLAUF, x), st.zelle_zahl)
        # Summen je Periode fuer die PPT-Kacheln: Eingaenge, Abgaenge (negativ), Delta – (Verlauf Ein, Verlauf Abg, KW Ein, KW Abg)
        for c, (ve, va, ke, ka) in enumerate([('I', 'J', 'AA', 'G'), ('S', 'T', 'AE', 'K')]):
            e = 'N(IF(%s,INDEX(KW!$%s$6:$%s$%d,$B%d),INDEX(Verlauf!$%s$6:$%s$%d,$B%d)))' % (woche, ke, ke, letzte_kw, x, ve, ve, MAX_VERLAUF, x)
            a = 'N(IF(%s,INDEX(KW!$%s$6:$%s$%d,$B%d),INDEX(Verlauf!$%s$6:$%s$%d,$B%d)))' % (woche, ka, ka, letzte_kw, x, va, va, MAX_VERLAUF, x)
            ws_d.write_formula(x - 1, 10 + c * 3, '=IF($B%d="",NA(),%s)' % (x, e), st.zelle_zahl)
            ws_d.write_formula(x - 1, 11 + c * 3, '=IF($B%d="",NA(),-%s)' % (x, a), st.zelle_zahl)
            ws_d.write_formula(x - 1, 12 + c * 3, '=IF($B%d="",NA(),%s-%s)' % (x, e, a), st.zelle_zahl)
        # Badges ueber den Rueckstandssaeulen: Veraenderung zur vorherigen Periode (gruen = weniger, gelb = mehr, grau = gleich) als
        # unsichtbare Punktreihen in fester Hoehe ueber der Summe (Summe + 22 % der hoechsten Saeule; das Etikett sitzt mittig auf dem
        # Punkt, Text aus der Zelle). "Achsenluft" (1,42 x Maximum) haelt die Automatik-Achse in Excel frei. Hinweis: LibreOffice
        # stapelt die Punktreihen eines kombinierten Stapeldiagramms und zeigt die Badges daher nicht an der richtigen Stelle.
        for c, ges in enumerate(['F', 'J']):
            b0 = 16 + c * 5
            mx = 'AGGREGATE(4,6,$%s$4:$%s$10)' % (ges, ges)
            d = '(%s%d-%s%d)' % (ges, x, ges, x - 1)
            gueltig = 'OR($B%d="",%d=1,ISNA(%s%d))' % (x, j, ges, x - 1)
            for k, bed in enumerate(['%s<0' % d, '%s>0' % d, '%s=0' % d]):
                ws_d.write_formula(x - 1, b0 + k, '=IF(%s,NA(),IF(%s,%s%d+%s*0.22,NA()))' % (gueltig, bed, ges, x, mx), st.zelle_zahl)
            ws_d.write_formula(x - 1, b0 + 3, '=IF($B%d="",NA(),%s*1.42)' % (x, mx), st.zelle_zahl)
            ws_d.write_formula(x - 1, b0 + 4, '=IF(%s,"",IF(%s>0,"+"&FIXED(%s,0),IF(%s<0,"-"&FIXED(-%s,0),"±0")))' % (gueltig, d, d, d, d), st.zelle)
    # Block B: Zeilen 13..33, je Periode drei Zeilen (Eingaenge, Abgaenge, Delta); je Quelle 9 Wertspalten + 5 Summenspalten
    # (Delta-Summe: Position am Ende des Stapels, Text als verknuepfte Beschriftung, weil der Stapel gemischte Vorzeichen haben kann)
    quellen = {'OPAG': [('X', 'K', 'X', 'D'), ('Y', 'L', 'Y', 'E'), ('Z', 'M', 'Z', 'F')],            # (Verlauf Ein, Verlauf Abg, KW Ein, KW Abg) je Ko/Le/KV
               'Verbund': [('AA', 'U', 'AB', 'H'), ('AB', 'V', 'AC', 'I'), ('AC', 'W', 'AD', 'J')]}
    for t in range(1, 22):
        x = 12 + t
        pz = 3 + (t - 1) // 3 + 1
        art = (t - 1) % 3
        ws_d.write_formula(x - 1, 1, '=IF($B$%d="","",$B$%d)' % (pz, pz), st.zelle_zahl)
        ws_d.write_formula(x - 1, 0, '=IF(B%d="","",$A$%d&CHAR(10)&"%s")' % (x, pz, ['Eingänge', 'Abgänge', 'Delta'][art]), st.zelle)
        for qi, q in enumerate(('OPAG', 'Verbund')):
            basis = 2 + qi * 14
            for si, (ve, va, ke, ka) in enumerate(quellen[q]):
                e = 'N(IF(%s,INDEX(KW!$%s$6:$%s$%d,$B%d),INDEX(Verlauf!$%s$6:$%s$%d,$B%d)))' % (woche, ke, ke, letzte_kw, x, ve, ve, MAX_VERLAUF, x)
                a = 'N(IF(%s,INDEX(KW!$%s$6:$%s$%d,$B%d),INDEX(Verlauf!$%s$6:$%s$%d,$B%d)))' % (woche, ka, ka, letzte_kw, x, va, va, MAX_VERLAUF, x)
                for k, ausdruck in enumerate([e, '-' + a, '%s-%s' % (e, a)]):
                    col = basis + k * 3 + si
                    ws_d.write_formula(x - 1, col, ('=IF($B%d="",NA(),%s)' % (x, ausdruck)) if k == art else '=NA()', st.zelle_zahl)
            bereich = lambda k: '%s%d:%s%d' % (xl_col_to_name(basis + k * 3), x, xl_col_to_name(basis + k * 3 + 2), x)  # noqa: E731
            summen = ['=IF($B%d="",NA(),SUM(%s))' % (x, bereich(0)) if art == 0 else '=NA()',
                      '=IF($B%d="",NA(),SUM(%s))' % (x, bereich(1)) if art == 1 else '=NA()',
                      '=IF($B%d="",NA(),IF(SUM(%s)>=0,SUMIF(%s,">0"),NA()))' % (x, bereich(2), bereich(2)) if art == 2 else '=NA()',
                      '=IF($B%d="",NA(),IF(SUM(%s)<0,SUMIF(%s,"<0"),NA()))' % (x, bereich(2), bereich(2)) if art == 2 else '=NA()',
                      '=IF($B%d="","",IF(SUM(%s)=0,"±0",IF(SUM(%s)<0,"-","+")&FIXED(ABS(SUM(%s)),0,FALSE)))' % (x, bereich(2), bereich(2), bereich(2)) if art == 2 else '""']
            for k, f in enumerate(summen):
                ws_d.write_formula(x - 1, basis + 9 + k, f, st.zelle_zahl)
    ws_d.freeze_panes(3, 0)

    # ---------------------------------------------------------- Snapshots
    for ws_s, q in ((ws_so, 'OPAG'), (ws_sv, 'Verbund')):
        for c, t in enumerate(['Schlüssel', 'Sparte', 'VSS', 'Themenpostkorb', 'GEVO_SL']):
            ws_s.write(0, c, t, st.kopf)
        ws_s.write('G1', 'Stichtag', st.kopf)
        ws_s.write('G2', 'Stichtag des Stands', st.zelle)
        ws_s.write('G3', 'Schlüssel', st.zelle)
        if snap[q]:
            ws_s.write_datetime('H2', dt.datetime(snap_datum[q].year, snap_datum[q].month, snap_datum[q].day), st.zelle_dat)
            ws_s.write_number('H3', len(snap[q]), st.zelle_zahl)
            for i, (key, m) in enumerate(snap[q].items()):
                ws_s.write_row(1 + i, 0, [key, m[0], m[1], m[2], m[3]])

    # ---------------------------------------------------------- Anleitung
    anleitung(wb, ws_an, st)

    # ---------------------------------------------------------- Cockpit
    kw_index = {(j, k): i for i, (j, k) in enumerate(kw_liste)}
    st_rows = sorted({kw_index.get((d.isocalendar()[0], d.isocalendar()[1])) for d in stichtage} - {None})
    bereiche = {'n_st': max(1, len(stichtage)),
                'kw1': 6 + (min(st_rows) if st_rows else 0), 'kw2': 6 + (max(st_rows) if st_rows else 0),
                'n_pk': max(1, len(postkoerbe))}
    werte = cockpit_werte(fakten, stichtage)
    cockpit(wb, ws_c, st, postkoerbe, gevo_typen, bereiche, werte)
    ppt_blatt(wb, ws_ppt, st, bereiche, werte)

    wb.close()
    return postkoerbe, gevo_typen



# ------------------------------------------------------------------ Anleitung (How-to)
ANLEITUNG = [
 ('H1', 'Anleitung: BÜ-Reporting HSB4 K'),
 ('P', 'Diese Arbeitsmappe ist die Master-Datei des tagesbasierten BÜ-Reportings. Sie liest die Rückstandsabzüge OPAG und Verbund aus einem Ordner, '
       'führt Rückstand, Eingänge, Abgänge und Produktivität fort und zeigt alles im Cockpit. Die Rohdaten selbst bleiben unverändert in ihrem Ordner.'),
 ('H2', '1. Ordner einrichten'),
 ('B', 'Master-Datei (diese Datei) in einen eigenen Ordner legen, zum Beispiel „BÜ-Reporting“.'),
 ('B', 'Daneben den Unterordner „Rohdaten“ anlegen. Dort landen die Rückstandsabzüge. Der Name ist in Konfiguration!B3 änderbar (relativ zur Master-Datei oder absolut).'),
 ('B', 'Daneben den Unterordner „Anwesenheit“ anlegen. Dort liegt die MAK-Liste; die neueste Datei im Ordner wird gelesen (Konfiguration!B4).'),
 ('B', 'Beim ersten Öffnen die Makros aktivieren (gelbe Leiste „Inhalt aktivieren“). Ohne Makros funktionieren weder Laden noch Chips; die Filterzellen in „Filter“ und die Formeln bleiben nutzbar.'),
 ('B', 'Die Master-Datei kommt leer: Fakten, Verlauf, Ladeprotokoll und Anwesenheit sind unbefüllt, das Cockpit zeigt nur den Rahmen. Der erste Klick auf „Neue Daten laden“ füllt alles aus dem Ordner Rohdaten und lädt, wenn noch keine MAK-Liste da ist, gleich die Anwesenheit mit; „Anwesenheit laden“ aktualisiert sie später (MAK und Produktivität bleiben sonst leer). Neue Themenpostkörbe aus den Abzügen erscheinen in Filter!B mit WAHR.'),
 ('H2', '2. Täglicher Ablauf'),
 ('B', 'Abzug OPAG und Abzug Verbund aus MIS-O als Excel-Datei in „Rohdaten“ speichern. Der Dateiname ist egal; empfohlen: JJJJMMTT_Rueckstand_OPAG_HSB4K.xlsx bzw. …_Verbund_….'),
 ('B', 'Im Cockpit auf „Neue Daten laden“ klicken. Die Meldung nennt, wie viele Stände neu geladen und wie viele übersprungen wurden.'),
 ('B', 'Das Ladeprotokoll zeigt je Stand Datei, Blatt, Quelle, Stichtag, Zeilen, Rückstand, Eingänge und Abgänge. Steht in „Hinweis“ etwas, wurde der Stand nicht normal geladen.'),
 ('B', 'Alte Dateien dürfen im Ordner bleiben: Ein Stand (Quelle und Stichtag) wird nur einmal geladen. Aufräumen ist nicht nötig, macht das Laden aber schneller.'),
 ('H2', '3. Tagesdateien und Sammeldateien'),
 ('P', 'Beides funktioniert. Die Erkennung arbeitet je Blatt, nicht je Datei:'),
 ('B', 'Tagesdatei: eine Datei mit einem Blatt (ein Stichtag, eine Quelle) – der Normalfall.'),
 ('B', 'Sammeldatei: eine Datei mit mehreren Blättern, zum Beispiel „OPAG 22.09.“, „OPAG 23.09.“, „Verbund 22.09.“, „Verbund 23.09.“ – jedes Blatt wird einzeln erkannt und geladen.'),
 ('B', 'Erkennung des Stichtags: in den ersten 15 Zeilen eine Zelle mit „Rückstandsstichtag = Mittwoch, 23. September 2026“ (Wochentag beliebig, Monat ausgeschrieben).'),
 ('B', 'Erkennung der Quelle: die Kopfzeile enthält „Themenpostkorb“; steht dort auch „OPS_AUFTR_ID“, ist es OPAG, sonst Verbund.'),
 ('B', 'Pflichtspalten: Verwaltungssystemschlüssel, Ordnungsbegriff, VORG_VERBU_LNR, Themenpostkorb, Rückstandsalter_Tage, GEVO_SL; OPAG zusätzlich OPS_AUFTR_ID und OPS_ARBGUT_LNR. Reihenfolge egal, Summenzeile („Anzahl: 13.831“) wird übersprungen.'),
 ('B', 'Reihenfolge: Alle gefundenen Stände werden nach Stichtag sortiert und in dieser Reihenfolge verarbeitet. Ein Stand, der älter ist als der zuletzt geladene Stand seiner Quelle, wird übersprungen und im Protokoll vermerkt, weil Eingänge und Abgänge aus dem Vergleich mit dem jeweils letzten Stand entstehen.'),
 ('B', 'Lücken (Wochenende, fehlender Tag) sind erlaubt: Der Vergleich läuft immer gegen den letzten geladenen Stand, die Bewegungen werden dem neuen Stichtag zugerechnet.'),
 ('H2', '4. Anwesenheit: einmal importieren, dann im Tool pflegen'),
 ('B', 'Erster Schritt: Die MAK-Liste in „Anwesenheit“ ablegen (Kopfzeile mit „Mitarbeiter“, Spalten „Makler BÜ Gesundheit“ und „Makler BÜ Komposit“ für die Sparte, Wochenspalten „33 KW“, „34. KW“ …) und „Anwesenheit laden“ klicken (beim ersten „Neue Daten laden“ passiert das automatisch). Das Jahr der Liste steht in Konfiguration!B5.'),
 ('B', 'Der Import füllt das Blatt „Mitarbeiter“ (Name, Einheit, Sparte, Kapazität = größter Wochenwert der Liste) und trägt im Blatt „Planung“ nur die Abweichungen ein: „Urlaub“ wird U, sonstiger Text F, abweichende Zahlen bleiben Zahlen. Ein erneuter Import ergänzt neue Namen und überschreibt die importierten Wochen; eigene Einträge in anderen Wochen bleiben.'),
 ('B', 'Ab dann wird die Anwesenheit im Tool gepflegt. Blatt „Planung“ (Knopf „Anwesenheitsplan öffnen“): eine Zeile je Mitarbeiter, eine Spalte je Kalenderwoche bis Ende 2028. Leer = anwesend mit Kapazität, U = Urlaub, K = krank, F = Fortbildung/sonstige Abwesenheit, H = halbe Woche, Zahl = MAK dieser Woche. Vergangene Wochen sind grau, die aktuelle Woche ist rot markiert, „Zur aktuellen KW“ springt hin. Unter der Matrix stehen die wirksamen MAK je KW.'),
 ('B', 'Neue Mitarbeitende: im Blatt „Mitarbeiter“ die nächste freie Zeile ausfüllen (Name, Sparte, Kapazität; Eintritt optional). Die Person erscheint sofort in der Planung. Austritt: Datum in „Austritt“ oder Aktiv = FALSCH; ab dann zählt sie nicht mehr. Kapazität ist die MAK je Woche bei voller Anwesenheit (1,0 Vollzeit, 0,5 halbe Stelle).'),
 ('B', 'Gesundheit wird der Sparte KV zugeordnet, Komposit dem Block Komposit/Leben. Eine Trennung Komposit gegen Leben gibt die Planung nicht her; die Produktivität wird deshalb für KV und für Komposit/Leben zusammen ausgewiesen. Alles rechnet über Formeln (Blatt Wirksam, ausgeblendet), Änderungen wirken sofort auf MAK und Produktivität.'),
 ('H2', '5. PowerPoint-Folie'),
 ('B', '„PowerPoint-Folie erzeugen“ (Cockpit) kopiert die sechs Kacheln des Blatts „PPT“ als Formen auf eine Folie der ERGO-Vorlage (Vorlage\\ERGO_Vorlage.pptx neben der Master-Datei; fehlt sie, entsteht eine leere Präsentation). Titel „HS | BÜ-Reporting Makler-Bestandsübertragung“, Untertitel mit Stichtag, oben rechts „Vertraulich“. Die Kachelköpfe tragen die Kennzahlen (Rückstand mit Delta, Eingänge/Abgänge, MAK und Produktivität, Anteil über 90 Tage); OPAG rot, Verbund petrol.'),
 ('B', 'Die Formen bleiben in PowerPoint bearbeitbar (Diagramme als Diagramme, Texte in Arial). Eine Kopie wird im Ordner „Praesentationen“ neben der Master-Datei gesichert, PowerPoint bleibt mit der Folie offen. Die Kacheln zeigen immer den aktuellen Filter und die aktuelle Ansicht (Tag/Woche); die Fußnote der Kacheln nennt beides.'),
 ('H2', '6. Filter im Cockpit'),
 ('B', 'Themenpostkörbe: Chips per Klick an- oder abwählen (gefüllt = im Filter, weiß = ausgeblendet; beim Überfahren mit der Maus leuchtet der Chip auf – Excel merkt sich dabei eine Änderung, daher die Speichern-Nachfrage beim Schließen). „Alle“ wählt alles, „Aktive Bearbeitung“ die Vorauswahl aus Konfiguration!F11:F30 (Standard KO, MV, GR – ohne 72-Stunden-BOT und BÜ; BE, WR, 00 fachlich zu klären).'),
 ('B', 'GeVo-Typen: Modus „Alle GeVo“ (kein Filter), „Nur BÜ-Schlüssel“ (GeVo-Nummern aus Konfiguration!D11:D20: 108, 469, 2015, 6065) oder „Manuelle Auswahl“ über die Chips der 13 häufigsten GeVo-Typen (aufsteigend nach GeVo-Nummer) plus „Alle übrigen“. Ein Klick auf einen GeVo-Chip wechselt automatisch in die manuelle Auswahl.'),
 ('B', 'Die Filter wirken auf alle Kennzahlen und Diagramme sofort. Neue Postkörbe aus späteren Abzügen erscheinen in Filter!B5:B44 mit WAHR und lassen sich dort umschalten (ohne Chip).'),
 ('B', '„Rückstand je Themenpostkorb“ unten rechts zeigt bewusst ohne Filter, was jedes Kästchen ein- oder ausschließt.'),
 ('B', 'Sparten: Die Chips Komposit, Leben, KV und Sonstige grenzen alle Kennzahlen und Diagramme auf die gewählten Sparten ein – so lässt sich in ein Einzelreporting je Sparte abtauchen. MAK und Produktivität folgen der Auswahl (KV rechnet gegen MAK Gesundheit, Komposit/Leben gegen MAK Komposit). „Alle Sparten“ hebt die Einschränkung auf.'),
 ('B', 'Veränderung zum vorherigen Stand: Die Kacheln Rückstand OPAG und Verbund zeigen das Delta gegenüber dem zuletzt geladenen Stand mit dessen Datum; über den Rückstandssäulen steht dasselbe je Periode als Badge (grün = weniger, gelb = mehr, grau = unverändert). Der Vergleich gilt immer gegenüber dem vorherigen geladenen Stand – ein Montagsstand nach einem Freitagsstand zeigt also die Veränderung über das Wochenende, und Eingänge/Abgänge sind die Bewegungen zwischen genau diesen beiden Ständen.'),
 ('B', 'Ansicht: „Tagessicht“ zeigt die letzten 7 Stichtage, „Wochensicht“ die letzten 7 Kalenderwochen (Rückstand zum letzten Stichtag der Woche, Eingänge/Abgänge/Delta als Wochensumme). Die Umschaltung wirkt auf die vier Verlaufs- und Bewegungsdiagramme; MAK und Produktivität sind immer je Kalenderwoche (Fenster von 7 KW bis zur KW des letzten Stichtags).'),
('B', 'Diagramme haben immer 7 Plätze, die neueste Periode steht rechts; solange weniger Stände vorliegen, bleiben die Plätze links frei – so ist die spätere Breite von Anfang an sichtbar. Eingänge stehen über der Achse, Abgänge darunter, das Delta (Eingänge minus Abgänge) je Sparte daneben; die Summe steht über bzw. unter der Säule. Werte, die nicht in ihr Segment passen, stehen wie in think-cell mit Führungslinie links oder rechts neben der Säule (in Excel setzt das Makro sie nach jeder Änderung neu).'),
 ('H2', '7. Kennzahlen'),
 ('B', 'Rückstand: Zeilen des Abzugs am Stichtag. OPAG zählt Arbeitsgüter (mehrere je Vorgang möglich), Verbund zählt Vorgänge. Sparte aus dem Verwaltungssystemschlüssel (Konfiguration!A11:B40).'),
 ('B', 'Eingänge: Schlüssel, die im neuen Stand erstmals vorkommen. Schlüssel Verbund = Verwaltungssystemschlüssel + Ordnungsbegriff + VORG_VERBU_LNR; OPAG zusätzlich OPS_AUFTR_ID + OPS_ARBGUT_LNR.'),
 ('B', 'Abgänge: Schlüssel des Vortagsstands, die im neuen Stand fehlen – abgearbeitet, weitergeleitet an die Sparte oder an den 72-Stunden-BOT übergeben. Sie werden dem Postkorb, GeVo und der Sparte des Vortags zugeordnet.'),
 ('B', 'Ein Vorgang, der nur den Postkorb wechselt (zum Beispiel MV nach KO), ist weder Eingang noch Abgang; er zählt am neuen Stichtag im neuen Postkorb.'),
 ('B', 'Altersstruktur: Rückstandsalter 0–7, 8–30, 31–90 und über 90 Tage am aktuellen Stichtag.'),
 ('B', 'Produktivität: Abgänge je MAK in der Kalenderwoche, ausgewiesen je Vorgang (Verbund) und je Arbeitsgut (OPAG), jeweils KV (gegen MAK Gesundheit), Komposit/Leben (gegen MAK Komposit) und Gesamt. Die laufende KW enthält nur die bereits geladenen Stichtage und ist erst am Wochenende vollständig.'),
 ('B', 'Der erste Stand je Quelle liefert nur den Rückstand; Eingänge und Abgänge gibt es ab dem zweiten Stand.'),
 ('H2', '8. Blätter'),
 ('B', 'Cockpit: Kennzahlen, Filter, Diagramme. Verlauf: eine Zeile je Stichtag (gefiltert). KW: Abgänge, MAK und Produktivität je Kalenderwoche. Fakten: verdichtete Sätze je Stichtag, Quelle, Sparte, VSS, Postkorb und GeVo mit Filterkennzeichen. Diagrammdaten: Hilfstabelle mit immer 7 Perioden für Rückstand und für die Säulen Eingänge (über der Achse), Abgänge (unter der Achse) und Delta.'),
 ('B', 'PPT: die Kacheln für die PowerPoint-Folie. Planung: Anwesenheitsmatrix je Mitarbeiter und KW. Mitarbeiter: Stammdaten. Filter: Zellen der Chips und Hilfsgrößen. Konfiguration: Pfade, Sparten, BÜ-Schlüssel, Vorauswahl. Ladeprotokoll: jeder geladene Stand. Wirksam (ausgeblendet): berechnete MAK je Mitarbeiter und KW.'),
 ('B', 'Snapshot_OPAG und Snapshot_Verbund (ausgeblendet): die Schlüssel des jeweils letzten Stands für den Vergleich am nächsten Tag. Nicht bearbeiten.'),
 ('H2', '9. Wenn etwas nicht klappt'),
 ('B', '„Rohdaten-Ordner nicht gefunden“: Ordner neben der Master-Datei anlegen oder Pfad in Konfiguration!B3 setzen.'),
 ('B', '„kein Rückstandsabzug erkannt“: Stichtag-Zeile oder Kopfzeile fehlt, oder das Blatt ist als Werte ohne die ersten Kopfzeilen gespeichert. Die Kopfzeilen des MIS-O-Abzugs müssen erhalten bleiben.'),
 ('B', '„übersprungen: Stichtag liegt vor dem zuletzt geladenen Stand“: ein älterer Abzug kam nach einem neueren. Ältere Stände können nachträglich nicht eingeordnet werden; wenn nötig Fakten, Verlauf, Ladeprotokoll und Snapshots leeren und alle Abzüge in Reihenfolge neu laden.'),
 ('B', 'Eine Rohdatei ist noch in Excel geöffnet: schließen, dann erneut laden. Dateien, die mit „~$“ beginnen, werden ignoriert.'),
 ('B', 'Kennzahlen zeigen leer: Es ist noch kein Stand geladen, oder alle Kästchen sind abgewählt. „Zurücksetzen“ nimmt alle Filter zurück.'),
 ('B', 'Diagramme ohne Werte oder mit altem Bereich: „Aktualisieren“ klicken; die Makros setzen die Datenbereiche der Diagramme nach jedem Laden neu (immer 7 Perioden, neueste rechts; leere Slots bleiben frei) und legen Werte, die nicht in ihr Segment passen, mit Führungslinie neben die Säule.'),
 ('B', 'Während „Neue Daten laden“ und „Anwesenheit laden“ zeigt ein Overlay auf dem Blatt den Fortschritt (Datei, Stand, Prozent). Excel ist in der Zeit gesperrt; das Overlay verschwindet von selbst, auch bei einem Fehler.'),
 ('B', 'Excel stürzt beim Laden oder beim Überfahren der Chips ab: Die Datei Ladelog.txt neben der Master-Datei zeigt den letzten Schritt vor dem Absturz. Den Hover-Effekt der Chips in Konfiguration!B8 auf NEIN stellen (die Chips bleiben klickbar), dann erneut versuchen. Stürzt Excel erst bei der Abschlussmeldung ab, Konfiguration!B9 auf NEIN stellen: Meldungen kommen dann als klassisches Fenster.'),
 ('B', 'Laufzeitfehler 52 „Bad file name or number“ oder „Ordner nicht gefunden“ mit einer https-Adresse: Die Master-Datei liegt in OneDrive oder SharePoint. Das Makro bildet die Adresse auf den synchronisierten Ordner ab; klappt das nicht, fragt es den Ordner einmal ab und merkt ihn sich in Konfiguration!B7. Dort lässt sich der lokale Pfad auch direkt eintragen.'),
 ('H2', '10. Grenzen'),
 ('B', 'Die Fakten-Tabelle fasst je Stichtag rund 500 bis 600 Zeilen je Quelle; Platz ist für etwa 300 Stichtage je Quelle (300.000 Zeilen). Danach die Datei kopieren und neu beginnen oder alte Stichtage aus Fakten und Verlauf löschen.'),
 ('B', 'Die Schlüssel des letzten Stands (rund 30.000 OPAG, 14.000 Verbund) bleiben in der Datei; sie ist deshalb einige Megabyte groß.'),
]


def anleitung(wb, ws, st):
    ws.set_column('A:A', 2)
    ws.set_column('B:B', 3)
    ws.set_column('C:C', 120)
    ws.set_tab_color(GRAUD)
    h1 = wb.add_format({'font_name': FONT, 'font_size': 20, 'bold': True, 'font_color': SW, 'valign': 'vcenter'})
    h2 = wb.add_format({'font_name': FONT, 'font_size': 12, 'bold': True, 'font_color': ROT, 'valign': 'bottom'})
    p = wb.add_format({'font_name': FONT, 'font_size': 10, 'font_color': SW, 'text_wrap': True, 'valign': 'top'})
    b = wb.add_format({'font_name': FONT, 'font_size': 10, 'font_color': SW, 'text_wrap': True, 'valign': 'top'})
    punkt = wb.add_format({'font_name': FONT, 'font_size': 10, 'font_color': ROT, 'bold': True, 'valign': 'top', 'align': 'center'})
    r = 1
    for art, text in ANLEITUNG:
        if art == 'H1':
            ws.set_row(r, 32)
            ws.write(r, 1, text, h1)
            r += 1
            ws.write(r, 1, 'Ordnerstruktur: Master-Datei · Rohdaten\\ · Anwesenheit\\ · Vorlage\\ · Praesentationen\\ – Stand der Anleitung: ' + dt.date.today().strftime('%d.%m.%Y'), st.untertitel)
            r += 2
        elif art == 'H2':
            r += 1
            ws.set_row(r, 22)
            ws.write(r, 1, text, h2)
            r += 1
        elif art == 'P':
            zeilen = max(1, len(text) // 115 + 1)
            ws.set_row(r, 14 * zeilen)
            ws.merge_range(r, 1, r, 2, text, p)
            r += 1
        else:
            zeilen = max(1, len(text) // 112 + 1)
            ws.set_row(r, 14 * zeilen)
            ws.write(r, 1, '•', punkt)
            ws.write(r, 2, text, b)
            r += 1


# ------------------------------------------------------------------ Cockpit
CHART_B, CHART_B_VOLL, CHART_H = 630, 1290, 285      # Pixel: halbe Breite, volle Breite, Hoehe
SPALTE_PX = 26                                        # Breite der Rasterspalten im Diagrammbereich (3,0 Zeichen)
LABEL_FONT = {'name': FONT, 'size': 8, 'bold': True}
# Innere Zeichenflaeche der gestapelten Diagramme als Anteil der Diagrammflaeche – fest gesetzt, damit die
# Etikettengeometrie (schmale Segmente -> Wert neben der Saeule mit Fuehrungslinie) beim Bau berechenbar ist.
PLOT_STAPEL = {'x': 0.015, 'y': 0.10, 'width': 0.97, 'height': 0.76}
PLOT_BEWEG = {'x': 0.015, 'y': 0.10, 'width': 0.97, 'height': 0.70}
PLOT_ALTER = {'x': 0.09, 'y': 0.12, 'width': 0.88, 'height': 0.76}
GEOMETRIE = []                                        # je Diagramm: Angaben fuer die Nachbearbeitung der Etiketten


def achsen_ende(m, luft=1.10):
    """Obere Achsengrenze: Luft fuer die Summenzahl (und Badges) ueber dem Stapel, auf zwei geltende Stellen aufgerundet."""
    if m <= 0:
        return 0
    u = 10 ** (math.floor(math.log10(m)) - 1)
    return math.ceil(m * luft / u) * u


def cockpit(wb, ws, st, postkoerbe, gevo_typen, ber, werte):
    ws.set_zoom(90)
    ws.set_vba_name('Cockpit')         # Codename fuer das Blattmodul (Worksheet_SelectionChange der Chips)
    ws.set_column('A:A', 1.5)
    ws.set_column('B:G', 5.4)          # Filterpanel (6 x 43 px)
    ws.set_column('H:H', 1.5)
    ws.set_column('I:BF', 3.0)         # Diagrammraster, 50 Spalten x 26 px
    ws.set_row(0, 8)
    ws.set_row(1, 30)
    ws.set_row(2, 16)
    ws.set_row(3, 10)
    ws.set_tab_color(ROT)
    # Kopf
    ws.write_rich_string('B2', st.titel_rot, 'BÜ', st.titel, '-Reporting HSB4 K', st.titel)
    ws.write('B3', 'Makler-Bestandsübertragung · Rückstand, Bewegungen und Produktivität · Quellen: Rückstandsabzüge OPAG und Verbund (MIS-O), Anwesenheitsliste', st.untertitel)
    ws.merge_range('AT2:AY2', 'Stand', st.rechts_grau)
    ws.merge_range('AZ2:BF2', '', st.datum_gross)
    ws.write_formula('AZ2', '=Filter!O5', st.datum_gross)
    f_vor = wb.add_format({'font_name': FONT, 'font_size': 9, 'font_color': GRAU, 'align': 'right', 'num_format': 'dd.mm.yyyy'})
    ws.merge_range('AT3:AY3', '', f_vor)
    ws.write_formula('AT3', '=IF(Filter!O6="","",Filter!O6)', f_vor)
    ws.merge_range('AZ3:BF3', 'vorheriger Stichtag', st.untertitel)

    # KPI-Kacheln (Zeilen 5–9): Label, Wert, zwei Unterzeilen, Polster; je Kachel 7 Rasterspalten (182 px), Abstand 1 Spalte
    kacheln = [
        ('RÜCKSTAND OPAG', '=IF(Filter!$O$7=0,"",INDEX(Verlauf!$H$6:$H$%d,Filter!$O$7))' % MAX_VERLAUF,
         '=IF(Filter!$O$19="","–",IF(Filter!$O$19>0,"+","")&FIXED(Filter!$O$19,0)&" ggü. "&RIGHT("0"&DAY(Filter!$O$6),2)&"."&RIGHT("0"&MONTH(Filter!$O$6),2)&".")', 'Arbeitsgüter am Stichtag', 'Filter!$O$19'),
        ('RÜCKSTAND VERBUND', '=IF(Filter!$O$7=0,"",INDEX(Verlauf!$R$6:$R$%d,Filter!$O$7))' % MAX_VERLAUF,
         '=IF(Filter!$O$20="","–",IF(Filter!$O$20>0,"+","")&FIXED(Filter!$O$20,0)&" ggü. "&RIGHT("0"&DAY(Filter!$O$6),2)&"."&RIGHT("0"&MONTH(Filter!$O$6),2)&".")', 'Vorgänge am Stichtag', 'Filter!$O$20'),
        ('EINGÄNGE VERBUND', '=IF(Filter!$O$7=0,"",INDEX(Verlauf!$S$6:$S$%d,Filter!$O$7))' % MAX_VERLAUF,
         '=IF(Filter!$O$7=0,"","OPAG: "&FIXED(INDEX(Verlauf!$I$6:$I$%d,Filter!$O$7),0)&" Arbeitsgüter")' % MAX_VERLAUF, 'neue Vorgänge am Stichtag', None),
        ('ABGÄNGE VERBUND', '=IF(Filter!$O$7=0,"",INDEX(Verlauf!$T$6:$T$%d,Filter!$O$7))' % MAX_VERLAUF,
         '=IF(Filter!$O$7=0,"","OPAG: "&FIXED(INDEX(Verlauf!$J$6:$J$%d,Filter!$O$7),0)&" Arbeitsgüter")' % MAX_VERLAUF, 'abgearbeitet oder weitergeleitet', None),
        ('PRODUKTIVITÄT KW (VERBUND)', '=IF(Filter!$O$11=0,"",IFERROR(INDEX(KW!$Q$6:$Q$400,Filter!$O$11),""))',
         '=IF(Filter!$O$11=0,"","KV "&IFERROR(FIXED(INDEX(KW!$O$6:$O$400,Filter!$O$11),1),"–")&" · Komposit/Leben "&IFERROR(FIXED(INDEX(KW!$P$6:$P$400,Filter!$O$11),1),"–"))',
         '=IF(Filter!$O$11=0,"","Vorgänge je MAK · OPAG "&IFERROR(FIXED(INDEX(KW!$T$6:$T$400,Filter!$O$11),1),"–")&" je MAK")', None),
        ('MAK AKTUELLE KW', '=IF(Filter!$O$11=0,"",INDEX(KW!$N$6:$N$400,Filter!$O$11))',
         '=IF(Filter!$O$11=0,"","KV "&FIXED(INDEX(KW!$L$6:$L$400,Filter!$O$11),1)&" · Komposit/Leben "&FIXED(INDEX(KW!$M$6:$M$400,Filter!$O$11),1))',
         'laut Anwesenheitsplan', None),
    ]
    ws.set_row(4, 16)
    ws.set_row(5, 36)
    ws.set_row(6, 14)
    ws.set_row(7, 14)
    ws.set_row(8, 8)
    for i, (label, f_wert, f_sub1, f_sub2, delta_ref) in enumerate(kacheln):
        c0 = 8 + i * 8
        c1 = c0 + 6
        dez = i >= 4
        ws.merge_range(4, c0, 4, c1, label, st.kpi_label)
        ws.merge_range(5, c0, 5, c1, '', st.kpi_wert_dez if dez else st.kpi_wert)
        ws.write_formula(5, c0, f_wert, st.kpi_wert_dez if dez else st.kpi_wert)
        for zr, f_sub in ((6, f_sub1), (7, f_sub2)):
            ws.merge_range(zr, c0, zr, c1, '', st.kpi_sub_text)
            if f_sub.startswith('='):
                ws.write_formula(zr, c0, f_sub, st.kpi_sub_text)
            else:
                ws.write(zr, c0, f_sub, st.kpi_sub_text)
        ws.merge_range(8, c0, 8, c1, '', st.kpi_fill)
        if delta_ref:
            zelle = xl_rowcol_to_cell(6, c0)
            ws.conditional_format(zelle, {'type': 'formula', 'criteria': '=AND(%s<>"",%s>0)' % (delta_ref, delta_ref), 'format': wb.add_format({'font_color': GELBD, 'bold': True, 'bg_color': GELBH})})
            ws.conditional_format(zelle, {'type': 'formula', 'criteria': '=AND(%s<>"",%s<0)' % (delta_ref, delta_ref), 'format': wb.add_format({'font_color': GRUEN, 'bold': True, 'bg_color': GRUENH})})

    # ---------------- Filterpanel links (Spalten B–G): Buttons und Chips als Formen mit Makro
    B_VOLL, B_H = 246, 20
    knoepfe = []     # (row, col, text, makro, fuellung, breite, hoehe, name, schriftfarbe, fett, links, y_offset)
    chips = []       # (row, text, name, aktiv) – Zustand steht in Filter!C bzw. Filter!H/I
    reset_zellen = []  # (row, text, format): Zellen, die beim Ueberfahren den Hover zuruecksetzen
    ws.merge_range(4, 1, 4, 6, 'DATEN', st.filter_kopf)
    knoepfe.append((5, 1, 'Neue Daten laden', 'modLaden.NeueDatenLaden', ROT, B_VOLL, 26, 'BTN_Laden', WEISS, True, False, 5))
    knoepfe.append((6, 1, 'Anwesenheit laden', 'modLaden.AnwesenheitLaden', GRAUD, B_VOLL, B_H, 'BTN_Anwesenheit', WEISS, True, False, 4))
    ws.set_row(9, 22)
    ws.set_row(10, 4)
    ws.set_row(11, 22)
    ws.set_row(12, 8)
    knoepfe.append((9, 1, 'Anwesenheitsplan öffnen', 'modCockpit.PlanungOeffnen', TEALD, B_VOLL, B_H, 'BTN_Planung', WEISS, True, False, 1))
    knoepfe.append((11, 1, 'PowerPoint-Folie erzeugen', 'modPPT.NachPowerPoint', ROTD, B_VOLL, B_H, 'BTN_PPT', WEISS, True, False, 1))
    r = 13
    ws.merge_range(r, 1, r, 6, 'SPARTEN', st.filter_kopf)
    reset_zellen.append((r, 'SPARTEN', st.filter_kopf))
    ws.set_row(r, 18)
    sp_start = r + 1
    for i, sp in enumerate(['Komposit', 'Leben', 'KV', 'Sonstige']):
        ws.set_row(sp_start + i, 17)
        chips.append((sp_start + i, sp, 'SP_%d' % (i + 1), True))
    r = sp_start + 4
    ws.set_row(r, 6)
    knoepfe.append((r + 1, 1, 'Alle Sparten', 'modCockpit.FilterAlleSparten', GRAUM, B_VOLL, B_H, 'BTN_SPAlle', WEISS, True, False, 1))
    ws.set_row(r + 1, 18)
    ws.set_row(r + 2, 8)
    r = r + 3
    ws.merge_range(r, 1, r, 6, 'THEMENPOSTKÖRBE', st.filter_kopf)
    reset_zellen.append((r, 'THEMENPOSTKÖRBE', st.filter_kopf))
    ws.set_row(r, 18)
    pk_start = r + 1
    for i in range(10):
        ws.set_row(pk_start + i, 17)
        if i < len(postkoerbe):
            chips.append((pk_start + i, postkoerbe[i], 'PK_%d' % (i + 1), postkoerbe[i] in POSTKOERBE_AKTIV))
    r = pk_start + 10
    ws.set_row(r, 6)
    knoepfe.append((r + 1, 1, 'Aktive Bearbeitung', 'modCockpit.FilterAktiveBearbeitung', TEALD, B_VOLL, B_H, 'BTN_PKAktiv', WEISS, True, False, 1))
    knoepfe.append((r + 3, 1, 'Alle Postkörbe', 'modCockpit.FilterAllePostkoerbe', GRAUM, B_VOLL, B_H, 'BTN_PKAlle', WEISS, True, False, 1))
    ws.set_row(r + 1, 18)
    ws.set_row(r + 2, 6)
    ws.set_row(r + 3, 18)
    ws.set_row(r + 4, 8)
    r = r + 5
    ws.merge_range(r, 1, r, 6, 'GEVO-TYPEN', st.filter_kopf)
    reset_zellen.append((r, 'GEVO-TYPEN', st.filter_kopf))
    ws.set_row(r, 18)
    r += 1
    ws.merge_range(r, 1, r, 6, '', st.dropdown)
    ws.write_formula(r, 1, '=Filter!$L$5', st.dropdown)
    ws.set_row(r, 18)
    r += 1
    ws.merge_range(r, 1, r, 6, 'Modus: Alle GeVo · Nur BÜ-Schlüssel · Manuelle Auswahl (Chips)', st.hinweis)
    reset_zellen.append((r, 'Modus: Alle GeVo · Nur BÜ-Schlüssel · Manuelle Auswahl (Chips)', st.hinweis))
    ws.set_row(r, 22)
    gv_start = r + 1
    for i in range(13):
        ws.set_row(gv_start + i, 17)
        if i < len(gevo_typen):
            chips.append((gv_start + i, gevo_typen[i], 'GV_%d' % (i + 1), True))
    chips.append((gv_start + 13, 'Alle übrigen GeVo-Typen', 'GV_14', True))
    ws.set_row(gv_start + 13, 17)
    r = gv_start + 14
    ws.set_row(r, 6)
    knoepfe.append((r + 1, 1, 'Nur BÜ-Schlüssel', 'modCockpit.FilterNurBUE', TEALD, B_VOLL, B_H, 'BTN_GVBUE', WEISS, True, False, 1))
    knoepfe.append((r + 3, 1, 'Alle GeVo', 'modCockpit.FilterAlleGeVo', GRAUM, B_VOLL, B_H, 'BTN_GVAlle', WEISS, True, False, 1))
    ws.set_row(r + 1, 18)
    ws.set_row(r + 2, 6)
    ws.set_row(r + 3, 18)
    ws.set_row(r + 4, 8)
    r = r + 5
    ws.merge_range(r, 1, r, 6, 'ANSICHT', st.filter_kopf)
    reset_zellen.append((r, 'ANSICHT', st.filter_kopf))
    ws.set_row(r, 18)
    knoepfe.append((r + 1, 1, 'Tagessicht · letzte 7 Stichtage', 'modCockpit.AnsichtTag', TEAL, B_VOLL, 17, 'ANS_Tag', WEISS, True, True, 1))
    knoepfe.append((r + 2, 1, 'Wochensicht · letzte 7 KW', 'modCockpit.AnsichtWoche', WEISS, B_VOLL, 17, 'ANS_Woche', GRAU, False, True, 1))
    ws.set_row(r + 1, 17)
    ws.set_row(r + 2, 17)
    ws.set_row(r + 3, 6)
    knoepfe.append((r + 4, 1, 'Aktualisieren', 'modCockpit.Aktualisieren', GRAUD, B_VOLL, B_H, 'BTN_Aktualisieren', WEISS, True, False, 1))
    knoepfe.append((r + 6, 1, 'Filter zurücksetzen', 'modCockpit.FilterZuruecksetzen', GRAUM, B_VOLL, B_H, 'BTN_Zurueck', WEISS, True, False, 1))
    knoepfe.append((r + 8, 1, 'Hilfe', 'modCockpit.Hilfe', GRAUM, B_VOLL, B_H, 'BTN_Hilfe', WEISS, True, False, 1))
    ws.set_row(r + 4, 18)
    ws.set_row(r + 5, 6)
    ws.set_row(r + 6, 18)
    ws.set_row(r + 7, 6)
    ws.set_row(r + 8, 18)
    ws.set_row(r + 9, 8)
    ws.merge_range(r + 10, 1, r + 15, 6, 'Chips: gefüllt = im Filter, weiß = ausgeblendet. Klick schaltet um. Eingänge = neue Schlüssel gegenüber dem vorherigen Stand, '
                                         'Abgänge = Schlüssel, die fehlen (abgearbeitet oder weitergeleitet). Produktivität = Abgänge je MAK in der KW. '
                                         'Werte, die nicht in ihr Segment passen, stehen mit Führungslinie neben der Säule.', st.hinweis)
    # Chips: Zellen mit HYPERLINK auf die Hover-Funktion (Mauszeiger darueber setzt Filter!Q1 = Chip-Nummer, bedingte Formate
    # zeichnen Zustand und Hover); der Klick landet in Worksheet_SelectionChange des Blatts und schaltet den Filter um.
    # Spalte A traegt die Chip-Nummer (weiss, unsichtbar), Kopfzeilen und Hinweise setzen den Hover zurueck (ChipHover(0)).
    f_chip = wb.add_format({'font_name': FONT, 'font_size': 8.5, 'font_color': GRAU, 'bg_color': WEISS, 'valign': 'vcenter', 'indent': 1,
                            'border': 1, 'border_color': GRAUL})
    f_id = wb.add_format({'font_color': WEISS, 'font_size': 6})
    cf_aktiv = wb.add_format({'bg_color': TEAL, 'font_color': WEISS, 'bold': True, 'border': 1, 'border_color': TEAL})
    cf_hover_aktiv = wb.add_format({'bg_color': TEALD, 'font_color': WEISS, 'bold': True, 'border': 1, 'border_color': TEALD})
    cf_hover_inaktiv = wb.add_format({'bg_color': TEALT, 'font_color': TEALD, 'bold': True, 'border': 1, 'border_color': TEAL})
    sp_formate = {}
    for (zr, text, nm, aktiv) in chips:
        art = nm.split('_')[0]
        nr = int(nm.split('_')[1]) + {'PK': 0, 'GV': 100, 'SP': 200}[art]
        zust = {'PK': 'Filter!$C$%d', 'GV': 'Filter!$I$%d', 'SP': 'Filter!$T$%d'}[art] % (4 + int(nm.split('_')[1]))
        if art == 'SP':                      # Sparten-Chips in der Farbe der Sparte (wie die Segmente der Diagramme)
            fs = FARBE_SPARTE[text]
            if fs not in sp_formate:
                sp_formate[fs] = (wb.add_format({'bg_color': fs, 'font_color': WEISS, 'bold': True, 'border': 1, 'border_color': fs}),
                                  wb.add_format({'bg_color': fs, 'font_color': WEISS, 'bold': True, 'border': 2, 'border_color': GRAUD}),
                                  wb.add_format({'bg_color': GRAUXL, 'font_color': fs, 'bold': True, 'border': 1, 'border_color': fs}))
            cf_a, cf_ha, cf_hi = sp_formate[fs]
        else:
            cf_a, cf_ha, cf_hi = cf_aktiv, cf_hover_aktiv, cf_hover_inaktiv
        ws.merge_range(zr, 1, zr, 6, '', f_chip)
        t = text.replace('"', '""')
        ws.write_formula(zr, 1, '=IFERROR(HYPERLINK(ChipHover(%d),"%s"),"%s")' % (nr, t, t), f_chip)     # ohne Makros bleibt der Text stehen
        ws.write_number(zr, 0, nr, f_id)
        zelle = xl_rowcol_to_cell(zr, 1)
        ws.conditional_format(zelle, {'type': 'formula', 'criteria': '=AND(Filter!$Q$1=%d,%s=TRUE)' % (nr, zust), 'format': cf_ha, 'stop_if_true': True})
        ws.conditional_format(zelle, {'type': 'formula', 'criteria': '=AND(Filter!$Q$1=%d,NOT(%s=TRUE))' % (nr, zust), 'format': cf_hi, 'stop_if_true': True})
        ws.conditional_format(zelle, {'type': 'formula', 'criteria': '=%s=TRUE' % zust, 'format': cf_a})
    for (zr, text, fmt) in reset_zellen:
        t = text.replace('"', '""')
        ws.write_formula(zr, 1, '=IFERROR(HYPERLINK(ChipHover(0),"%s"),"%s")' % (t, t), fmt)

    # ---------------- Diagramme rechts (ab Spalte I = 8): Raster mit 2 Spalten (je 25 Rasterspalten) oder voller Breite
    def naechste_zeile(zeile):
        # erste Zeile, ab der ein Diagramm unter dem Diagramm in 'zeile' (Titel, Untertitel, Diagramm ab zeile+2) Platz hat
        unten = px_zeile(ws, zeile + 2) + 4 + CHART_H + 10
        r = zeile + 2
        while px_zeile(ws, r) < unten:
            r += 1
        return r

    kopf_fmt = {}
    def chart_platz(zeile, spalte, titel, sub, chart, farbe=FARBE_NEUTRAL, voll=False):
        # Kachel mit farbiger Kopfleiste ("Bookmark": OPAG rot, Verbund petrol, uebrige grau), Untertitel und hellem Rahmen
        ende = (57 if voll else spalte + 24)
        if farbe not in kopf_fmt:
            kopf_fmt[farbe] = (wb.add_format({'font_name': FONT, 'font_size': 11, 'bold': True, 'font_color': WEISS, 'bg_color': farbe, 'valign': 'vcenter', 'indent': 1}),
                               wb.add_format({'font_name': FONT, 'font_size': 8, 'font_color': GRAU, 'bg_color': GRAUXL, 'valign': 'vcenter', 'indent': 1}))
        f_kopf, f_sub = kopf_fmt[farbe]
        ws.merge_range(zeile, spalte, zeile, ende, '', f_kopf)
        if titel.startswith('='):
            ws.write_formula(zeile, spalte, titel, f_kopf)
        else:
            ws.write(zeile, spalte, titel, f_kopf)
        ws.merge_range(zeile + 1, spalte, zeile + 1, ende, sub, f_sub)
        letzte = naechste_zeile(zeile) - 2
        for rr in range(zeile + 2, letzte + 1):
            ws.merge_range(rr, spalte, rr, ende, '', st.kpi_fill)
        nummer = chart_einfuegen(ws, zeile + 2, spalte, chart, {'x_offset': 10, 'y_offset': 6, 'object_position': 3})
        for g in GEOMETRIE:
            if 'datei' not in g:
                g['datei'] = 'xl/charts/chart%d.xml' % nummer

    def da(col):                      # Block A Rueckstand: immer 7 Zeilen
        return '=Diagrammdaten!$%s$4:$%s$10' % (col, col)

    def db(col):                      # Block B Bewegungen: immer 21 Zeilen
        return '=Diagrammdaten!$%s$13:$%s$33' % (col, col)

    k2 = ber['kw2']                   # Fenster von 7 Kalenderwochen, endet mit der KW des letzten Stichtags
    k1 = max(6, k2 - 6)
    k2 = k1 + 6

    def kwb(col):
        return '=KW!$%s$%d:$%s$%d' % (col, k1, col, k2)

    summen_label = lambda fmt, pos: {'value': True, 'position': pos, 'num_format': fmt, 'font': {**LABEL_FONT, 'color': GRAUD}}  # noqa: E731

    def stapel(q):
        ch = wb.add_chart({'type': 'column', 'subtype': 'stacked'})
        cols = {'OPAG': ['C', 'D', 'E', 'F'], 'Verbund': ['G', 'H', 'I', 'J']}[q]
        for sp, col in zip(['Komposit', 'Leben', 'KV'], cols):
            ch.add_series({'name': sp, 'categories': da('A'), 'values': da(col),
                           'fill': {'color': FARBE_SPARTE[sp]}, 'border': {'color': WEISS, 'width': 0.75}, 'gap': 100,
                           'data_labels': SEGMENT_LABEL()})
        ln = wb.add_chart({'type': 'line'})
        ln.add_series({'name': 'Gesamt', 'categories': da('A'), 'values': da(cols[3]), 'line': {'none': True}, 'marker': {'type': 'none'},
                       'data_labels': summen_label('#,##0;#,##0;', 'above')})
        # Badges: Veraenderung zur vorherigen Periode ueber der Summe (gruen = weniger, gelb = mehr, grau = gleich), Text aus der Zelle
        b0 = 16 + (0 if q == 'OPAG' else 5)
        text_col = xl_col_to_name(b0 + 4)
        for k, (nm, fuellung, schrift) in enumerate([('Delta weniger', GRUENH, GRUEN), ('Delta mehr', GELBH, GELBD), ('Delta gleich', GRAUXL, GRAUD)]):
            # unsichtbare Punktreihen; je Punkt eigene Schrift und Fuellung (Etikett mittig auf dem Punkt)
            badge_text = [{'value': '=Diagrammdaten!$%s$%d' % (text_col, 4 + t), 'font': {**LABEL_FONT, 'color': schrift},
                           'fill': {'color': fuellung}, 'border': {'none': True}} for t in range(7)]
            ln.add_series({'name': nm, 'categories': da('A'), 'values': da(xl_col_to_name(b0 + k)), 'line': {'none': True}, 'marker': {'type': 'none'},
                           'data_labels': {'value': True, 'position': 'center', 'custom': badge_text, 'font': {**LABEL_FONT, 'color': schrift},
                                           'fill': {'color': fuellung}, 'border': {'none': True}}})
        ln.add_series({'name': 'Achsenluft', 'categories': da('A'), 'values': da(xl_col_to_name(b0 + 3)), 'line': {'none': True}, 'marker': {'type': 'none'}})
        ch.combine(ln)
        chart_stil(ch, breite=CHART_B, hoehe=CHART_H)
        thinkcell(ch)
        ch.set_legend({'position': 'top', 'font': {'name': FONT, 'size': 8, 'color': GRAUD}, 'delete_series': [4, 5, 6, 7]})
        ch.set_plotarea({'border': {'none': True}, 'fill': {'none': True}, 'layout': PLOT_STAPEL})
        w = werte['rueckstand'][q]                                    # 7 Slots x [Ko, Le, KV] oder None
        ymax = achsen_ende(max([sum(s) for s in w if s] or [0]), 1.42)
        if ymax > 0:                                                  # feste Achse nur mit Daten (Excel-Makro stellt auf Automatik zurueck)
            ch.set_y_axis({'visible': False, 'major_gridlines': {'visible': False}, 'min': 0, 'max': ymax})
            texte = {}
            for t in range(1, 7):
                if w[t] and w[t - 1]:
                    texte['Diagrammdaten!$%s$%d' % (text_col, 4 + t)] = zahl_text(sum(w[t]) - sum(w[t - 1]), '+#,##0')
            GEOMETRIE.append({'kennung': 'Diagrammdaten!$%s$4:$%s$10' % (cols[0], cols[0]), 'art': 'saeulen', 'b': CHART_B, 'h': CHART_H,
                          'layout': PLOT_STAPEL, 'gap': 100, 'werte': w, 'ymin': 0, 'ymax': ymax, 'formate': ['#,##0'] * 3, 'texte': texte})
        return ch

    def bewegung(q):
        ch = wb.add_chart({'type': 'column', 'subtype': 'stacked'})
        basis = 2 + (0 if q == 'OPAG' else 14)
        kat = db('A')
        fmt = ['#,##0;#,##0;', '#,##0;#,##0;', '+#,##0;-#,##0;']
        for k, art in enumerate(['Eingänge', 'Abgänge', 'Delta']):
            for si, sp in enumerate(['Komposit', 'Leben', 'KV']):
                col = xl_col_to_name(basis + k * 3 + si)
                ch.add_series({'name': sp if k == 0 else '%s %s' % (art, sp), 'categories': kat, 'values': db(col),
                               'fill': {'color': FARBE_SPARTE[sp]}, 'border': {'color': WEISS, 'width': 0.75}, 'gap': 110,
                               'data_labels': SEGMENT_LABEL(fmt[k])})
        ln = wb.add_chart({'type': 'line'})
        text_col = xl_col_to_name(basis + 13)
        verknuepft = [({'value': '=Diagrammdaten!$%s$%d' % (text_col, 13 + t), 'font': {**LABEL_FONT, 'color': GRAUD}} if t % 3 == 2 else None) for t in range(21)]
        for k, (name, fmtk, pos) in enumerate([('Σ Eingänge', '#,##0;#,##0;', 'above'), ('Σ Abgänge', '#,##0;#,##0;', 'below'),
                                               ('Σ Delta', '+#,##0;-#,##0;±0', 'above'), ('Σ Delta negativ', '+#,##0;-#,##0;', 'below')]):
            col = xl_col_to_name(basis + 9 + k)
            lab = summen_label(fmtk, pos)
            if k >= 2:
                lab['custom'] = verknuepft          # Text der Delta-Summe aus der Zelle (Stapel mit gemischten Vorzeichen)
            ln.add_series({'name': name, 'categories': kat, 'values': db(col), 'line': {'none': True}, 'marker': {'type': 'none'}, 'data_labels': lab})
        ch.combine(ln)
        chart_stil(ch, breite=CHART_B_VOLL, hoehe=CHART_H)
        thinkcell(ch)
        ch.set_legend({'position': 'top', 'font': {'name': FONT, 'size': 8, 'color': GRAUD}, 'delete_series': list(range(3, 13))})
        ch.set_plotarea({'border': {'none': True}, 'fill': {'none': True}, 'layout': PLOT_BEWEG})
        ch.set_x_axis({'num_font': {'name': FONT, 'size': 8, 'color': GRAU}, 'line': {'color': GRAUL, 'width': 0.75}, 'major_gridlines': {'visible': False},
                       'major_tick_mark': 'none', 'label_position': 'low'})
        w = werte['bewegung'][q]                                      # 21 Slots x 9 Reihen (None = #NV)
        hoch = max([sum(x for x in s if x and x > 0) for s in w] or [0])
        tief = max([-sum(x for x in s if x and x < 0) for s in w] or [0])
        ymax, ymin = achsen_ende(hoch), -achsen_ende(tief)
        col0 = xl_col_to_name(basis)
        if ymax > 0 or ymin < 0:
            ch.set_y_axis({'visible': False, 'major_gridlines': {'visible': False}, 'min': ymin, 'max': ymax})
            GEOMETRIE.append({'kennung': 'Diagrammdaten!$%s$13:$%s$33' % (col0, col0), 'art': 'saeulen', 'b': CHART_B_VOLL, 'h': CHART_H,
                          'layout': PLOT_BEWEG, 'gap': 110, 'werte': w, 'ymin': ymin, 'ymax': ymax, 'formate': ['#,##0'] * 6 + ['+#,##0'] * 3,
                          'texte': {'Diagrammdaten!$%s$%d' % (text_col, 13 + t): zahl_text(sum(x for x in w[t][6:9] if x), '+#,##0') for t in range(2, 21, 3) if w[t][6] is not None}})
        return ch

    zeitraum = 'IF(Filter!$L$9="Woche"," · letzte 7 Kalenderwochen (Stand Wochenende)"," · letzte 7 Stichtage")'
    z1 = 14
    ws.set_row(z1, 20)
    chart_platz(z1, 8, '="Rückstand OPAG im Verlauf"&%s' % zeitraum, 'Arbeitsgüter nach Sparte, Summe über der Säule · nach aktivem Filter · neueste Periode rechts', stapel('OPAG'), FARBE_OPAG)
    chart_platz(z1, 33, '="Rückstand Verbund im Verlauf"&%s' % zeitraum, 'Vorgänge nach Sparte, Summe über der Säule · nach aktivem Filter · neueste Periode rechts', stapel('Verbund'), FARBE_VERBUND)
    z2 = naechste_zeile(z1)
    ws.set_row(z2, 20)
    chart_platz(z2, 8, '="Eingänge, Abgänge und Delta OPAG nach Sparte"&%s' % zeitraum,
                'je Periode drei Säulen: Eingänge (neue Schlüssel) über der Achse, Abgänge (abgearbeitet oder weitergeleitet) unter der Achse, Delta = Eingänge minus Abgänge · nach aktivem Filter', bewegung('OPAG'), FARBE_OPAG, True)
    z3 = naechste_zeile(z2)
    ws.set_row(z3, 20)
    chart_platz(z3, 8, '="Eingänge, Abgänge und Delta Verbund nach Sparte"&%s' % zeitraum,
                'je Periode drei Säulen: Eingänge über der Achse, Abgänge unter der Achse, Delta = Eingänge minus Abgänge je Sparte · nach aktivem Filter', bewegung('Verbund'), FARBE_VERBUND, True)
    z4 = naechste_zeile(z3)
    ws.set_row(z4, 20)
    mak = wb.add_chart({'type': 'column', 'subtype': 'stacked'})
    mak.add_series({'name': 'Gesundheit (KV)', 'categories': kwb('C'), 'values': kwb('L'), 'fill': {'color': ROT}, 'border': {'color': WEISS, 'width': 0.75}, 'gap': 55,
                    'data_labels': SEGMENT_LABEL('0.0;0.0;')})
    mak.add_series({'name': 'Komposit/Leben', 'categories': kwb('C'), 'values': kwb('M'), 'fill': {'color': TEAL}, 'border': {'color': WEISS, 'width': 0.75},
                    'data_labels': SEGMENT_LABEL('0.0;0.0;')})
    mak_ln = wb.add_chart({'type': 'line'})
    mak_ln.add_series({'name': 'Gesamt', 'categories': kwb('C'), 'values': kwb('N'), 'line': {'none': True}, 'marker': {'type': 'none'},
                       'data_labels': summen_label('0.0;0.0;', 'above')})
    mak.combine(mak_ln)
    chart_stil(mak, y_format='0.0', breite=CHART_B, hoehe=CHART_H)
    thinkcell(mak)
    chart_platz(z4, 8, 'Kapazität je Kalenderwoche (MAK)', 'wirksame MAK laut Anwesenheitsplan (Blatt Planung) · Gesundheit und Komposit/Leben · letzte 7 KW bis zur KW des letzten Stichtags', mak)

    alter = wb.add_chart({'type': 'bar', 'subtype': 'percent_stacked'})
    for i, t in enumerate(['0–7 Tage', '8–30 Tage', '31–90 Tage', 'über 90 Tage']):
        col = xl_col_to_name(14 + i)
        alter.add_series({'name': t, 'categories': '=Filter!$N$15:$N$16', 'values': '=Filter!$%s$15:$%s$16' % (col, col),
                          'fill': {'color': FARBE_ALTER[i]}, 'border': {'color': WEISS, 'width': 1}, 'gap': 60,
                          'data_labels': {'value': True, 'num_format': '#,##0;#,##0;', 'font': {'name': FONT, 'size': 8, 'color': SW if i < 2 else WEISS}}})
    chart_stil(alter, y_format='0%', breite=CHART_B, hoehe=CHART_H)
    alter.set_x_axis({'visible': False, 'major_gridlines': {'visible': False}})
    alter.set_y_axis({'num_font': {'name': FONT, 'size': 9, 'color': GRAUD, 'bold': True}, 'line': {'none': True},
                      'major_gridlines': {'visible': False}, 'major_tick_mark': 'none', 'reverse': True})
    alter.set_plotarea({'border': {'none': True}, 'fill': {'none': True}, 'layout': PLOT_ALTER})
    GEOMETRIE.append({'kennung': 'Filter!$O$15:$O$16', 'art': 'balken_prozent', 'b': CHART_B, 'h': CHART_H, 'layout': PLOT_ALTER, 'gap': 60,
                      'werte': werte['alter'], 'formate': ['#,##0'] * 4, 'dunkel': 2})
    chart_platz(z4, 33, 'Altersstruktur des Rückstands', 'Anteil je Altersklasse am aktuellen Stichtag · nach aktivem Filter', alter)

    z5 = naechste_zeile(z4)
    ws.set_row(z5, 20)

    def produktivitaet(cols):
        ch = wb.add_chart({'type': 'column'})
        ch.add_series({'name': 'KV', 'categories': kwb('C'), 'values': kwb(cols[0]), 'fill': {'color': ROT}, 'border': {'none': True}, 'gap': 80, 'overlap': -10,
                       'data_labels': {'value': True, 'position': 'inside_end', 'num_format': '0.0', 'font': {**LABEL_FONT, 'color': WEISS}}})
        ch.add_series({'name': 'Komposit/Leben', 'categories': kwb('C'), 'values': kwb(cols[1]), 'fill': {'color': TEAL}, 'border': {'none': True},
                       'data_labels': {'value': True, 'position': 'inside_end', 'num_format': '0.0', 'font': {**LABEL_FONT, 'color': WEISS}}})
        ln = wb.add_chart({'type': 'line'})
        ln.add_series({'name': 'Gesamt', 'categories': kwb('C'), 'values': kwb(cols[2]), 'line': {'color': SW, 'width': 2.25},
                       'marker': {'type': 'circle', 'size': 7, 'fill': {'color': SW}, 'border': {'color': WEISS}},
                       'data_labels': {'value': True, 'position': 'above', 'num_format': '0.0', 'font': {**LABEL_FONT, 'color': SW}}})
        ch.combine(ln)
        chart_stil(ch, y_format='0.0', breite=CHART_B, hoehe=CHART_H)
        thinkcell(ch)
        return ch
    chart_platz(z5, 8, 'Produktivität je Vorgang (Verbund)', 'Abgänge je MAK in der KW: KV gegen MAK Gesundheit, Komposit/Leben gegen MAK Komposit, Gesamt als Linie',
                produktivitaet(['O', 'P', 'Q']))
    chart_platz(z5, 33, 'Produktivität je Arbeitsgut (OPAG)', 'gleiche Logik auf Ebene der Arbeitsgüter (mehrere je Vorgang möglich) · laufende KW bis zum letzten Stichtag',
                produktivitaet(['R', 'S', 'T']))
    z6 = naechste_zeile(z5)
    ws.set_row(z6, 20)
    pk = wb.add_chart({'type': 'bar'})
    pk_end = 4 + ber['n_pk']
    pk.add_series({'name': 'Verbund', 'categories': '=Filter!$B$5:$B$%d' % pk_end, 'values': '=Filter!$D$5:$D$%d' % pk_end, 'fill': {'color': TEALD}, 'border': {'none': True}, 'gap': 40,
                   'data_labels': {'value': True, 'num_format': '#,##0', 'font': {'name': FONT, 'size': 8, 'color': GRAUD}}})
    pk.add_series({'name': 'OPAG', 'categories': '=Filter!$B$5:$B$%d' % pk_end, 'values': '=Filter!$E$5:$E$%d' % pk_end, 'fill': {'color': TEALL}, 'border': {'none': True}})
    chart_stil(pk, breite=CHART_B, hoehe=CHART_H)
    pk.set_x_axis({'num_font': {'name': FONT, 'size': 8, 'color': GRAU}, 'num_format': '#,##0', 'line': {'none': True}, 'major_tick_mark': 'none',
                   'major_gridlines': {'visible': True, 'line': {'color': GRAUXL, 'width': 0.75}}})
    pk.set_y_axis({'num_font': {'name': FONT, 'size': 8, 'color': GRAUD}, 'line': {'none': True}, 'major_tick_mark': 'none', 'reverse': True,
                   'major_gridlines': {'visible': False}})
    chart_platz(z6, 8, 'Rückstand je Themenpostkorb', 'aktueller Stichtag, ohne Filter · zeigt, was die Chips links ein- oder ausschließen', pk)
    ws.merge_range(z6 + 19, 8, z6 + 19, 57, '', st.hinweis)
    ws.write_formula(z6 + 19, 8, '=IF(Filter!$O$21<>"",Filter!$O$21,"Diagramme aktualisieren sich mit jeder Änderung der Filter. „Neue Daten laden“ ergänzt Stichtage; ein Stichtag wird je Quelle nur einmal geladen (Ladeprotokoll). '
                                 'Leere Slots rechts oder links bleiben frei, bis Stichtage bzw. Kalenderwochen vorliegen.")', st.hinweis)

    # Schaltflaechen als Textfelder (Makro wird nach dem Schreiben in der Zeichnung eingetragen)
    for (zr, zc, text, makro, farbe, breite, hoehe, nm, schrift, fett, links, yoff) in knoepfe:
        ws.insert_textbox(zr, zc, text, {'width': breite, 'height': hoehe, 'x_offset': 2 if zc == 1 else 4, 'y_offset': yoff, 'object_position': 3,
                                         'fill': {'color': farbe}, 'line': ({'color': GRAUL, 'width': 0.75} if farbe == WEISS else {'none': True}),
                                         'font': {'name': FONT, 'size': 8.5 if links else 9, 'bold': fett, 'color': schrift},
                                         'align': {'vertical': 'middle', 'horizontal': 'left' if links else 'center'}})
    ws.set_landscape()
    ws.set_paper(8)                 # A3
    ws.fit_to_pages(1, 1)
    ws.print_area(0, 0, z6 + 20, 58)
    ws.set_margins(0.3, 0.3, 0.3, 0.3)
    ws.activate()
    ws.set_first_sheet()
    global KNOEPFE_LISTEN, WS_COCKPIT
    KNOEPFE_LISTEN, WS_COCKPIT = [knoepfe, KNOEPFE_PLANUNG], ws


# ------------------------------------------------------------------ Werte fuer die Etikettengeometrie (gleiche Filter wie die Vorbelegung: aktive Postkoerbe, alle GeVo)
def cockpit_werte(fakten, stichtage):
    aktiv = [z for z in fakten if z[4] in POSTKOERBE_AKTIV]
    tage = sorted(stichtage)
    slots = [None] * (7 - min(7, len(tage))) + tage[-7:]
    sparten = ['Komposit', 'Leben', 'KV']

    def summe(tag, q, sp, feld):
        return sum(z[feld] for z in aktiv if z[0] == tag and z[1] == q and z[2] == sp)
    rueck, beweg, alter = {}, {}, []
    for q in ('OPAG', 'Verbund'):
        rueck[q] = [[summe(t, q, sp, 8) for sp in sparten] if t else None for t in slots]
        reihen = []
        for t in slots:
            for art in range(3):
                zeile = [None] * 9
                if t:
                    for si, sp in enumerate(sparten):
                        e, a = summe(t, q, sp, 9), summe(t, q, sp, 10)
                        zeile[art * 3 + si] = [e, -a, e - a][art]
                reihen.append(zeile)
        beweg[q] = reihen
        if tage:
            alter.append([sum(z[11 + k] for z in aktiv if z[0] == tage[-1] and z[1] == q) for k in range(4)])
        else:
            alter.append([0, 0, 0, 0])
    return {'rueckstand': rueck, 'bewegung': beweg, 'alter': alter}


# ------------------------------------------------------------------ Etiketten schmaler Segmente neben die Saeule (think-cell-Art) – Zustand beim Bau; in Excel setzt modCockpit.EtikettenAuslagern nach
LABEL_H = 13.0            # Hoehe eines Etiketts in Pixel (8 pt fett)
LABEL_ABSTAND = 5.0       # Abstand Etikett - Saeule


def label_breite(text):
    return 4 + 5.6 * len(text)


def zahl_text(v, fmt):
    if fmt.endswith(','):                                   # Tausender-Skalierung ("#,##0.0,")
        return '{:.1f}'.format(abs(v) / 1000.0).replace('.', ',')
    s = '{:,.0f}'.format(abs(v)).replace(',', '.')
    if fmt.startswith('+'):
        return ('+' if v > 0 else '-' if v < 0 else '±') + s
    return s


def etiketten_saeulen(g):
    """Liefert je (Reihe, Punkt) den Versatz (dx, dy) als Anteil der Diagrammflaeche fuer Segmente, in die das Etikett nicht passt."""
    b, h, lo = g['b'], g['h'], g['layout']
    x0, y0, pw, ph = b * lo['x'], h * lo['y'], b * lo['width'], h * lo['height']
    werte = g['werte']
    n = len(werte)
    ymin, ymax = g['ymin'], g['ymax']
    if ymax <= ymin:
        return []
    px = lambda v: y0 + ph * (ymax - v) / (ymax - ymin)  # noqa: E731
    label_h, zeichen = g.get('label_h', LABEL_H), g.get('zeichen', 5.6)
    kat_b = pw / n
    col_b = kat_b / (1 + g['gap'] / 100.0)
    aus = []
    for i, zeile in enumerate(werte):
        if not zeile:
            continue
        xm = x0 + kat_b * (i + 0.5)
        oben, unten = 0.0, 0.0
        links = (i < n - 1)              # letzte Saeule: rechts beginnen, dort ist der Rand frei
        letzte = {'L': None, 'R': None}
        for s, v in enumerate(zeile):
            if v is None or v == 0:
                continue
            if v > 0:
                y_a, y_b = px(oben + v), px(oben)
                oben += v
            else:
                y_a, y_b = px(unten), px(unten + v)
                unten += v
            seg_h = y_b - y_a
            text = zahl_text(v, g['formate'][s])
            lw = 4 + zeichen * len(text)
            if seg_h >= label_h + 1 and col_b >= lw + 2:
                continue
            ym = (y_a + y_b) / 2
            seite = 'L' if links else 'R'
            links = not links
            prev = letzte[seite]
            if prev is not None and abs(ym - prev) < label_h + 1:
                ym = prev - (label_h + 1) if ym <= prev else prev + (label_h + 1)
            letzte[seite] = ym
            if seite == 'L':
                xl = xm - col_b / 2 - LABEL_ABSTAND - lw / 2
            else:
                xl = xm + col_b / 2 + LABEL_ABSTAND + lw / 2
            aus.append((s, i, (xl - xm) / b, (ym - (y_a + y_b) / 2) / h))
    return aus


def etiketten_balken_prozent(g):
    """Prozent-gestapelte Balken (Altersstruktur): zu schmale Segmente bekommen ihr Etikett ueber den Balken."""
    b, h, lo = g['b'], g['h'], g['layout']
    x0, y0, pw, ph = b * lo['x'], h * lo['y'], b * lo['width'], h * lo['height']
    werte = g['werte']
    n = len(werte)
    kat_h = ph / n
    bal_h = kat_h / (1 + g['gap'] / 100.0)
    aus = []
    for i, zeile in enumerate(werte):          # Kategorie 0 steht oben (Achse umgekehrt)
        tot = float(sum(zeile)) or 1.0
        x = x0
        ym = y0 + kat_h * (i + 0.5)
        letzte = None
        for s, v in enumerate(zeile):
            w = pw * v / tot
            xm = x + w / 2
            x += w
            if v == 0:
                continue
            lw = label_breite(zahl_text(v, g['formate'][s]))
            if w >= lw + 2:
                continue
            xl = xm
            if letzte is not None and abs(xl - letzte) < lw + 2:
                xl = letzte + lw + 2
            letzte = xl
            aus.append((s, i, (xl - xm) / b, (-(bal_h / 2) - LABEL_H / 2 - 3) / h))
    return aus


def etiketten_eintragen(text, g):
    """Traegt fuer ein Diagramm-XML die versetzten Etiketten und die Fuehrungslinien ein."""
    versatz = etiketten_saeulen(g) if g['art'] == 'saeulen' else etiketten_balken_prozent(g)
    print('Etiketten neben der Säule:', g.get('datei'), [(s_, i_) for s_, i_, _dx, _dy in versatz])
    if not versatz:
        return text
    teile = re.split(r'(?=<c:ser>)', text)
    je_reihe = {}
    for s, i, dx, dy in versatz:
        je_reihe.setdefault(s, []).append((i, dx, dy))
    ext = ('<c:extLst><c:ext uri="{CE6537A1-D6FC-4f65-9D91-7224C49458BB}" xmlns:c15="http://schemas.microsoft.com/office/drawing/2012/chart">'
           '<c15:showLeaderLines val="1"/><c15:leaderLines><c:spPr><a:ln w="6350" cap="flat"><a:solidFill><a:srgbClr val="9AA3AD"/></a:solidFill></a:ln></c:spPr></c15:leaderLines>'
           '</c:ext></c:extLst>')
    reihe = 0
    for k, teil in enumerate(teile):
        if not teil.startswith('<c:ser>'):
            continue
        if reihe in je_reihe:
            m = re.search(r'<c:dLbls>(.*?)</c:dLbls>', teil, re.S)
            if m:
                inhalt = m.group(1)
                numfmt = re.search(r'<c:numFmt [^>]*/>', inhalt)
                txpr = re.search(r'<c:txPr>.*?</c:txPr>', inhalt, re.S)
                dunkel = g.get('dunkel', 0)
                lbls = ''
                for i, dx, dy in je_reihe[reihe]:
                    tx = txpr.group(0) if txpr else ''
                    if reihe >= dunkel or g['art'] == 'saeulen':
                        tx = re.sub(r'<a:srgbClr val="[0-9A-Fa-f]{6}"/>', '<a:srgbClr val="4A4A4A"/>', tx)
                    lbls += ('<c:dLbl><c:idx val="%d"/><c:layout><c:manualLayout><c:x val="%.5f"/><c:y val="%.5f"/></c:manualLayout></c:layout>%s<c:spPr><a:noFill/><a:ln><a:noFill/></a:ln></c:spPr>%s'
                             '<c:showLegendKey val="0"/><c:showVal val="1"/><c:showCatName val="0"/><c:showSerName val="0"/><c:showPercent val="0"/><c:showBubbleSize val="0"/></c:dLbl>'
                             % (i, dx, dy, numfmt.group(0) if numfmt else '', tx))
                neu = '<c:dLbls>' + lbls + inhalt + ext + '</c:dLbls>'
                teil = teil[:m.start()] + neu + teil[m.end():]
                teile[k] = teil
        reihe += 1
    return ''.join(teile)


# ------------------------------------------------------------------ Anwesenheitstool: Mitarbeiter (Stammdaten), Planung (Matrix je KW), Wirksam (berechnet, versteckt)
MA_ZEILEN = 60            # reservierte Mitarbeiterzeilen
MA_START = 5              # erste Datenzeile im Blatt Mitarbeiter (1-basiert)
PL_START = 7              # erste Mitarbeiterzeile in Planung/Wirksam (1-basiert); Kopf: 4 Monat, 5 KW, 6 Montag/Schluessel
PL_SPALTE0 = 3            # erste Wochenspalte (0-basiert: D)
MONATE_DE = ['Januar', 'Februar', 'März', 'April', 'Mai', 'Juni', 'Juli', 'August', 'September', 'Oktober', 'November', 'Dezember']


def montag(jahr, kw):
    d = dt.date(jahr, 1, 4)
    d = d - dt.timedelta(days=d.isoweekday() - 1)
    return d + dt.timedelta(weeks=kw - 1)


def anwesenheit_blaetter(wb, ws_m, ws_p, ws_w, st, kw_liste, anwesenheit, anw_datei):
    n_kw = len(kw_liste)
    c_end = PL_SPALTE0 + n_kw - 1                       # letzte Wochenspalte (0-basiert)
    wochen_bereich = '$%s$%d:$%s$%d' % (xl_col_to_name(PL_SPALTE0), PL_START, xl_col_to_name(c_end), PL_START + MA_ZEILEN - 1)
    schluessel_zeile = '$%s$6:$%s$6' % (xl_col_to_name(PL_SPALTE0), xl_col_to_name(c_end))
    f = lambda **k: wb.add_format({'font_name': FONT, 'font_size': 9, 'valign': 'vcenter', **k})  # noqa: E731
    f_kopf_monat = f(bold=True, font_color=GRAUD, bg_color=GRAUXL, left=1, left_color=GRAUL)
    f_kopf_kw = f(bold=True, font_color=WEISS, bg_color=GRAUD, align='center')
    f_kopf_mo = f(font_size=7, font_color=GRAU, align='center', num_format='dd.mm.', bg_color=GRAUXL)
    f_name = f(bold=True)
    f_zelle = f(align='center', num_format='0.0', border=1, border_color=GRAUXL)
    f_kap = f(align='center', num_format='0.0', font_color=GRAU)
    f_sparte = f(font_color=GRAU)
    f_summe = f(bold=True, align='center', num_format='0.0', top=1, top_color=GRAUL)
    f_summe_label = f(bold=True, top=1, top_color=GRAUL)
    f_eingabe = f(font_color='#0000FF', bg_color='#FFF9DB', border=1, border_color=GRAUL)
    f_eingabe_dez = f(font_color='#0000FF', bg_color='#FFF9DB', border=1, border_color=GRAUL, num_format='0.0', align='center')
    f_eingabe_dat = f(font_color='#0000FF', bg_color='#FFF9DB', border=1, border_color=GRAUL, num_format='dd.mm.yyyy', align='center')
    f_eingabe_bool = f(font_color='#0000FF', bg_color='#FFF9DB', border=1, border_color=GRAUL, align='center')

    # ---------------- Mitarbeiter (Stammdaten): A Name, B Einheit, C Sparte, D Kapazitaet, E Eintritt, F Austritt, G Aktiv, H Bemerkung
    ws_m.set_column('A:A', 22)
    ws_m.set_column('B:B', 12)
    ws_m.set_column('C:C', 12)
    ws_m.set_column('D:D', 14)
    ws_m.set_column('E:F', 12)
    ws_m.set_column('G:G', 8)
    ws_m.set_column('H:H', 40)
    ws_m.set_tab_color(TEAL)
    ws_m.write('A1', 'Mitarbeiter (Stammdaten für Anwesenheit und Produktivität)', st.titel)
    ws_m.write('A2', 'Neue Mitarbeitende: nächste freie Zeile ausfüllen (Name, Sparte, Kapazität). Sie erscheinen sofort in der Planung. '
                     'Austritt: Datum eintragen oder Aktiv = FALSCH. Kapazität = MAK je Woche bei voller Anwesenheit (1,0 = Vollzeit, 0,5 = halbe Stelle).', st.untertitel)
    for c, t in enumerate(['Mitarbeiter', 'Einheit', 'Sparte', 'Kapazität (MAK/Woche)', 'Eintritt', 'Austritt', 'Aktiv (leer = ja)', 'Bemerkung']):
        ws_m.write(MA_START - 2, c, t, st.kopf)
    ws_m.set_row(MA_START - 2, 30)
    stamm, wochen = v.mitarbeiter_aus_anwesenheit(anwesenheit)
    for i in range(MA_ZEILEN):
        r = MA_START - 1 + i
        if i < len(stamm):
            name, einheit, sparte, kap = stamm[i]
            ws_m.write(r, 0, name, f_eingabe)
            ws_m.write(r, 1, einheit, f_eingabe)
            ws_m.write(r, 2, sparte, f_eingabe)
            ws_m.write_number(r, 3, kap, f_eingabe_dez)
            ws_m.write_boolean(r, 6, True, f_eingabe_bool)
        else:
            ws_m.write_blank(r, 0, None, f_eingabe)
            ws_m.write_blank(r, 1, None, f_eingabe)
            ws_m.write_blank(r, 2, None, f_eingabe)
            ws_m.write_blank(r, 3, None, f_eingabe_dez)
            ws_m.write_blank(r, 6, None, f_eingabe_bool)
        ws_m.write_blank(r, 4, None, f_eingabe_dat)
        ws_m.write_blank(r, 5, None, f_eingabe_dat)
        ws_m.write_blank(r, 7, None, f_eingabe)
    ws_m.data_validation(MA_START - 1, 2, MA_START - 2 + MA_ZEILEN, 2, {'validate': 'list', 'source': ['Gesundheit', 'Komposit'],
                                                                           'input_title': 'Sparte', 'input_message': 'Gesundheit = KV, Komposit = Komposit/Leben'})
    ws_m.data_validation(MA_START - 1, 6, MA_START - 2 + MA_ZEILEN, 6, {'validate': 'list', 'source': ['WAHR', 'FALSCH']})
    ws_m.data_validation(MA_START - 1, 3, MA_START - 2 + MA_ZEILEN, 3, {'validate': 'decimal', 'criteria': 'between', 'minimum': 0, 'maximum': 1.5,
                                                                           'input_title': 'Kapazität', 'input_message': 'MAK je Woche bei voller Anwesenheit, 0 bis 1,5'})
    ws_m.write('J4', 'Import', st.abschnitt_klein)
    ws_m.write('J5', 'Letzte MAK-Liste', st.zelle)
    ws_m.write('K5', anw_datei, st.zelle)
    ws_m.write('J6', 'Importiert am', st.zelle)
    if anw_datei:
        ws_m.write_datetime('K6', dt.datetime.now(), st.zelle_datzeit)
    ws_m.set_column('J:J', 16)
    ws_m.set_column('K:K', 40)
    ws_m.freeze_panes(MA_START - 1, 1)

    # ---------------- Planung (Eingabematrix) und Wirksam (berechnete MAK je Mitarbeiter und KW)
    for ws in (ws_p, ws_w):
        ws.set_column('A:A', 20)
        ws.set_column('B:B', 10)
        ws.set_column('C:C', 7)
        ws.set_column(PL_SPALTE0, c_end, 6.2)
        ws.freeze_panes(PL_START - 1, PL_SPALTE0)
    ws_p.set_tab_color(TEAL)
    ws_p.write('A2', 'Anwesenheitsplan (MAK je Mitarbeiter und Kalenderwoche)', st.titel)
    ws_p.write('A3', 'Leer = anwesend mit Kapazität · U = Urlaub · K = krank · F = Fortbildung/sonstige Abwesenheit · H = halbe Woche · Zahl = MAK dieser Woche. '
                     'Vergangene Wochen grau, aktuelle Woche hervorgehoben. Mitarbeitende werden im Blatt „Mitarbeiter“ gepflegt.', st.untertitel)
    ws_p.write('A4', 'Monat', f_kopf_monat)
    ws_p.write('A5', 'Kalenderwoche', f_kopf_kw)
    ws_p.write('A6', 'Montag', f_kopf_mo)
    ws_p.write('B4', '', f_kopf_monat)
    ws_p.write('B5', 'Sparte', f_kopf_kw)
    ws_p.write('B6', '', f_kopf_mo)
    ws_p.write('C4', '', f_kopf_monat)
    ws_p.write('C5', 'Kap.', f_kopf_kw)
    ws_p.write('C6', '', f_kopf_mo)
    ws_w.write('A1', 'Wirksame MAK je Mitarbeiter und KW (berechnet aus Mitarbeiter und Planung; Grundlage für KW!L:N)', st.untertitel)
    ws_w.write('A6', 'Schlüssel Jahr*100+KW', st.zelle)
    ws_w.write('A5', 'Montag', st.zelle)
    letzter_monat = None
    for i, (j, k) in enumerate(kw_liste):
        c = PL_SPALTE0 + i
        mo = montag(j, k)
        label = '%s %s' % (MONATE_DE[mo.month - 1][:3], str(j)[2:]) if (mo.year, mo.month) != letzter_monat else ''
        letzter_monat = (mo.year, mo.month)
        ws_p.write(3, c, label, f_kopf_monat if label else f(bg_color=GRAUXL))
        ws_p.write(4, c, 'KW %d' % k, f_kopf_kw)
        ws_p.write_datetime(5, c, dt.datetime(mo.year, mo.month, mo.day), f_kopf_mo)
        ws_w.write_datetime(4, c, dt.datetime(mo.year, mo.month, mo.day), st.zelle_dat)
        ws_w.write_number(5, c, j * 100 + k, st.zelle_zahl)
    kw_index = {jk: i for i, jk in enumerate(kw_liste)}
    for i in range(MA_ZEILEN):
        r = PL_START - 1 + i                            # 0-basiert
        mz = MA_START + i                               # Zeile im Blatt Mitarbeiter (1-basiert)
        ws_p.write_formula(r, 0, '=IF(Mitarbeiter!$A$%d="","",Mitarbeiter!$A$%d)' % (mz, mz), f_name)
        ws_p.write_formula(r, 1, '=IF(Mitarbeiter!$A$%d="","",Mitarbeiter!$C$%d)' % (mz, mz), f_sparte)
        ws_p.write_formula(r, 2, '=IF(Mitarbeiter!$A$%d="","",Mitarbeiter!$D$%d)' % (mz, mz), f_kap)
        ws_w.write_formula(r, 0, '=Planung!A%d' % (r + 1), st.zelle)
        ws_w.write_formula(r, 1, '=Planung!B%d' % (r + 1), st.zelle)
        ws_w.write_formula(r, 2, '=N(Mitarbeiter!$D$%d)' % mz, st.zelle_dez)
        name = stamm[i][0] if i < len(stamm) else None
        kap = stamm[i][3] if i < len(stamm) else None
        for ci in range(n_kw):
            c = PL_SPALTE0 + ci
            col = xl_col_to_name(c)
            wert = wochen.get(name, {}).get(kw_liste[ci]) if name else None
            if wert is None or (isinstance(wert, float) and abs(wert - kap) < 1e-9):
                ws_p.write_blank(r, c, None, f_zelle)
            elif isinstance(wert, float):
                ws_p.write_number(r, c, wert, f_zelle)
            else:
                ws_p.write(r, c, wert, f_zelle)
            p = 'Planung!%s%d' % (col, r + 1)
            # Woche zaehlt, wenn ihr Montag..Sonntag den Zeitraum Eintritt..Austritt beruehrt: Eintritt <= Montag+6 und Austritt >= Montag
            ws_w.write_formula(r, c, '=IF($A%d="",0,IF(Mitarbeiter!$G$%d=FALSE,0,IF(AND(Mitarbeiter!$E$%d<>"",%s$5+6<Mitarbeiter!$E$%d),0,'
                                     'IF(AND(Mitarbeiter!$F$%d<>"",%s$5>Mitarbeiter!$F$%d),0,IF(%s="",$C%d,IF(ISNUMBER(%s),%s,IF(UPPER(%s)="H",$C%d/2,0)))))))'
                               % (r + 1, mz, mz, col, mz, mz, col, mz, p, r + 1, p, p, p, r + 1), st.zelle_dez)
    # Summenzeilen unter der Planung (wirksame MAK je KW)
    rs = PL_START - 1 + MA_ZEILEN + 1
    ws_p.write(rs, 0, 'MAK Gesundheit (KV)', f_summe_label)
    ws_p.write(rs + 1, 0, 'MAK Komposit/Leben', f_summe_label)
    ws_p.write(rs + 2, 0, 'MAK gesamt', f_summe_label)
    for ci in range(n_kw):
        col = xl_col_to_name(PL_SPALTE0 + ci)
        wb_ = 'Wirksam!$%s$%d:$%s$%d' % (col, PL_START, col, PL_START + MA_ZEILEN - 1)
        ws_p.write_formula(rs, PL_SPALTE0 + ci, '=SUMIFS(%s,Wirksam!$B$%d:$B$%d,"Gesundheit")' % (wb_, PL_START, PL_START + MA_ZEILEN - 1), f_summe)
        ws_p.write_formula(rs + 1, PL_SPALTE0 + ci, '=SUMIFS(%s,Wirksam!$B$%d:$B$%d,"Komposit")' % (wb_, PL_START, PL_START + MA_ZEILEN - 1), f_summe)
        ws_p.write_formula(rs + 2, PL_SPALTE0 + ci, '=%s%d+%s%d' % (col, rs + 1, col, rs + 2), f_summe)
    # Eingabepruefung und bedingte Formate der Matrix
    m0, m1 = PL_START - 1, PL_START - 2 + MA_ZEILEN
    erste = xl_col_to_name(PL_SPALTE0) + str(PL_START)
    ws_p.data_validation(m0, PL_SPALTE0, m1, c_end, {'validate': 'custom', 'value': '=OR(ISNUMBER(%s),UPPER(%s)="U",UPPER(%s)="K",UPPER(%s)="F",UPPER(%s)="H")' % ((erste,) * 5),
                                                    'input_title': 'Anwesenheit', 'input_message': 'leer = anwesend · U Urlaub · K krank · F Fortbildung/Abwesenheit · H halbe Woche · Zahl = MAK',
                                                    'error_title': 'Ungültiger Eintrag', 'error_message': 'Erlaubt: leer, U, K, F, H oder eine Zahl (MAK).'})
    cf = lambda **k: wb.add_format(k)  # noqa: E731
    bereich = (m0, PL_SPALTE0, m1, c_end)
    ws_p.conditional_format(*bereich, {'type': 'formula', 'criteria': '=UPPER(%s)="U"' % erste, 'format': cf(bg_color='#FFE699', font_color='#7F6000', bold=True)})
    ws_p.conditional_format(*bereich, {'type': 'formula', 'criteria': '=UPPER(%s)="K"' % erste, 'format': cf(bg_color=ROTL, font_color=ROTD, bold=True)})
    ws_p.conditional_format(*bereich, {'type': 'formula', 'criteria': '=UPPER(%s)="F"' % erste, 'format': cf(bg_color=GRAUL, font_color=GRAUD, bold=True)})
    ws_p.conditional_format(*bereich, {'type': 'formula', 'criteria': '=UPPER(%s)="H"' % erste, 'format': cf(bg_color=TEALL, font_color=TEALD, bold=True)})
    ws_p.conditional_format(*bereich, {'type': 'formula', 'criteria': '=AND(ISNUMBER(%s),%s<>"")' % (erste, erste), 'format': cf(bg_color='#DDEBF7', font_color='#1F4E79', bold=True)})
    ws_p.conditional_format(*bereich, {'type': 'formula', 'criteria': '=$A%d=""' % PL_START, 'format': cf(bg_color=WEISS, border=0)})
    heute_kw = 'Filter!$O$24'                       # ISO-Schluessel von heute (TODAY() nur dort)
    ws_p.conditional_format(3, PL_SPALTE0, 5, c_end, {'type': 'formula', 'criteria': '=Wirksam!%s$6=%s' % (xl_col_to_name(PL_SPALTE0), heute_kw), 'format': cf(bg_color=ROT, font_color=WEISS, bold=True)})
    ws_p.conditional_format(*bereich, {'type': 'formula', 'criteria': '=Wirksam!%s$6=%s' % (xl_col_to_name(PL_SPALTE0), heute_kw), 'format': cf(left=2, right=2, left_color=ROT, right_color=ROT)})
    ws_p.conditional_format(*bereich, {'type': 'formula', 'criteria': '=Wirksam!%s$5<Filter!$O$25' % xl_col_to_name(PL_SPALTE0), 'format': cf(font_color=GRAUM, bg_color='#F7F7F7')})
    ws_p.conditional_format(3, PL_SPALTE0, 5, c_end, {'type': 'formula', 'criteria': '=Wirksam!%s$5<Filter!$O$25' % xl_col_to_name(PL_SPALTE0), 'format': cf(font_color=GRAUM)})
    ws_p.set_row(3, 16)
    ws_p.set_row(4, 18)
    ws_p.set_row(5, 12)
    ws_p.set_row(0, 34)          # Schaltflaechen
    ws_p.set_row(1, 30)          # Titel
    ws_p.set_row(2, 18)          # Hinweis
    # Schaltflaechen oben rechts im Blatt Planung (Makros werden in der Nachbearbeitung eingetragen)
    knoepfe = [(0, 0, 'Zur aktuellen KW', 'modCockpit.ZurAktuellenKW', TEALD, 150, 24, 'BTN_PL_KW', WEISS, True, False, 5),
               (0, 3, 'MAK-Liste importieren', 'modLaden.AnwesenheitLaden', GRAUD, 170, 24, 'BTN_PL_Import', WEISS, True, False, 5),
               (0, 7, 'Zum Cockpit', 'modCockpit.CockpitOeffnen', GRAUM, 120, 24, 'BTN_PL_Cockpit', WEISS, True, False, 5)]
    for (zr, zc, text, makro, farbe, breite, hoehe, nm, schrift, fett, links, yoff) in knoepfe:
        ws_p.insert_textbox(zr, zc, text, {'width': breite, 'height': hoehe, 'x_offset': 4, 'y_offset': yoff, 'object_position': 3,
                                           'fill': {'color': farbe}, 'line': {'none': True},
                                           'font': {'name': FONT, 'size': 9, 'bold': fett, 'color': schrift}, 'align': {'vertical': 'middle', 'horizontal': 'center'}})
    global KNOEPFE_PLANUNG
    KNOEPFE_PLANUNG = knoepfe
    return wochen_bereich, schluessel_zeile


# ------------------------------------------------------------------ PPT-Folie: Kacheln im Folienmass (Punkte), die das Makro modPPT.NachPowerPoint als Formen kopiert
FARBE_OPAG, FARBE_VERBUND, FARBE_NEUTRAL = ROTD, TEALD, GRAUD       # "Bookmark"-Farben der Kacheln
PT = 96.0 / 72.0                                                     # Punkt -> Pixel
PPT_BREITE, PPT_HOEHE = 878, 405                                     # Inhaltsflaeche unter dem Folientitel (Layout "Only Title", Punkte)
KACHEL_B, KACHEL_H, KACHEL_LUECKE = 283, 195, 14
KACHEL_KOPF = 30                                                     # zwei Zeilen: Titel, darunter die Kennzahl
PPT_CHART_B, PPT_CHART_H = 283, 165                                  # Diagramm fuellt die Kachel unter der Kopfleiste (Punkte); Fussnote liegt unten darueber
PLOT_PPT_STAPEL = {'x': 0.02, 'y': 0.15, 'width': 0.96, 'height': 0.64}
PLOT_PPT_BEWEG = {'x': 0.02, 'y': 0.15, 'width': 0.96, 'height': 0.58}
CHART_ZAEHLER = [0]                                                  # laufende Nummer eingefuegter Diagramme (Chart 1, Chart 2, ...)


def chart_einfuegen(ws, zeile, spalte, chart, optionen):
    ws.insert_chart(zeile, spalte, chart, optionen)
    CHART_ZAEHLER[0] += 1
    return CHART_ZAEHLER[0]


def ppt_blatt(wb, ws, st, ber, werte):
    ws.set_zoom(85)
    ws.set_tab_color(ROT)
    ws.set_column('A:A', 2)
    ws.set_column('B:B', 2)
    ws.set_column('C:AZ', 3.0)
    ws.set_row(0, 18)
    ws.set_row(1, 14)
    ws.set_row(2, 8)
    ws.write('C1', 'PPT-Folie: Diese Kacheln kopiert „PowerPoint-Folie erzeugen“ (Cockpit) als Formen auf eine Folie der ERGO-Vorlage. Titel und Untertitel der Folie stehen in AZ1:AZ2, Werte in den Kachelköpfen sind mit Zellen verknüpft.', st.untertitel)
    # Folientitel und Untertitel (vom Makro in die Platzhalter geschrieben)
    ws.write('AZ1', 'Folientitel', st.abschnitt_klein)
    ws.write_formula('BA1', '="HS | BÜ-Reporting Makler-Bestandsübertragung"', st.zelle)
    ws.write('AZ2', 'Untertitel', st.abschnitt_klein)
    datum = lambda z: 'RIGHT("0"&DAY(%s),2)&"."&RIGHT("0"&MONTH(%s),2)&"."&YEAR(%s)' % (z, z, z)  # noqa: E731
    ws.write_formula('BA2', '=IF(Filter!$O$5="","Noch keine Stände geladen","Stand "&%s&IF(Filter!$O$6="",""," · vorheriger Stand "&%s)&" · Quelle MIS-O")'
                     % (datum('Filter!$O$5'), datum('Filter!$O$6')), st.zelle)
    ws.set_column('AZ:AZ', 12)
    ws.set_column('BA:BA', 90)
    # Kachelwerte (mit Zellen verknuepfte Textfelder)
    ws.write('AZ4', 'Kachelwerte', st.abschnitt_klein)
    werte_formeln = [
        '=IF(Filter!$O$7=0,"–",FIXED(INDEX(Verlauf!$H$6:$H$%d,Filter!$O$7),0,FALSE)&IF(Filter!$O$19="",""," ("&IF(Filter!$O$19>0,"+","")&FIXED(Filter!$O$19,0,FALSE)&")"))' % MAX_VERLAUF,
        '=IF(Filter!$O$7=0,"–",FIXED(INDEX(Verlauf!$R$6:$R$%d,Filter!$O$7),0,FALSE)&IF(Filter!$O$20="",""," ("&IF(Filter!$O$20>0,"+","")&FIXED(Filter!$O$20,0,FALSE)&")"))' % MAX_VERLAUF,
        '=IF(Filter!$O$7=0,"–","+"&FIXED(INDEX(Verlauf!$I$6:$I$%d,Filter!$O$7),0,FALSE)&" / −"&FIXED(INDEX(Verlauf!$J$6:$J$%d,Filter!$O$7),0,FALSE))' % (MAX_VERLAUF, MAX_VERLAUF),
        '=IF(Filter!$O$7=0,"–","+"&FIXED(INDEX(Verlauf!$S$6:$S$%d,Filter!$O$7),0,FALSE)&" / −"&FIXED(INDEX(Verlauf!$T$6:$T$%d,Filter!$O$7),0,FALSE))' % (MAX_VERLAUF, MAX_VERLAUF),
        '=IF(Filter!$O$11=0,"–","MAK "&FIXED(INDEX(KW!$N$6:$N$400,Filter!$O$11),1)&" · "&IFERROR(FIXED(INDEX(KW!$Q$6:$Q$400,Filter!$O$11),1),"–")&" Vorgänge je MAK")',
        '=IF(Filter!$O$7=0,"–",IF(Filter!$O$15+Filter!$P$15+Filter!$Q$15+Filter!$R$15=0,"–",FIXED(100*Filter!$R$15/(Filter!$O$15+Filter!$P$15+Filter!$Q$15+Filter!$R$15),0)&" % OPAG über 90 Tage"))',
    ]
    for i, fm in enumerate(werte_formeln):
        ws.write_formula(4 + i, 52, fm, st.zelle)      # BA5..BA10
    ws.write('AZ12', 'Filter', st.abschnitt_klein)
    ws.write_formula('BA12', '="Themenpostkörbe: "&IF(COUNTIF(PK_Aktiv,TRUE)=COUNTA(PK_Liste),"alle",COUNTIF(PK_Aktiv,TRUE)&" von "&COUNTA(PK_Liste))&" · Sparten: "&IF(COUNTIF(SP_Aktiv,TRUE)=COUNTA(SP_Liste),"alle",TRIM(IF(Filter!$T$5=TRUE,"Komposit ","")&IF(Filter!$T$6=TRUE,"Leben ","")&IF(Filter!$T$7=TRUE,"KV ","")&IF(Filter!$T$8=TRUE,"Sonstige","")))&" · GeVo: "&Filter!$L$5&" · "&IF(Filter!$L$9="Woche","Wochensicht","Tagessicht")', st.zelle)

    x0, y0 = 4, 4                                                     # Ursprung der Formen (Pixel) in Zelle B4
    def px(pt):
        return int(round(pt * PT))

    def kachel(nr, titel, farbe, wert_zelle, chart, geom=None):
        col, row = nr % 3, nr // 3
        kx = x0 + px(col * (KACHEL_B + KACHEL_LUECKE))
        ky = y0 + px(row * (KACHEL_H + KACHEL_LUECKE))
        # Kopfleiste ("Bookmark"): Titel oben, verknuepfte Kennzahl in der zweiten Zeile (beide linksbuendig, keine Ueberlappung
        # bei Schriftersatz in PowerPoint)
        ws.insert_textbox(3, 1, titel, {'x_offset': kx, 'y_offset': ky, 'width': px(KACHEL_B), 'height': px(KACHEL_KOPF), 'object_position': 3,
                                        'fill': {'color': farbe}, 'line': {'none': True},
                                        'font': {'name': FONT, 'size': 9, 'bold': True, 'color': WEISS}, 'align': {'vertical': 'top', 'horizontal': 'left'}})
        ws.insert_textbox(3, 1, '', {'x_offset': kx, 'y_offset': ky + px(14), 'width': px(KACHEL_B), 'height': px(KACHEL_KOPF - 14), 'object_position': 3,
                                     'textlink': wert_zelle, 'fill': {'none': True}, 'line': {'none': True},
                                     'font': {'name': FONT, 'size': 8, 'bold': False, 'color': WEISS}, 'align': {'vertical': 'top', 'horizontal': 'left'}})
        nummer = chart_einfuegen(ws, 3, 1, chart, {'x_offset': kx, 'y_offset': ky + px(KACHEL_KOPF), 'object_position': 3})
        if geom:
            geom['datei'] = 'xl/charts/chart%d.xml' % nummer
            GEOMETRIE.append(geom)
        # Fussnote
        ws.insert_textbox(3, 1, '', {'x_offset': kx, 'y_offset': ky + px(KACHEL_H - 13), 'width': px(KACHEL_B), 'height': px(13), 'object_position': 3,
                                     'textlink': '=PPT!$BA$12', 'fill': {'none': True}, 'line': {'none': True},
                                     'font': {'name': FONT, 'size': 6.5, 'italic': True, 'color': GRAU}, 'align': {'vertical': 'middle', 'horizontal': 'left'}})

    b, h = px(PPT_CHART_B), px(PPT_CHART_H)
    lab = lambda fmt, farbe=WEISS, size=7: {'value': True, 'position': 'center', 'num_format': fmt, 'font': {'name': FONT, 'size': size, 'color': farbe, 'bold': True}}  # noqa: E731
    lab_sum = lambda fmt, pos: {'value': True, 'position': pos, 'num_format': fmt, 'font': {'name': FONT, 'size': 7, 'color': GRAUD, 'bold': True}}  # noqa: E731

    def basis(ch, y_format='#,##0'):
        ch.set_chartarea({'border': {'none': True}, 'fill': {'color': GRAUXL}})
        ch.set_plotarea({'border': {'none': True}, 'fill': {'none': True}})
        ch.set_title({'none': True})
        ch.set_legend({'position': 'top', 'font': {'name': FONT, 'size': 7, 'color': GRAUD}})
        ch.set_x_axis({'num_font': {'name': FONT, 'size': 7, 'color': GRAU}, 'line': {'color': GRAUL, 'width': 0.75}, 'major_gridlines': {'visible': False},
                       'major_tick_mark': 'none', 'minor_tick_mark': 'none'})
        ch.set_y_axis({'visible': False, 'major_gridlines': {'visible': False}})
        ch.set_size({'width': b, 'height': h})
        ch.show_blanks_as('gap')

    def stapel(q):
        ch = wb.add_chart({'type': 'column', 'subtype': 'stacked'})
        cols = {'OPAG': ['C', 'D', 'E', 'F'], 'Verbund': ['G', 'H', 'I', 'J']}[q]
        for sp, col in zip(['Komposit', 'Leben', 'KV'], cols):
            ch.add_series({'name': sp, 'categories': '=Diagrammdaten!$A$4:$A$10', 'values': '=Diagrammdaten!$%s$4:$%s$10' % (col, col),
                           'fill': {'color': FARBE_SPARTE[sp]}, 'border': {'color': WEISS, 'width': 0.5}, 'gap': 60, 'data_labels': lab('#,##0.0,;#,##0.0,;')})
        ln = wb.add_chart({'type': 'line'})
        ln.add_series({'name': 'Gesamt', 'categories': '=Diagrammdaten!$A$4:$A$10', 'values': '=Diagrammdaten!$%s$4:$%s$10' % (cols[3], cols[3]),
                       'line': {'none': True}, 'marker': {'type': 'none'}, 'data_labels': lab_sum('#,##0.0,;#,##0.0,;', 'above')})
        ch.combine(ln)
        basis(ch)
        ch.set_plotarea({'border': {'none': True}, 'fill': {'none': True}, 'layout': PLOT_PPT_STAPEL})
        w = werte['rueckstand'][q]
        ymax = achsen_ende(max([sum(s) for s in w if s] or [0]))
        geom = None
        if ymax > 0:
            ch.set_y_axis({'visible': False, 'major_gridlines': {'visible': False}, 'min': 0, 'max': ymax})
            geom = {'art': 'saeulen', 'b': b, 'h': h, 'layout': PLOT_PPT_STAPEL, 'gap': 60, 'werte': w, 'ymin': 0, 'ymax': ymax, 'formate': ['#,##0.0,'] * 3, 'label_h': 11.5, 'zeichen': 5.0}
        return ch, geom

    def bewegung(q):
        # Summen je Periode: Eingaenge ueber der Achse, Abgaenge darunter, Delta als Punktlinie
        ch = wb.add_chart({'type': 'column'})
        cols = {'OPAG': ['K', 'L', 'M'], 'Verbund': ['N', 'O', 'P']}[q]
        ch.add_series({'name': 'Eingänge', 'categories': '=Diagrammdaten!$A$4:$A$10', 'values': '=Diagrammdaten!$%s$4:$%s$10' % (cols[0], cols[0]),
                       'fill': {'color': GRAUD}, 'border': {'none': True}, 'gap': 80, 'overlap': 100, 'data_labels': {**lab('#,##0;#,##0;', GRAUD), 'position': 'outside_end'}})
        ch.add_series({'name': 'Abgänge', 'categories': '=Diagrammdaten!$A$4:$A$10', 'values': '=Diagrammdaten!$%s$4:$%s$10' % (cols[1], cols[1]),
                       'fill': {'color': TEAL}, 'border': {'none': True}, 'data_labels': {**lab('#,##0;#,##0;', TEALD), 'position': 'outside_end'}})
        ln = wb.add_chart({'type': 'line'})
        ln.add_series({'name': 'Delta', 'categories': '=Diagrammdaten!$A$4:$A$10', 'values': '=Diagrammdaten!$%s$4:$%s$10' % (cols[2], cols[2]),
                       'line': {'none': True}, 'marker': {'type': 'diamond', 'size': 6, 'fill': {'color': ROT}, 'border': {'color': WEISS}},
                       'data_labels': {'value': True, 'position': 'right', 'num_format': '+#,##0;-#,##0;±0', 'font': {'name': FONT, 'size': 7, 'color': ROT, 'bold': True}}})
        ch.combine(ln)
        basis(ch)
        ch.set_plotarea({'border': {'none': True}, 'fill': {'none': True}, 'layout': PLOT_PPT_BEWEG})
        ch.set_x_axis({'num_font': {'name': FONT, 'size': 7, 'color': GRAU}, 'line': {'color': GRAUL, 'width': 0.75}, 'major_gridlines': {'visible': False},
                       'major_tick_mark': 'none', 'label_position': 'low'})
        return ch

    def mak_chart():
        ch = wb.add_chart({'type': 'column', 'subtype': 'stacked'})
        k2 = ber['kw2']
        k1 = max(6, k2 - 6)
        k2 = k1 + 6
        kwb = lambda col: '=KW!$%s$%d:$%s$%d' % (col, k1, col, k2)  # noqa: E731
        ch.add_series({'name': 'MAK Gesundheit (KV)', 'categories': kwb('C'), 'values': kwb('L'), 'fill': {'color': ROT}, 'border': {'color': WEISS, 'width': 0.5}, 'gap': 70,
                       'data_labels': lab('0.0;0.0;')})
        ch.add_series({'name': 'MAK Komposit/Leben', 'categories': kwb('C'), 'values': kwb('M'), 'fill': {'color': TEAL}, 'border': {'color': WEISS, 'width': 0.5},
                       'data_labels': lab('0.0;0.0;')})
        ln = wb.add_chart({'type': 'line'})
        ln.add_series({'name': 'MAK gesamt', 'categories': kwb('C'), 'values': kwb('N'), 'line': {'none': True}, 'marker': {'type': 'none'},
                       'data_labels': lab_sum('0.0;0.0;', 'above')})
        ch.combine(ln)
        basis(ch, '0.0')
        ch.set_plotarea({'border': {'none': True}, 'fill': {'none': True}, 'layout': PLOT_PPT_STAPEL})
        return ch

    def alter_chart():
        ch = wb.add_chart({'type': 'bar', 'subtype': 'percent_stacked'})
        for i, t in enumerate(['0–7 Tage', '8–30 Tage', '31–90 Tage', 'über 90 Tage']):
            col = xl_col_to_name(14 + i)
            ch.add_series({'name': t, 'categories': '=Filter!$N$15:$N$16', 'values': '=Filter!$%s$15:$%s$16' % (col, col),
                           'fill': {'color': FARBE_ALTER[i]}, 'border': {'color': WEISS, 'width': 1}, 'gap': 60,
                           'data_labels': {'value': True, 'num_format': '#,##0;#,##0;', 'font': {'name': FONT, 'size': 7, 'color': SW if i < 2 else WEISS}}})
        basis(ch)
        ch.set_x_axis({'visible': False, 'major_gridlines': {'visible': False}})
        ch.set_y_axis({'num_font': {'name': FONT, 'size': 8, 'color': GRAUD, 'bold': True}, 'line': {'none': True}, 'major_gridlines': {'visible': False},
                       'major_tick_mark': 'none', 'reverse': True})
        ch.set_plotarea({'border': {'none': True}, 'fill': {'none': True}, 'layout': {'x': 0.1, 'y': 0.16, 'width': 0.88, 'height': 0.7}})
        return ch

    ch, g = stapel('OPAG')
    kachel(0, 'Rückstand OPAG (Arbeitsgüter, in Tsd.)', FARBE_OPAG, '=PPT!$BA$5', ch, g)
    ch, g = stapel('Verbund')
    kachel(1, 'Rückstand Verbund (Vorgänge, in Tsd.)', FARBE_VERBUND, '=PPT!$BA$6', ch, g)
    kachel(2, 'Kapazität (MAK) je KW', FARBE_NEUTRAL, '=PPT!$BA$9', mak_chart())
    kachel(3, 'Eingänge / Abgänge OPAG', FARBE_OPAG, '=PPT!$BA$7', bewegung('OPAG'))
    kachel(4, 'Eingänge / Abgänge Verbund', FARBE_VERBUND, '=PPT!$BA$8', bewegung('Verbund'))
    kachel(5, 'Altersstruktur des Rückstands', FARBE_NEUTRAL, '=PPT!$BA$10', alter_chart())
    ws.set_landscape()
    ws.set_paper(9)
    ws.fit_to_pages(1, 1)
    ws.print_area(0, 0, 40, 50)


# ------------------------------------------------------------------ Nachbearbeitung des Pakets: Makros an Textfelder, Kontrollkaestchen in VML, VBA-Projekt
def px_spalte(ws, col):
    return sum(ws._size_col(c) for c in range(col))


def px_zeile(ws, row):
    return sum(ws._size_row(r) for r in range(row))


def nachbearbeiten(vba_bin):
    tmp = OUT + '.tmp'
    zin = zipfile.ZipFile(OUT)
    zout = zipfile.ZipFile(tmp, 'w', zipfile.ZIP_DEFLATED)
    namen = zin.namelist()
    zeichnungen = [n for n in namen if re.match(r'xl/drawings/drawing\d+\.xml$', n)]
    for n in namen:
        daten = zin.read(n)
        if n in zeichnungen:
            text = daten.decode('utf-8')
            liste = next((kn for kn in KNOEPFE_LISTEN if all(('<a:t>%s</a:t>' % k[2]) in text for k in kn)), None)
            if liste:
                bloecke = re.split(r'(?=<xdr:twoCellAnchor)', text)
                belegt = set()
                for (_zr, _zc, knopf, makro, _f, _b, _h, nm, _s, _fett, _l, _y) in liste:
                    for i, bl in enumerate(bloecke):
                        if i in belegt or '<xdr:sp ' not in bl or ('<a:t>%s</a:t>' % knopf) not in bl:
                            continue
                        bl = bl.replace('<xdr:sp macro=""', '<xdr:sp macro="[0]!%s"' % makro, 1)
                        bl = re.sub(r'(<xdr:cNvPr id="\d+" name=")[^"]*(")', lambda m: m.group(1) + nm + m.group(2), bl, count=1)
                        bl = bl.replace('<a:prstGeom prst="rect">', '<a:prstGeom prst="roundRect">', 1)
                        bloecke[i] = bl
                        belegt.add(i)
                        break
                    else:
                        raise RuntimeError('Schaltflaeche nicht gefunden: ' + knopf)
                daten = ''.join(bloecke).encode('utf-8')
        if re.match(r'xl/charts/chart\d+\.xml$', n):
            text = daten.decode('utf-8')
            for g in GEOMETRIE:
                if g.get('datei') == n:
                    text = etiketten_eintragen(text, g)
                    for ref, wert in g.get('texte', {}).items():      # Zwischenspeicher der verknuepften Beschriftungen (fuer Vorschau ohne Neuberechnung)
                        text = text.replace('<c:f>%s</c:f><c:strCache><c:ptCount val="1"/><c:pt idx="0"><c:v>0</c:v>' % ref,
                                            '<c:f>%s</c:f><c:strCache><c:ptCount val="1"/><c:pt idx="0"><c:v>%s</c:v>' % (ref, wert))
            daten = text.encode('utf-8')
        zout.writestr(zin.getinfo(n), daten)
    zin.close()
    zout.close()
    os.replace(tmp, OUT)


def vba_bin_schreiben():
    module = []
    for name, datei in [('modLaden', 'modLaden.bas'), ('modCockpit', 'modCockpit.bas'), ('modPPT', 'modPPT.bas'), ('modFortschritt', 'modFortschritt.bas')]:
        module.append((name, open(os.path.join(HIER, 'vba', datei), encoding='utf-8').read(), False))
    module.insert(0, ('ThisWorkbook', 'Option Explicit\r\n\r\nPrivate Sub Workbook_Open()\r\n    On Error Resume Next\r\n    modCockpit.FilterAnzeigen\r\n    modCockpit.DiagrammeAnpassen\r\nEnd Sub\r\n', 'workbook'))
    module.insert(1, ('Cockpit', open(os.path.join(HIER, 'vba', 'Cockpit.cls'), encoding='utf-8').read(), 'sheet'))
    pfad = os.path.join(HIER, 'vbaProject.bin')
    open(pfad, 'wb').write(ovba.vba_projekt(module))
    return pfad


if __name__ == '__main__':
    vba = vba_bin_schreiben()
    ziel_master = OUT
    for leer, ziel in ((True, ziel_master), (False, OUT_DEMO)):
        OUT = ziel
        bauen(vba, leer=leer)
        nachbearbeiten(vba)
        print('geschrieben:', OUT)
