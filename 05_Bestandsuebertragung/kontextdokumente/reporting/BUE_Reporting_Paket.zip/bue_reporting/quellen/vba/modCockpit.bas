Option Explicit
' ============================================================================
' modCockpit – Schaltflaechen des Cockpits: Filter setzen, Ansicht aktualisieren
' Die Chips im Cockpit sind Zellen mit HYPERLINK auf ChipHover (Rollover: Filter!Q1 = Chip unter der Maus);
' der Klick landet ueber Worksheet_SelectionChange (Blattmodul Cockpit) in ChipSchalten und schaltet
' Filter!C (Themenpostkoerbe, Zeilen PK_VON..PK_BIS), Filter!H (GeVo-Typen, Zeilen 5..18) bzw. Filter!T (Sparten, Zeilen 5..8) um.
' Alle Kennzahlen und Diagramme rechnen ueber Formeln; DiagrammeAnpassen setzt nur veraenderte Bereiche.
' Diagramme: 1/2 Rueckstand OPAG/Verbund, 3/4 Bewegungen OPAG/Verbund, 5 MAK, 6 Altersstruktur,
' 7/8 Produktivitaet Verbund/OPAG, 9 Rueckstand je Themenpostkorb.
' ============================================================================

Private aktualisierungGeplant As Boolean   ' Aktualisierung per OnTime bereits geplant
Private reihenFest As Boolean              ' Diagrammdaten-Reihen (feste Zeilen) sind gesetzt
Private letztesK1 As Long                  ' zuletzt gesetztes KW-Fenster
Private letztesP As Long                   ' zuletzt gesetzte letzte Postkorbzeile

Public Sub FilterAllePostkoerbe()
    If modLaden.LadenLaeuft() Then Exit Sub
    SetzePostkoerbe True
End Sub

Public Sub FilterAktiveBearbeitung()
    If modLaden.LadenLaeuft() Then Exit Sub
    ' Nur die Themenpostkoerbe aus der Vorauswahl "Aktive Bearbeitung" (Konfiguration!F11:F30)
    Dim wsF As Worksheet, wsK As Worksheet, r As Long, k As Long, aktiv As Boolean
    Set wsF = ThisWorkbook.Worksheets("Filter")
    Set wsK = ThisWorkbook.Worksheets("Konfiguration")
    Dim vorauswahl As Variant, namen As Variant, aus() As Variant
    vorauswahl = wsK.Range("F11:F30").Value2
    namen = wsF.Range(wsF.Cells(modLaden.PK_VON, 2), wsF.Cells(modLaden.PK_BIS, 2)).Value2
    ReDim aus(1 To UBound(namen, 1), 1 To 1)
    For r = 1 To UBound(namen, 1)
        aktiv = False
        If Len(CStr(namen(r, 1))) > 0 Then
            For k = 1 To UBound(vorauswahl, 1)
                If CStr(vorauswahl(k, 1)) = CStr(namen(r, 1)) Then aktiv = True
            Next k
            aus(r, 1) = aktiv
        Else
            aus(r, 1) = Empty
        End If
    Next r
    wsF.Range(wsF.Cells(modLaden.PK_VON, 3), wsF.Cells(modLaden.PK_BIS, 3)).Value = aus
    Aktualisieren
End Sub

Public Sub FilterAlleGeVo()
    If modLaden.LadenLaeuft() Then Exit Sub
    ThisWorkbook.Worksheets("Filter").Range("L5").Value = "Alle GeVo"
    Aktualisieren
End Sub

Public Sub FilterNurBUE()
    If modLaden.LadenLaeuft() Then Exit Sub
    ThisWorkbook.Worksheets("Filter").Range("L5").Value = "Nur BÜ-Schlüssel"
    Aktualisieren
End Sub

Public Sub FilterZuruecksetzen()
    If modLaden.LadenLaeuft() Then Exit Sub
    SetzePostkoerbe True
    ThisWorkbook.Worksheets("Filter").Range("L5").Value = "Alle GeVo"
    Dim r As Long
    For r = 5 To 18
        ThisWorkbook.Worksheets("Filter").Cells(r, 8).Value = True
    Next r
    ThisWorkbook.Worksheets("Filter").Range("T5:T8").Value = True
    Aktualisieren
End Sub

Public Sub FilterAlleSparten()
    If modLaden.LadenLaeuft() Then Exit Sub
    ThisWorkbook.Worksheets("Filter").Range("T5:T8").Value = True
    Aktualisieren
End Sub

Public Sub Aktualisieren()
    aktualisierungGeplant = False
    Application.Calculate
    FilterAnzeigen
    DiagrammeAnpassen
End Sub

Public Sub Hilfe()
    If modLaden.LadenLaeuft() Then Exit Sub
    modFortschritt.HinweisZeigen "BÜ-Reporting HSB4 K", "BÜ-Reporting HSB4 K" & vbCrLf & vbCrLf & _
           "Neue Daten laden: liest alle Rückstandsabzüge (OPAG und Verbund) aus dem Ordner 'Rohdaten' neben dieser Datei, " & _
           "erkennt Stichtag und Quelle selbst und lädt nur, was noch fehlt." & vbCrLf & vbCrLf & _
           "Anwesenheit laden: importiert die MAK-Liste einmalig in die Blätter Mitarbeiter und Planung. Danach wird die Anwesenheit dort gepflegt (Anwesenheitsplan öffnen): leer = anwesend, U Urlaub, K krank, F Abwesenheit, H halbe Woche, Zahl = MAK; neue Mitarbeitende im Blatt Mitarbeiter." & vbCrLf & vbCrLf & _
           "PowerPoint-Folie erzeugen: kopiert die Kacheln des Blatts PPT auf eine Folie der ERGO-Vorlage." & vbCrLf & vbCrLf & _
           "Filter: Die Chips für Sparten, Themenpostkörbe und GeVo-Typen schalten per Klick um (gefüllt = im Filter) und wirken sofort auf alle Kennzahlen und Diagramme; über den Rückstandssäulen zeigt ein Badge die Veränderung zum vorherigen Stand (grün = weniger, gelb = mehr). " & _
           "'Aktive Bearbeitung' wählt die Postkörbe aus Konfiguration!F11:F30." & vbCrLf & vbCrLf & _
           "Eingänge = Schlüssel, die im neuen Stand erstmals vorkommen; Abgänge = Schlüssel des Vortags, die fehlen " & _
           "(abgearbeitet oder weitergeleitet). Produktivität = Abgänge je MAK in der Kalenderwoche." & vbCrLf & vbCrLf & _
           "Diagramme zeigen immer 7 Perioden (Tages- oder Wochensicht, neueste rechts); Werte, die nicht in ihr Segment passen, stehen mit Führungslinie neben der Säule.", False
End Sub

Private Sub SetzePostkoerbe(wert As Boolean)
    Dim ws As Worksheet, r As Long, namen As Variant, aus() As Variant
    Set ws = ThisWorkbook.Worksheets("Filter")
    namen = ws.Range(ws.Cells(modLaden.PK_VON, 2), ws.Cells(modLaden.PK_BIS, 2)).Value2
    ReDim aus(1 To UBound(namen, 1), 1 To 1)
    For r = 1 To UBound(namen, 1)
        If Len(CStr(namen(r, 1))) > 0 Then aus(r, 1) = wert Else aus(r, 1) = Empty
    Next r
    ws.Range(ws.Cells(modLaden.PK_VON, 3), ws.Cells(modLaden.PK_BIS, 3)).Value = aus
End Sub

' ---------------------------------------------------------------- Chips (Filterschaltflaechen)
Public Function ChipHover(nr As Long) As String
    ' Wird von HYPERLINK() in den Chipzellen beim Ueberfahren mit der Maus ausgewertet (Rollover): merkt den Chip in Filter!Q1,
    ' die bedingten Formate heben ihn hervor. Der Link zeigt auf die Zelle selbst; der Klick loest Worksheet_SelectionChange aus.
    ' Geschrieben wird NUR beim Ueberfahren (CalculationState = xlDone), nie waehrend einer Neuberechnung oder des Ladens:
    ' Zellschreiben aus einer UDF mitten in der Berechnung bringt neuere Excel-Versionen zum Absturz.
    ' Konfiguration!B8 = NEIN schaltet den Hover ganz ab (Klick bleibt).
    ' Der Link zeigt auf Spalte A der Chipzeile (dort steht die Chip-Nummer); ist diese Zelle schon markiert, auf Spalte H
    ' derselben Zeile – so aendert jeder Klick die Auswahl und Worksheet_SelectionChange feuert auch beim zweiten Klick.
    Dim z As Range, ziel As Range
    On Error Resume Next
    Set z = Application.Caller
    Set ziel = z.Parent.Cells(z.Row, 1)
    If Not ActiveCell Is Nothing Then
        If ActiveCell.Parent.Name = z.Parent.Name And ActiveCell.Address = ziel.Address Then Set ziel = z.Parent.Cells(z.Row, 8)
    End If
    ChipHover = "#'" & z.Parent.Name & "'!" & ziel.Address
    If modLaden.LadenLaeuft() Then Exit Function
    If Application.CalculationState <> xlDone Then Exit Function
    If UCase$(Trim$(CStr(ThisWorkbook.Worksheets("Konfiguration").Range("B8").Value))) = "NEIN" Then Exit Function
    If ThisWorkbook.Worksheets("Filter").Range("Q1").Value <> nr Then ThisWorkbook.Worksheets("Filter").Range("Q1").Value = nr
    On Error GoTo 0
End Function

Public Sub ChipSchalten(nr As Long)
    If modLaden.LadenLaeuft() Then Exit Sub
    ' Schaltet den Chip nr um: 1..99 Themenpostkorb (Filter!C), 101..114 GeVo-Typ (Filter!H, wechselt in die manuelle Auswahl),
    ' 201..204 Sparte (Filter!T)
    Dim wsF As Worksheet, r As Long, i As Long
    Set wsF = ThisWorkbook.Worksheets("Filter")
    If nr < 100 Then
        r = 4 + nr
        wsF.Cells(r, 3).Value = Not CBool(wsF.Cells(r, 3).Value)
    ElseIf nr >= 200 Then
        r = 4 + (nr - 200)
        wsF.Cells(r, 20).Value = Not CBool(wsF.Cells(r, 20).Value)
    Else
        r = 4 + (nr - 100)
        If wsF.Range("L5").Value <> "Manuelle Auswahl" Then
            For i = 5 To 18
                wsF.Cells(i, 8).Value = CBool(wsF.Cells(i, 9).Value)
            Next i
            wsF.Range("L5").Value = "Manuelle Auswahl"
        End If
        wsF.Cells(r, 8).Value = Not CBool(wsF.Cells(r, 8).Value)
    End If
    ' Kennzahlen rechnen sofort ueber Formeln; Diagramme und Etiketten gleich danach nachziehen, damit der Klick
    ' nicht blockiert und der naechste Klick auf denselben Chip sofort wirkt
    AktualisierungPlanen
End Sub

Public Sub AuswahlWegPlanen()
    ' Nach dem Chip-Klick die Auswahl auf die neutrale Zelle H1 setzen – per OnTime, also nachdem Excel den Hyperlink
    ' fertig verfolgt hat (ein Select im Ereignis selbst wird von der Hyperlink-Navigation wieder ueberschrieben)
    On Error Resume Next
    Application.OnTime Now, "'" & ThisWorkbook.Name & "'!modCockpit.AuswahlWeg"
    On Error GoTo 0
End Sub

Public Sub AuswahlWeg()
    On Error Resume Next
    If ActiveSheet.Name = "Cockpit" Then
        Application.EnableEvents = False
        ActiveSheet.Range("H1").Select
        Application.EnableEvents = True
    End If
    On Error GoTo 0
End Sub

Public Sub AktualisierungPlanen()
    If aktualisierungGeplant Then Exit Sub
    On Error GoTo Direkt
    aktualisierungGeplant = True
    Application.OnTime Now, "'" & ThisWorkbook.Name & "'!modCockpit.Aktualisieren"
    Exit Sub
Direkt:
    aktualisierungGeplant = False
    Aktualisieren
End Sub

Public Sub FilterAnzeigen()
    ' Faerbt die Ansichts-Chips (Formen ANS_Tag/ANS_Woche) nach Filter!L9; die Filter-Chips sind Zellen mit bedingtem Format
    Dim shp As Shape, ws As Worksheet, wsF As Worksheet
    Set ws = ThisWorkbook.Worksheets("Cockpit")
    Set wsF = ThisWorkbook.Worksheets("Filter")
    For Each shp In ws.Shapes
        If shp.Name = "ANS_Tag" Then
            ChipFaerben shp, (wsF.Range("L9").Value <> "Woche")
        ElseIf shp.Name = "ANS_Woche" Then
            ChipFaerben shp, (wsF.Range("L9").Value = "Woche")
        End If
    Next shp
End Sub

Public Sub AnsichtTag()
    If modLaden.LadenLaeuft() Then Exit Sub
    ThisWorkbook.Worksheets("Filter").Range("L9").Value = "Tag"
    Aktualisieren
End Sub

Public Sub AnsichtWoche()
    If modLaden.LadenLaeuft() Then Exit Sub
    ThisWorkbook.Worksheets("Filter").Range("L9").Value = "Woche"
    Aktualisieren
End Sub

Private Sub ChipFaerben(shp As Shape, aktiv As Boolean)
    With shp
        If aktiv Then
            .Fill.Visible = msoTrue
            .Fill.Solid
            .Fill.ForeColor.RGB = RGB(15, 148, 167)
            .Line.Visible = msoFalse
            .TextFrame2.TextRange.Font.Fill.ForeColor.RGB = RGB(255, 255, 255)
            .TextFrame2.TextRange.Font.Bold = msoTrue
        Else
            .Fill.Visible = msoTrue
            .Fill.Solid
            .Fill.ForeColor.RGB = RGB(255, 255, 255)
            .Line.Visible = msoTrue
            .Line.ForeColor.RGB = RGB(208, 213, 218)
            .Line.Weight = 0.75
            .TextFrame2.TextRange.Font.Fill.ForeColor.RGB = RGB(107, 107, 107)
            .TextFrame2.TextRange.Font.Bold = msoFalse
        End If
    End With
End Sub

' ---------------------------------------------------------------- Diagrammbereiche nachziehen
Public Sub DiagrammeAnpassen(Optional erzwingen As Boolean = False)
    ' Setzt die Datenbereiche der Diagramme nur, wenn sie sich geaendert haben: Diagrammdaten (immer 7 Perioden) einmal,
    ' das KW-Fenster (7 Kalenderwochen bis zur KW des letzten Stichtags) bei neuem k1, die Postkorbliste bei neuem p.
    ' Danach Etiketten pruefen (Werte neben schmalen Segmenten). erzwingen = True nach dem Laden.
    Dim ws As Worksheet, wsK As Worksheet, wsF As Worksheet, wsP As Worksheet
    Dim k1 As Long, k2 As Long, p As Long, nm As Variant
    Set ws = ThisWorkbook.Worksheets("Cockpit")
    Set wsK = ThisWorkbook.Worksheets("KW")
    Set wsF = ThisWorkbook.Worksheets("Filter")
    Set wsP = ThisWorkbook.Worksheets("PPT")
    k2 = 5 + CLng(Val(wsK.Range("AQ6").Value))
    k1 = k2 - 6
    If k1 < 6 Then k1 = 6
    k2 = k1 + 6
    p = wsF.Cells(wsF.Rows.Count, 2).End(xlUp).Row
    If p < modLaden.PK_VON Then p = modLaden.PK_VON
    If p > modLaden.PK_BIS Then p = modLaden.PK_BIS
    On Error Resume Next
    If erzwingen Then reihenFest = False: letztesK1 = 0: letztesP = 0
    If Not reihenFest Then
        Err.Clear
        SetzeReihen ws.ChartObjects("Chart 1").Chart, "Diagrammdaten", "A", 4, 10, Array("C", "D", "E", "F", "Q", "R", "S", "T")
        SetzeReihen ws.ChartObjects("Chart 2").Chart, "Diagrammdaten", "A", 4, 10, Array("G", "H", "I", "J", "V", "W", "X", "Y")
        SetzeReihen ws.ChartObjects("Chart 3").Chart, "Diagrammdaten", "A", 13, 33, Array("C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O")
        SetzeReihen ws.ChartObjects("Chart 4").Chart, "Diagrammdaten", "A", 13, 33, Array("Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "AA", "AB", "AC")
        ' PPT-Folie (Blatt PPT): 10/11 Rueckstand OPAG/Verbund, 12 MAK, 13/14 Bewegungen OPAG/Verbund (Summen), 15 Altersstruktur
        SetzeReihen wsP.ChartObjects("Chart 10").Chart, "Diagrammdaten", "A", 4, 10, Array("C", "D", "E", "F")
        SetzeReihen wsP.ChartObjects("Chart 11").Chart, "Diagrammdaten", "A", 4, 10, Array("G", "H", "I", "J")
        SetzeReihen wsP.ChartObjects("Chart 13").Chart, "Diagrammdaten", "A", 4, 10, Array("K", "L", "M")
        SetzeReihen wsP.ChartObjects("Chart 14").Chart, "Diagrammdaten", "A", 4, 10, Array("N", "O", "P")
        ' Beim Bau sind die Wertachsen fest gesetzt (fuer die Etikettengeometrie); in Excel rechnet die Automatik
        For Each nm In Array("Chart 1", "Chart 2", "Chart 3", "Chart 4")
            With ws.ChartObjects(nm).Chart.Axes(xlValue)
                .MinimumScaleIsAuto = True
                .MaximumScaleIsAuto = True
            End With
        Next nm
        For Each nm In Array("Chart 10", "Chart 11")
            With wsP.ChartObjects(nm).Chart.Axes(xlValue)
                .MinimumScaleIsAuto = True
                .MaximumScaleIsAuto = True
            End With
        Next nm
        reihenFest = (Err.Number = 0)
        Err.Clear
    End If
    If k1 <> letztesK1 Then
        SetzeReihen ws.ChartObjects("Chart 5").Chart, "KW", "C", k1, k2, Array("L", "M", "N")
        SetzeReihen ws.ChartObjects("Chart 7").Chart, "KW", "C", k1, k2, Array("O", "P", "Q")
        SetzeReihen ws.ChartObjects("Chart 8").Chart, "KW", "C", k1, k2, Array("R", "S", "T")
        SetzeReihen wsP.ChartObjects("Chart 12").Chart, "KW", "C", k1, k2, Array("L", "M", "N")
        letztesK1 = k1
    End If
    If p <> letztesP Then
        SetzeReihen ws.ChartObjects("Chart 9").Chart, "Filter", "B", modLaden.PK_VON, p, Array("D", "E")
        letztesP = p
    End If
    For Each nm In Array("Chart 1", "Chart 2", "Chart 3", "Chart 4")
        ws.ChartObjects(nm).Chart.Refresh
        EtikettenAuslagern ws.ChartObjects(nm).Chart, 0
    Next nm
    EtikettenAuslagern ws.ChartObjects("Chart 6").Chart, 2
    For Each nm In Array("Chart 10", "Chart 11")
        wsP.ChartObjects(nm).Chart.Refresh
        EtikettenAuslagern wsP.ChartObjects(nm).Chart, 0
    Next nm
    EtikettenAuslagern wsP.ChartObjects("Chart 15").Chart, 2
    On Error GoTo 0
End Sub

' ---------------------------------------------------------------- Navigation
Public Sub PlanungOeffnen()
    If modLaden.LadenLaeuft() Then Exit Sub
    ThisWorkbook.Worksheets("Planung").Activate
    ZurAktuellenKW
End Sub

Public Sub CockpitOeffnen()
    If modLaden.LadenLaeuft() Then Exit Sub
    ThisWorkbook.Worksheets("Cockpit").Activate
    ThisWorkbook.Worksheets("Cockpit").Range("A1").Select
End Sub

Public Sub ZurAktuellenKW()
    ' Blaettert die Planung so, dass die aktuelle Kalenderwoche direkt neben den fixierten Spalten steht
    Dim ws As Worksheet, wsW As Worksheet, schluessel As Long, spalte As Variant, heute As Date
    Set ws = ThisWorkbook.Worksheets("Planung")
    Set wsW = ThisWorkbook.Worksheets("Wirksam")
    heute = Date - Weekday(Date, vbMonday) + 4                 ' Donnerstag der Woche: ISO-Jahr und -Woche stimmen dann immer
    schluessel = Year(heute) * 100 + DatePart("ww", heute, vbMonday, vbFirstFourDays)
    spalte = Application.Match(schluessel, wsW.Rows(6), 0)
    ws.Activate
    If IsError(spalte) Then Exit Sub
    ActiveWindow.ScrollColumn = CLng(spalte)
    ws.Cells(7, CLng(spalte)).Select
End Sub

Private Sub SetzeReihen(ch As Chart, blatt As String, katSpalte As String, z1 As Long, z2 As Long, spalten As Variant)
    Dim i As Long
    For i = 1 To ch.SeriesCollection.Count
        If i - 1 <= UBound(spalten) Then
            ch.SeriesCollection(i).XValues = "=" & blatt & "!$" & katSpalte & "$" & z1 & ":$" & katSpalte & "$" & z2
            ch.SeriesCollection(i).Values = "=" & blatt & "!$" & spalten(i - 1) & "$" & z1 & ":$" & spalten(i - 1) & "$" & z2
        End If
    Next i
End Sub

' ---------------------------------------------------------------- Etiketten wie in think-cell: passt der Wert nicht ins Segment,
' steht er mit Fuehrungslinie neben der Saeule (abwechselnd links und rechts, ohne Ueberlappung) bzw. ueber dem Balken.
Public Sub EtikettenAuslagern(ch As Chart, dunkleReihen As Long)
    Dim s As Series, p As Point, lbl As DataLabel, werte() As Variant, reihenTyp() As Long, leader() As Boolean
    Dim i As Long, j As Long, n As Long, nReihen As Long, y As Single, x As Single, v As Double
    Dim links As Boolean, letzteL As Single, letzteR As Single, balken As Boolean
    Dim lb As Single, lh As Single, luecke As Single, kat As Single
    On Error Resume Next
    n = ch.SeriesCollection(1).Points.Count
    nReihen = ch.SeriesCollection.Count
    If n = 0 Or nReihen = 0 Then Exit Sub
    ' Reihenwerte und Typen einmal lesen (Values je Punkt zu lesen ist teuer)
    ReDim werte(1 To nReihen): ReDim reihenTyp(1 To nReihen): ReDim leader(1 To nReihen)
    For j = 1 To nReihen
        Set s = ch.SeriesCollection(j)
        reihenTyp(j) = 0
        If s.ChartType = xlColumnStacked Then reihenTyp(j) = 1
        If s.ChartType = xlBarStacked Or s.ChartType = xlBarStacked100 Then reihenTyp(j) = 2
        If Left$(s.Name, 5) = "Delta" Or s.Name = "Achsenluft" Then reihenTyp(j) = 0   ' unsichtbare Badge-Segmente: Etiketten bleiben, wie sie sind
        If reihenTyp(j) > 0 Then werte(j) = s.Values
    Next j
    kat = ch.PlotArea.InsideWidth / n
    For i = 1 To n
        links = (i < n): letzteL = -1E+9: letzteR = -1E+9      ' letzte Saeule: rechts beginnen, dort ist der Rand frei
        For j = 1 To nReihen
            If reihenTyp(j) > 0 Then
                Set s = ch.SeriesCollection(j)
                balken = (reihenTyp(j) = 2)
                v = 0
                If IsNumeric(werte(j)(i)) Then v = CDbl(werte(j)(i))
                Set p = s.Points(i)
                If v <> 0 And p.HasDataLabel Then
                    Set lbl = p.DataLabel
                    lb = lbl.Width: lh = lbl.Height
                    If balken Then
                        If p.Width < lb + 2 Then
                            lbl.Position = xlLabelPositionCenter
                            x = p.Left + p.Width / 2 - lb / 2
                            If x < letzteR Then x = letzteR
                            lbl.Left = x
                            lbl.Top = p.Top - lh - 3
                            letzteR = x + lb + 2
                            lbl.Font.Color = RGB(74, 74, 74)
                            If Not leader(j) Then s.HasLeaderLines = True: leader(j) = True
                        Else
                            lbl.Position = xlLabelPositionCenter
                            If j <= dunkleReihen Then lbl.Font.Color = RGB(26, 26, 26) Else lbl.Font.Color = RGB(255, 255, 255)
                        End If
                    Else
                        If p.Height < lh + 1 Or p.Width < lb + 2 Then
                            lbl.Position = xlLabelPositionCenter
                            y = p.Top + p.Height / 2 - lh / 2
                            If links Then
                                If Abs(y - letzteL) < lh + 1 Then y = IIf(y <= letzteL, letzteL - lh - 1, letzteL + lh + 1)
                                lbl.Left = p.Left - lb - 5
                                letzteL = y
                            Else
                                If Abs(y - letzteR) < lh + 1 Then y = IIf(y <= letzteR, letzteR - lh - 1, letzteR + lh + 1)
                                lbl.Left = p.Left + p.Width + 5
                                letzteR = y
                            End If
                            lbl.Top = y
                            links = Not links
                            lbl.Font.Color = RGB(74, 74, 74)
                            If Not leader(j) Then s.HasLeaderLines = True: leader(j) = True
                            ' Passt das Etikett nicht in die Luecke zwischen den Saeulen, Schrift verkleinern
                            luecke = kat - p.Width
                            If luecke < 0 Then luecke = 0
                            If lb + 6 > luecke And i > 1 And i < n Then lbl.Font.Size = 7 Else lbl.Font.Size = 8
                        Else
                            lbl.Position = xlLabelPositionCenter
                            lbl.Font.Color = RGB(255, 255, 255)
                        End If
                    End If
                End If
            End If
        Next j
    Next i
    On Error GoTo 0
End Sub

