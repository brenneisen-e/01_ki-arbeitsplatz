/* ============================================================
   NÜRNBERGER KPI-Board — Datenpflege
   ------------------------------------------------------------
   Erfassung je Periode, Pflichten (Fälligkeit), Änderungs-Log und
   effektive Werte. Wird nach data.js/data_basis.js und vor app.js
   geladen. localStorage: Werte über data_store.js, Log unter LOG_KEY.
   ============================================================ */

/* ---------- Bediener ----------
   Es gibt derzeit keine Rollen: ein Bediener pflegt alle Kennzahlen. */
const SINGLE_USER = { id: "nutzer", label: "Nutzer" };

function currentRole() { return SINGLE_USER.id; }
/* Name des Bedieners im Änderungs-Log */
function logActor() { return SINGLE_USER.label; }

/* Alle Kennzahlen (keine Aufteilung nach Rollen) */
function kpisOfRole() { return allKpis(); }

/* ---------- Erfasste Werte ----------
   Lesen und Schreiben über data_store.js. loadValues() liefert die
   Wide-Sicht für Pflichten und Datenqualität. */
function loadValues() {
  const out = {};
  loadLong().forEach(r => {
    if (r.type !== "ist" || r.source !== ENTRY_SOURCE) return;
    out[r.kpi_id] = out[r.kpi_id] || {};
    out[r.kpi_id][r.period] = { value: r.value, enteredAt: r.last_updated, enteredBy: r.source };
  });
  return out;
}
function getEnteredValue(kpiId, period) {
  const rec = getLongRecord(kpiId, period, "ist");
  if (!isEnteredRecord(rec)) return null;
  return { value: rec.value, enteredAt: rec.last_updated, enteredBy: rec.source };
}
/* Planwerte (type = "plan") */
function getPlanValue(kpiId, period) {
  const rec = getLongRecord(kpiId, period, "plan");
  return rec ? { value: rec.value, enteredAt: rec.last_updated } : null;
}

/* ---------- Änderungs-Log ---------- */
const LOG_KEY = "kpi_changelog_v2";
function loadLog() {
  try { return JSON.parse(localStorage.getItem(LOG_KEY) || "[]") || []; }
  catch (e) { return []; }
}
function saveLog(l) {
  try { localStorage.setItem(LOG_KEY, JSON.stringify(l)); } catch (e) {}
}
function addLogEntry(entry) {
  const log = loadLog();
  log.push(Object.assign({ ts: new Date().toISOString() }, entry));
  saveLog(log);
}

/* ---------- Perioden-Logik ----------
   Quartalsraster aus data_basis.js. Halbjährliche KPIs erfassen Q2/Q4,
   jährliche Q4, alle anderen jedes Quartal. */
const CADENCE_QSTEP = {
  "Quartal": 1, "Monatlich": 1, "Halbjährlich": 2, "Jährlich": 4
};

function cadenceOf(kpi) {
  const c = (kpi.cadence || "Quartal").trim();
  if (/halb/i.test(c)) return "Halbjährlich";
  if (/monat/i.test(c)) return "Monatlich";
  if (/j[aä]hr/i.test(c)) return "Jährlich";
  return "Quartal";
}

/* Erfassbare Perioden je KPI nach Takt */
function entryPeriods(kpi) {
  const cad = cadenceOf(kpi);
  if (cad === "Halbjährlich") return PERIODS.filter(p => /Q2|Q4/.test(p));
  if (cad === "Jährlich") return PERIODS.filter(p => /Q4/.test(p));
  return PERIODS.slice();
}

/* Perioden-Ende als Date (Quartalsende) */
function periodEndDate(period) {
  const m = period.match(/^(\d{4})-Q([1-4])$/);
  if (!m) return null;
  const y = parseInt(m[1], 10), q = parseInt(m[2], 10);
  const month = q * 3; /* Q1→März=3, Q2→Juni=6, Q3→Sep=9, Q4→Dez=12 */
  return new Date(y, month, 0); /* Tag 0 = letzter Tag des Vormonats */
}

/* Nächste Periode im Takt-Schritt */
function nextPeriod(period, step) {
  const m = period.match(/^(\d{4})-Q([1-4])$/);
  if (!m) return null;
  let y = parseInt(m[1], 10), q = parseInt(m[2], 10) + step;
  while (q > 4) { q -= 4; y += 1; }
  while (q < 1) { q += 4; y -= 1; }
  return `${y}-Q${q}`;
}

/* Letzte erwartbare Periode: jüngste Periode, deren Ende plus
   6 Wochen Erfassungszeit vorbei ist. */
const ENTRY_GRACE_DAYS = 42;
function lastExpectedPeriod(kpi) {
  const periods = entryPeriods(kpi);
  const now = new Date();
  let last = null;
  periods.forEach(p => {
    const due = periodEndDate(p);
    if (!due) return;
    const deadline = new Date(due.getTime() + ENTRY_GRACE_DAYS * 86400000);
    if (deadline <= now) last = p;
  });
  return last;
}

/* Letzte erfasste Periode (Erfassung oder Ist aus data_basis) */
function lastEnteredPeriod(kpi) {
  const periods = entryPeriods(kpi);
  let last = null;
  periods.forEach(p => {
    if (getEnteredValue(kpi.id, p)) last = p;
    else {
      const d = (typeof KPI_DATA !== "undefined" && KPI_DATA[kpi.id]) ? KPI_DATA[kpi.id] : null;
      if (d && d.series) {
        const s = d.series.find(x => x.period === p && x.isActual && x.value !== null);
        if (s) last = p;
      }
    }
  });
  return last;
}

/* ---------- Pflichten-Status je KPI ----------
   fällig: erwartete Periode noch nicht erfasst und Frist vorbei
   demnächst: Frist in ≤ 30 Tagen
   ok: nichts offen
   im-aufbau: Kennzahl ohne Methodik, keine Pflicht */
function dutyStatus(kpi) {
  if (kpi.maturity === "zu-entwickeln") return "im-aufbau";
  const expected = lastExpectedPeriod(kpi);
  if (!expected) return "ok";
  const entered = lastEnteredPeriod(kpi);
  const periods = entryPeriods(kpi);
  const eIdx = periods.indexOf(expected);
  const aIdx = entered ? periods.indexOf(entered) : -1;
  if (eIdx >= 0 && aIdx >= eIdx) return "ok";
  /* Fälligkeit: Periodenende + 6 Wochen */
  const due = periodEndDate(expected);
  if (!due) return "ok";
  const deadline = new Date(due.getTime() + ENTRY_GRACE_DAYS * 86400000);
  const now = new Date();
  if (deadline <= now) return "faellig";
  if (deadline - now <= 30 * 86400000) return "demnaechst";
  return "ok";
}

/* Fälligkeitsfrist (Datum) für Anzeige */
function dutyDeadline(kpi) {
  const expected = lastExpectedPeriod(kpi);
  if (!expected) return null;
  const due = periodEndDate(expected);
  if (!due) return null;
  return new Date(due.getTime() + ENTRY_GRACE_DAYS * 86400000);
}

/* Nächste zu erfassende Periode (Vorbelegung im Datenblatt) */
function nextDuePeriod(kpi) {
  const entered = lastEnteredPeriod(kpi);
  const periods = entryPeriods(kpi);
  if (!entered) return periods[0] || null;
  const step = CADENCE_QSTEP[cadenceOf(kpi)] || 1;
  return nextPeriod(entered, step);
}

/* Alle Pflichten über alle Kennzahlen */
function allDuties() {
  return kpisOfRole().map(k => ({
    kpi: k,
    status: dutyStatus(k),
    period: lastExpectedPeriod(k),
    deadline: dutyDeadline(k)
  }));
}
function countDueDuties() {
  return allDuties().filter(d => d.status === "faellig").length;
}

/* ---------- Effektive Werte ----------
   Einzige Stelle, die Erfassung und data_basis.js zusammenführt.
   Rangfolge: 1. erfasster Ist-Wert  2. Ist aus data_basis
   3. current aus data.js. */
function effectiveValue(kpiId) {
  const kpi = kpiById(kpiId);
  if (!kpi) return null;
  const periods = entryPeriods(kpi);
  /* 1. jüngste erfasste Periode */
  let best = null, bestP = null;
  periods.forEach(p => {
    const rec = getLongRecord(kpiId, p, "ist");
    if (isEnteredRecord(rec) && typeof rec.value === "number" && (!bestP || p > bestP)) {
      best = rec; bestP = p;
    }
  });
  if (best) return { value: best.value, period: bestP, source: "erfasst" };
  /* 2. Ist aus data_basis */
  if (typeof KPI_DATA !== "undefined" && KPI_DATA[kpiId]) {
    const d = KPI_DATA[kpiId];
    let b = null, bp = null;
    (d.series || []).forEach(s => {
      if (s.isActual && typeof s.value === "number" && (!bp || s.period > bp)) { b = s; bp = s.period; }
    });
    if (b) return { value: b.value, period: bp, source: "basis" };
  }
  /* 3. current aus data.js */
  if (typeof kpi.current.value === "number") {
    return { value: kpi.current.value, period: null, source: "kuratiert" };
  }
  return null;
}

/* Hat der Nutzer für diese Kennzahl Werte erfasst? */
function hasEnteredValues(kpiId) {
  const vals = loadValues()[kpiId] || {};
  return Object.keys(vals).length > 0;
}

/* Wert schreiben (validiert über setLongValue); gibt den vorherigen
   Wert zurück. `roleId` wird nicht ausgewertet. */
function writeValue(kpiId, period, value, roleId, type) {
  const t = type || "ist";
  const res = setLongValue(kpiId, period, t, value, { source: ENTRY_SOURCE });
  if (!res.ok && typeof console !== "undefined") console.warn("Wert abgewiesen:", res.errors.join("; "));
  return res.prev;
}

/* Lokale Erfassung löschen (Log bleibt) */
function clearEnteredValues() {
  clearEnteredLong();
}

/* ---------- Datenqualität ----------
   pct = erfasste Ist-Perioden ÷ erwartete Ist-Perioden; Ist aus
   data_basis zählt, solange nichts erfasst ist. */
function qualityOf(kpi) {
  const periods = entryPeriods(kpi);
  const expected = lastExpectedPeriod(kpi);
  const eIdx = expected ? periods.indexOf(expected) : -1;
  const expectedCount = eIdx >= 0 ? eIdx + 1 : 0;
  if (!expectedCount) {
    return { pct: 0, expectedCount: 0, have: 0, entered: 0, basis: 0 };
  }
  const expectedPeriods = periods.slice(0, expectedCount);
  let entered = 0, basis = 0;
  expectedPeriods.forEach(p => {
    if (getEnteredValue(kpi.id, p)) { entered++; return; }
    const d = (typeof KPI_DATA !== "undefined" && KPI_DATA[kpi.id]) ? KPI_DATA[kpi.id] : null;
    const s = d && d.series ? d.series.find(x => x.period === p && x.isActual && x.value !== null) : null;
    if (s) basis++;
  });
  const have = entered + basis;
  const pct = Math.min(100, Math.round(have / expectedCount * 100));
  return { pct, expectedCount, have, entered, basis };
}

/* ---------- Export / Import ---------- */
function exportState() {
  return {
    long: loadLong(),
    changelog: loadLog(),
    exportedAt: new Date().toISOString()
  };
}
function importState(json) {
  try {
    const s = typeof json === "string" ? JSON.parse(json) : json;
    if (Array.isArray(s.long)) {
      const res = saveLong(s.long);
      if (!res.ok) return false;
    }
    if (s.changelog) saveLog(s.changelog);
    return true;
  } catch (e) { return false; }
}

/* ---------- Markdown-Export des Logs ---------- */
function changelogMarkdown() {
  const log = loadLog();
  if (!log.length) return "_Keine Einträge._";
  const lines = ["| Zeit | Kennzahl | Periode / Feld | Art | Alt | Neu |", "|---|---|---|---|---|---|"];
  log.slice().reverse().forEach(e => {
    lines.push(`| ${e.ts.slice(0, 16).replace("T", " ")} | ${e.kpiName || e.kpi} | ${e.period || e.field || "—"} | ${e.kind} | ${e.oldValue === null || e.oldValue === undefined ? "—" : e.oldValue} | ${e.newValue === null || e.newValue === undefined ? "—" : e.newValue} |`);
  });
  return lines.join("\n");
}