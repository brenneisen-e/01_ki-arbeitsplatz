/* ============================================================
   NÜRNBERGER KPI-Board — Plan-Rechnung
   ------------------------------------------------------------
   Der Quartalsplan wird aus den Eckwerten (Basis, Ziel 2028,
   Ziel 2031) linear gerechnet. Hinterlegte Planwerte einzelner
   Quartale haben Vorrang.
   Läuft im Browser und in Node (Tests).
   ============================================================ */
(function (root) {
  'use strict';

  /* „2026-Q2" → 2026.25; Q4 = x.75 */
  function periodToYearFraction(period) {
    const m = String(period == null ? '' : period).match(/^(\d{4})-Q([1-4])$/);
    if (!m) return null;
    return parseInt(m[1], 10) + (parseInt(m[2], 10) - 1) / 4;
  }

  /* 2026.25 → „2026-Q2" */
  function yearFractionToPeriod(yf) {
    const year = Math.floor(yf + 1e-9);
    const q = Math.round((yf - year) * 4) + 1;
    return `${year}-Q${q}`;
  }

  /* Eckwerte ohne Zahl (z. B. TBD) fallen weg; Ergebnis zeitlich sortiert. */
  function normalizeAnchors(anchors) {
    return (anchors || [])
      .filter(a => a && typeof a.value === 'number' && a.period)
      .map(a => ({
        period: a.period,
        yf: periodToYearFraction(a.period),
        value: a.value,
        source: a.source || 'anker'
      }))
      .filter(a => a.yf !== null)
      .sort((a, b) => a.yf - b.yf);
  }

  /* Linear zwischen den Stützpunkten. Nach dem letzten Eckwert bleibt der
     Zielwert stehen; vor dem ersten gibt es keinen Plan. */
  function interpolateAt(anchors, yf) {
    if (!anchors.length) return null;
    if (yf < anchors[0].yf) return null;
    const last = anchors[anchors.length - 1];
    if (yf >= last.yf) return last.value;
    for (let i = 0; i < anchors.length - 1; i++) {
      const a = anchors[i], b = anchors[i + 1];
      if (yf >= a.yf && yf <= b.yf) {
        const span = b.yf - a.yf;
        if (span === 0) return b.value;
        return a.value + (b.value - a.value) * (yf - a.yf) / span;
      }
    }
    return last.value;
  }

  /* Saisongewichte Q1–Q3 relativ zu Q4, gemittelt über alle Jahre mit
     vier hinterlegten Quartalen. Für kumulierte KPIs (Q4 = Jahreswert)
     werden damit Jahre ohne hinterlegte Quartale verteilt. */
  function deriveSeasonalWeights(documented) {
    const doc = documented || {};
    const byYear = {};
    Object.keys(doc).forEach(period => {
      const m = String(period).match(/^(\d{4})-Q([1-4])$/);
      const v = doc[period];
      if (!m || typeof v !== 'number') return;
      const year = m[1];
      (byYear[year] || (byYear[year] = {}))[m[2]] = v;
    });
    const ratios = [[], [], []];
    Object.keys(byYear).forEach(year => {
      const y = byYear[year];
      if (typeof y['1'] === 'number' && typeof y['2'] === 'number' &&
          typeof y['3'] === 'number' && typeof y['4'] === 'number' && y['4'] !== 0) {
        ratios[0].push(y['1'] / y['4']);
        ratios[1].push(y['2'] / y['4']);
        ratios[2].push(y['3'] / y['4']);
      }
    });
    if (!ratios[0].length) return null;
    const avg = arr => arr.reduce((s, v) => s + v, 0) / arr.length;
    return [avg(ratios[0]), avg(ratios[1]), avg(ratios[2])];
  }

  /* Plan je Periode. `documented` ({ "2026-Q4": 55, … }) hat Vorrang.
     Ohne mindestens zwei Eckwerte gibt es keinen Plan.
     opts.cumulative: Q1–Q3 werden aus dem Jahreswert mit den
     Saisongewichten verteilt statt über Jahresgrenzen interpoliert. */
  function derivePath(periods, anchors, documented, opts) {
    const norm = normalizeAnchors(anchors);
    const doc = documented || {};
    const seasonal = (opts && opts.cumulative) ? deriveSeasonalWeights(doc) : null;
    const hasPlan = norm.length >= 2;
    /* Hinterlegte Punkte ab dem ersten Eckwert zählen als Stützpunkte;
       sie ersetzen einen Eckwert derselben Periode. */
    let supports = norm;
    if (hasPlan) {
      const firstYf = norm[0].yf;
      const docPts = Object.keys(doc)
        .filter(p => typeof doc[p] === 'number')
        .map(p => ({ period: p, yf: periodToYearFraction(p), value: doc[p], source: 'dokumentiert' }))
        .filter(d => d.yf !== null && d.yf >= firstYf);
      const docPeriods = new Set(docPts.map(d => d.period));
      supports = norm.filter(a => !docPeriods.has(a.period)).concat(docPts)
        .sort((a, b) => a.yf - b.yf);
    }
    return (periods || []).map(period => {
      if (Object.prototype.hasOwnProperty.call(doc, period) &&
          typeof doc[period] === 'number') {
        return { period, value: doc[period], source: 'dokumentiert' };
      }
      if (!hasPlan) return { period, value: null, source: 'keine' };
      const yf = periodToYearFraction(period);
      if (yf === null || yf < norm[0].yf) return { period, value: null, source: 'keine' };
      if (seasonal) {
        const m = String(period).match(/^(\d{4})-Q([1-4])$/);
        const q = m ? parseInt(m[2], 10) : null;
        if (q !== null && q < 4) {
          const annual = interpolateAt(supports, parseInt(m[1], 10) + 0.75);
          if (annual !== null) {
            return { period, value: annual * seasonal[q - 1], source: 'saisonal' };
          }
        }
      }
      const v = interpolateAt(supports, yf);
      return { period, value: v, source: v === null ? 'keine' : 'interpoliert' };
    });
  }

  /* Planwert einer Periode */
  function pathValueAt(periods, anchors, documented, period, opts) {
    const row = derivePath([period], anchors, documented, opts)[0];
    return row && typeof row.value === 'number' ? row.value : null;
  }

  root.PathDerive = {
    periodToYearFraction, yearFractionToPeriod,
    normalizeAnchors, interpolateAt, deriveSeasonalWeights, derivePath, pathValueAt
  };
})(typeof window !== 'undefined' ? window : globalThis);
