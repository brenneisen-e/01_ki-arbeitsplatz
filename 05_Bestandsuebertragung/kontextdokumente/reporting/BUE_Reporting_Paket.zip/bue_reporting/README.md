# BÜ-Reporting HSB4 K – Master-Excel

Tagesbasiertes Reporting der Makler-Bestandsübertragung aus den Rückstandsabzügen **OPAG** (Arbeitsgüter) und
**Verbund** (Vorgänge) sowie der Anwesenheitsliste (MAK je Kalenderwoche). Eine Master-Datei mit Makros liest die
Rohdaten aus einem Ordner, führt Rückstand, Eingänge, Abgänge und Produktivität fort und zeigt alles in einem Cockpit.

## Ordnerstruktur

```
bue_reporting/
├── BUE_Reporting_Master.xlsm      leere Master-Datei (Cockpit, Makros) – Daten kommen per „Neue Daten laden“
├── BUE_Reporting_Demo_befuellt.xlsm dieselbe Datei, mit den vier Abzügen und der MAK-Liste vorbefüllt (zum Anschauen)
├── Rohdaten/                      tägliche Abzüge, je Datei ein Blatt (oder mehrere) – Dateiname beliebig
│   ├── 20260922_Rueckstand_OPAG_HSB4K.xlsx
│   ├── 20260922_Rueckstand_Verbund_HSB4K.xlsx
│   ├── 20260923_Rueckstand_OPAG_HSB4K.xlsx
│   └── 20260923_Rueckstand_Verbund_HSB4K.xlsx
├── Anwesenheit/                   MAK-Liste für den einmaligen Import (die neueste Datei wird gelesen)
│   └── HSB4K_Anwesenheit_bis_Oktober_2026.xlsx
├── Vorlage/ERGO_Vorlage.pptx      ERGO-Folienmaster für „PowerPoint-Folie erzeugen“
├── Praesentationen/               entsteht beim ersten Export, eine Datei je Folie
└── quellen/                       Build-Skripte (siehe unten)
```

Die Master-Datei erkennt jedes Blatt selbst: Stichtag aus der Zeile „Rückstandsstichtag = Mittwoch, 23. September 2026“,
Quelle aus den Spaltenköpfen (`OPS_AUFTR_ID` vorhanden = OPAG, sonst Verbund). Liegt die Master-Datei in OneDrive oder SharePoint, bildet das Makro die https-Adresse auf den
synchronisierten lokalen Ordner ab oder fragt ihn einmal ab (Konfiguration!B7). Ein Stand (Quelle + Stichtag) wird nur
einmal geladen; das Ladeprotokoll zeigt, was drin ist. Stände müssen in zeitlicher Reihenfolge kommen, weil Eingänge
und Abgänge aus dem Vergleich mit dem jeweils letzten Stand entstehen.

## Anleitung in der Datei

Das Blatt **Anleitung** (zweites Blatt) beschreibt Ordner, täglichen Ablauf, Tages- und Sammeldateien, Anwesenheit,
Filter, Kennzahlen, Blätter, Fehlerbilder und Grenzen. Tagesdateien (ein Blatt je Datei) und Sammeldateien (mehrere
Blätter je Datei) werden gleich behandelt: die Erkennung arbeitet je Blatt.

## Bedienung im Cockpit

- **Neue Daten laden** – alle Abzüge im Ordner Rohdaten einlesen, fehlende Stände ergänzen; ein Overlay mit Fortschrittsbalken zeigt Datei, Stand und Prozent (modFortschritt, Formen auf dem Blatt, keine UserForm).
- **Anwesenheit laden** – MAK-Liste einmal importieren: füllt „Mitarbeiter“ (Stammdaten, Kapazität = größter Wochenwert) und „Planung“ (nur Abweichungen: U Urlaub, F sonstige Abwesenheit, Zahl).
- **Anwesenheitsplan öffnen** – Blatt „Planung“: Matrix Mitarbeiter × KW bis Ende 2028, Einträge leer/U/K/F/H/Zahl, aktuelle KW markiert, Summen je KW; neue Mitarbeitende im Blatt „Mitarbeiter“ anlegen, Austritt per Datum oder Aktiv = FALSCH.
- **PowerPoint-Folie erzeugen** – kopiert die sechs Kacheln des Blatts „PPT“ (OPAG rot, Verbund petrol, Kennzahlen im Kachelkopf) auf eine Folie der ERGO-Vorlage, Titel „HS | BÜ-Reporting Makler-Bestandsübertragung“, sichert eine Kopie in „Praesentationen“.
- **Sparten** – Chips Komposit, Leben, KV und Sonstige in der Farbe der Sparte; sie grenzen alle Kennzahlen und Diagramme auf die gewählten Sparten ein (Einzelreporting je Sparte). MAK und Produktivität folgen der Auswahl (KV gegen MAK Gesundheit, Komposit/Leben gegen MAK Komposit). Über den Rückstandssäulen zeigt ein Badge die Veränderung zur vorherigen Periode (grün = weniger, gelb = mehr, grau = gleich); die Kacheln Rückstand OPAG/Verbund nennen das Delta mit dem Datum des vorherigen geladenen Stands.
- **Themenpostkörbe** – Chips je Postkorb (gefüllt = im Filter, leuchten beim Überfahren mit der Maus auf; Zellen mit HYPERLINK auf die Hover-Funktion `ChipHover`, Klick über `Worksheet_SelectionChange` im Blattmodul Cockpit); „Aktive Bearbeitung“ setzt die Vorauswahl aus Konfiguration!F11:F30 (Standard KO, MV, GR), „Alle Postkörbe“ wählt alles.
- **GeVo-Typen** – Modus „Alle GeVo“, „Nur BÜ-Schlüssel“ (108, 469, 2015, 6065 aus Konfiguration!D11:D20) oder „Manuelle Auswahl“ über die Chips der 13 häufigsten GeVo-Typen (aufsteigend nach Nummer) plus „Alle übrigen“.
- **Ansicht** – Tagessicht (letzte 7 Stichtage) oder Wochensicht (letzte 7 Kalenderwochen) für Rückstand und Bewegungen; MAK und Produktivität immer je KW (7 KW bis zur KW des letzten Stichtags).
- Alle Kennzahlen und Diagramme rechnen über Formeln; die Filter wirken sofort. „Aktualisieren“ erzwingt eine Neuberechnung, „Zurücksetzen“ nimmt alle Filter zurück.

## Diagramme

- Immer 7 Plätze je Diagramm, neueste Periode rechts; fehlende Stände lassen die Plätze links frei, die Breite steht von Anfang an.
- Gestapelte Säulen im think-cell-Stil: Werte in den Segmenten, Summe über der Säule, keine Wertachse. Bewegungen: Eingänge über der Achse, Abgänge unter der Achse, Delta je Sparte daneben.
- Werte, die nicht in ihr Segment passen, stehen mit Führungslinie links oder rechts neben der Säule (Altersstruktur: über dem Balken). Beim Bau setzt `bue_reporting_build.py` diese Positionen ins Diagramm-XML; in Excel setzt `modCockpit.EtikettenAuslagern` sie nach jedem Laden und jedem Filterklick neu.

## Kennzahlen und Logik

| Größe | Definition |
|---|---|
| Rückstand | Zeilen des Abzugs am Stichtag (OPAG: Arbeitsgüter, Verbund: Vorgänge), nach Sparte aus dem Verwaltungssystemschlüssel (Konfiguration!A11:B40: KV; LV/LF/LG = Leben; übrige = Komposit) |
| Eingänge | Schlüssel, die im neuen Stand erstmals vorkommen (Verbund: VSS + Ordnungsbegriff + VORG_VERBU_LNR; OPAG zusätzlich OPS_AUFTR_ID + OPS_ARBGUT_LNR) |
| Abgänge | Schlüssel des Vortagsstands, die im neuen Stand fehlen – abgearbeitet oder weitergeleitet (auch Übergabe an den 72-Stunden-BOT); zugeordnet nach Postkorb, GeVo und Sparte des Vortags |
| Altersklassen | Rückstandsalter 0–7, 8–30, 31–90, über 90 Tage |
| MAK je KW | wirksame MAK aus Mitarbeiter (Kapazität, Eintritt/Austritt, Aktiv) und Planung (leer = Kapazität, U/K/F = 0, H = halbe Kapazität, Zahl = Wert), getrennt nach Gesundheit (KV) und Komposit/Leben |
| Produktivität | Abgänge je MAK in der Kalenderwoche, Basis Verbund (Vorgänge) oder OPAG laut Konfiguration!B6; die laufende KW enthält nur die bereits geladenen Stichtage |

Der erste Stand je Quelle liefert nur den Rückstand (keine Bewegungen), ab dem zweiten Stand kommen Eingänge und Abgänge dazu.

## Blätter

Cockpit (KPI-Kacheln, Filter, Kacheln mit farbiger Kopfleiste: OPAG rot, Verbund petrol; neun Diagramme: Rückstand OPAG/Verbund, Bewegungen OPAG/Verbund in voller Breite, MAK, Altersstruktur, Produktivität Verbund/OPAG, Rückstand je Postkorb) · Verlauf (eine Zeile je Stichtag, gefiltert) · KW (Abgänge, MAK, Produktivität
je Kalenderwoche) · Fakten (verdichtete Sätze je Stichtag, Quelle, Sparte, VSS, Postkorb, GeVo mit Filterkennzeichen) ·
PPT (Folienkacheln) · Planung und Mitarbeiter (Anwesenheitstool) · Filter (Chip-Zellen, Hilfsgrößen) · Konfiguration · Ladeprotokoll · Snapshot_OPAG / Snapshot_Verbund
(ausgeblendet: Schlüssel des letzten Stands für den Vergleich am nächsten Tag) · Wirksam (ausgeblendet: berechnete MAK).

## Build (quellen/)

- `bue_reporting_build.py` – erzeugt die Master-Datei mit xlsxwriter, befüllt sie mit den vorhandenen Rohdaten, trägt
  Makros an die Schaltflächen und Kontrollkästchen in die Zeichnung ein und hängt das VBA-Projekt an.
- `verarbeitung.py` – dieselbe Zähl- und Vergleichslogik wie das VBA (für die Vorbefüllung und als Referenz).
- `ovba.py` – schreibt aus den `.bas`-Quelltexten ein `vbaProject.bin` (OLE-Container, MS-OVBA) ohne Excel.
- `vba/modLaden.bas`, `vba/modCockpit.bas`, `vba/modPPT.bas`, `vba/modFortschritt.bas`, `vba/Cockpit.cls` – der VBA-Quelltext (Laden und Import, Cockpit und Planung, PowerPoint-Export, Lade-Overlay, Blattmodul für die Chips).
- `lo_vba_check.py` – lädt die Master-Datei in LibreOffice und ruft je Modul eine Prozedur auf (Syntaxprüfung ohne Excel).

Aufruf: `python3 quellen/bue_reporting_build.py` schreibt beide Dateien (leere Master-Datei und befüllte Demo). Die Rohdaten-Sammeldatei
aus dem Upload wird beim ersten Lauf in Tagesdateien je Quelle zerlegt.

## Audit September 2026

Ergebnis und Umsetzung in `AUDIT_2026-09.md`: fremde Dateien werden ohne Makros geöffnet, Laden sperrt die Bedienung,
SUMIFS lesen nur den Fakten-Block des jeweiligen Stichtags (Verlauf!AL:AM), eine Hilfsformel je Fakten-Zeile, Planungshorizont
bis 2030 mit Warnung, 40 Postkörbe, Überlauf-Wachen.

## Prüfstand

Geprüft ohne Excel: Paketstruktur (Makroteil, Zeichnung, Diagramm-XML mit Etikettenversatz und Führungslinien, Namen), Lesbarkeit des
VBA-Projekts (oletools), Formeln vollständig mit LibreOffice Calc (Neuberechnung, keine Fehlerwerte außer den gewollten #NV in
leeren Diagrammplätzen und Produktivitätswochen ohne Daten) und mit dem Python-Paket `formulas`, die Zähllogik in Python gegen die
Rohdaten, das Cockpit als LibreOffice-Render (PDF, Seite 1). Erster Öffnen-Test in Excel mit der leeren Master-Datei: Makros aktivieren,
„Neue Daten laden“ (lädt die vier Abzüge aus Rohdaten, Ladeprotokoll zeigt vier Stände), „Anwesenheit laden“, dann Filter klicken und
die Etiketten neben schmalen Segmenten prüfen. Die Demo-Datei sollte danach dieselben Zahlen zeigen.
