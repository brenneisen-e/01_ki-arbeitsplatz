/* ============================================================
   NÜRNBERGER KPI-Board — Speicherschicht
   ------------------------------------------------------------
   Gespeichert wird im Long-Format, ein Eintrag je Wert:
     kpi_id · period · type · value · unit · comment · source · last_updated
   Ist und Plan sind getrennte Einträge (type = ist | plan).
   Die Eingabe arbeitet im Wide-Format (Perioden als Spalten);
   wideToLong() wandelt beim Speichern um.
   saveLong() schreibt nur, wenn alle Einträge gültig sind.
   ============================================================ */

const LONG_STORE_KEY = "kpi_long_v2";
const LONG_TYPES = ["ist", "plan"];
const LONG_FIELDS = ["kpi_id", "period", "type", "value", "unit", "comment", "source", "last_updated"];
/* Nur Einträge mit dieser Quelle gelten als „erfasst"; Startwerte
   tragen das Quellsystem aus data_basis.js. */
const ENTRY_SOURCE = "Erfassung";
const PLAN_SOURCE = "Planung";

/* ---------- KPI-Register ---------- */
function kpiList() {
  return [...DATA.finance, ...DATA.central, ...DATA.drivers, ...DATA.suggestions];
}
function kpiByIdLocal(id) { return kpiList().find(k => k.id === id) || null; }
function allowedKpiIds() { return kpiList().map(k => k.id); }

/* ---------- Validierung ----------
   Liefert die Fehlerliste; leer = gültig. */
function validateLongRecord(rec) {
  const errs = [];
  if (!rec || typeof rec !== "object" || Array.isArray(rec)) return ["Eintrag ist kein Objekt"];
  const extra = Object.keys(rec).filter(f => !LONG_FIELDS.includes(f));
  if (extra.length) errs.push(`unbekannte Felder: ${extra.join(", ")}`);
  if (!allowedKpiIds().includes(rec.kpi_id)) errs.push(`kpi_id „${rec.kpi_id}" ist nicht erlaubt`);
  if (!/^\d{4}-Q[1-4]$/.test(String(rec.period == null ? "" : rec.period))) {
    errs.push(`period „${rec.period}" hat nicht das Format YYYY-Qn`);
  }
  if (!LONG_TYPES.includes(rec.type)) errs.push(`type „${rec.type}" muss „ist" oder „plan" sein`);
  if (typeof rec.value !== "number" || !isFinite(rec.value)) errs.push(`value „${rec.value}" ist nicht numerisch`);
  if (typeof rec.unit !== "string" || !rec.unit.trim()) errs.push("unit fehlt");
  if (rec.comment != null && typeof rec.comment !== "string") errs.push("comment ist kein Text");
  if (rec.source != null && typeof rec.source !== "string") errs.push("source ist kein Text");
  if (rec.last_updated != null && typeof rec.last_updated !== "string") errs.push("last_updated ist kein Text");
  return errs;
}

/* ---------- Startwerte aus data_basis.js: Ist-Einträge der Serien ---------- */
function buildLongSeed() {
  const out = [];
  kpiList().forEach(k => {
    const d = (typeof KPI_DATA !== "undefined") ? KPI_DATA[k.id] : null;
    if (!d) return;
    const src = (d.dataQuality && d.dataQuality.sourceSystem) || k.source || "";
    const upd = (d.dataQuality && d.dataQuality.lastUpdated) || "";
    (d.series || []).forEach(s => {
      if (!s.isActual || typeof s.value !== "number") return;
      out.push({
        kpi_id: k.id, period: s.period, type: "ist", value: s.value,
        unit: k.unit, comment: "", source: src, last_updated: upd
      });
    });
  });
  return out;
}

let LONG_SEED = null;
function longSeed() { if (!LONG_SEED) LONG_SEED = buildLongSeed(); return LONG_SEED; }

/* ---------- Laden / Speichern ---------- */
function loadLong() {
  try {
    const raw = localStorage.getItem(LONG_STORE_KEY);
    if (!raw) return longSeed().slice();
    const arr = JSON.parse(raw);
    if (!Array.isArray(arr)) return longSeed().slice();
    return arr;
  } catch (e) { return longSeed().slice(); }
}

/* Schreibt nur, wenn jeder Eintrag gültig ist. */
function saveLong(records) {
  const errs = [];
  records.forEach((r, i) => {
    const e = validateLongRecord(r);
    if (e.length) errs.push(`Eintrag ${i + 1}: ${e.join("; ")}`);
  });
  if (errs.length) return { ok: false, errors: errs, count: 0 };
  try {
    localStorage.setItem(LONG_STORE_KEY, JSON.stringify(records));
  } catch (e) {
    return { ok: false, errors: ["Speichern im Browser fehlgeschlagen"], count: 0 };
  }
  return { ok: true, errors: [], count: records.length };
}

/* ---------- Umwandlung Wide → Long ---------- */
function wideToLong(kpiId, wide, opts = {}) {
  const kpi = kpiByIdLocal(kpiId);
  const unit = (kpi && kpi.unit) || "";
  const now = new Date().toISOString();
  const out = [];
  ["ist", "plan"].forEach(type => {
    const row = (wide && wide[type]) || {};
    Object.keys(row).forEach(period => {
      const v = row[period];
      if (v === null || v === undefined || v === "") return;
      const num = Number(v);
      if (!isFinite(num)) return;
      const key = type + ":" + period;
      out.push({
        kpi_id: kpiId, period, type, value: num, unit,
        comment: (opts.comment && opts.comment[key]) || (type === "plan" ? "Plan" : ""),
        source: (opts.source && opts.source[key]) || (type === "plan" ? PLAN_SOURCE : ENTRY_SOURCE),
        last_updated: now
      });
    });
  });
  return out;
}

/* ---------- Einzelwert schreiben (validiert) ---------- */
function setLongValue(kpiId, period, type, value, opts = {}) {
  const kpi = kpiByIdLocal(kpiId);
  if (!kpi) return { ok: false, errors: [`kpi_id „${kpiId}" ist nicht erlaubt`], prev: null };
  const store = loadLong();
  const idx = store.findIndex(r => r.kpi_id === kpiId && r.period === period && r.type === type);
  const prev = idx >= 0 ? store[idx].value : null;
  if (value === null || value === undefined || value === "") {
    if (idx >= 0) store.splice(idx, 1);
    const res = saveLong(store);
    return { ok: res.ok, errors: res.errors, prev };
  }
  const rec = {
    kpi_id: kpiId, period, type, value: Number(value), unit: kpi.unit,
    comment: opts.comment || (type === "plan" ? "Plan" : ""),
    source: opts.source || (type === "plan" ? PLAN_SOURCE : ENTRY_SOURCE),
    last_updated: new Date().toISOString()
  };
  const errs = validateLongRecord(rec);
  if (errs.length) return { ok: false, errors: errs, prev };
  if (idx >= 0) store[idx] = rec; else store.push(rec);
  const res = saveLong(store);
  return { ok: res.ok, errors: res.errors, prev };
}

/* ---------- Lesen ---------- */
function getLongRecord(kpiId, period, type) {
  return loadLong().find(x => x.kpi_id === kpiId && x.period === period && x.type === type) || null;
}
function isEnteredRecord(rec) { return !!rec && rec.source === ENTRY_SOURCE; }

/* ---------- Zurücksetzen ---------- */
/* Alle lokalen Werte verwerfen; danach gelten wieder die Startwerte. */
function clearEnteredLong() {
  try { localStorage.removeItem(LONG_STORE_KEY); } catch (e) {}
  return { ok: true, errors: [], count: 0 };
}
